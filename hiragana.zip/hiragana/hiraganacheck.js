﻿// Hiragana Checker js
// Copyright (c) 2024 syuribox
// Released under the MIT license.

function html_escape(s){
	return s.replace(/&/g,"&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, '&#39;').replace(/"/g, '&#34;');
}

function get_id(id){
	return document.getElementById(id);
}

function page_onload(){
	dic_change();
}

function button_file_open(e){
	read_files(e.target.files);
}

function drop_files(e){
	e.preventDefault();
	read_files(e.dataTransfer.files);
}

function drop_cancel(e){
	if(e.preventDefault){
		e.preventDefault();
	}
	return false;
}

var book = [];
var current_page = -1;
var button_start_val = '構文チェック';
var concat_page_name = '結合テキスト';
var str_update = ' [変更]';
var last_check_type = 0;

function read_files(files){
	var file_size = 0;
	for(var i = 0; i < files.length; i++){
		file_size += files[i].size;
	}
	if( 500000 < file_size ){
		if(false == window.confirm('合計ファイルサイズが500KB以上あります。\n' +
				'ファイル読み込みを処理しますか？')){
			return;
		}
	}
	var curret_name = '<>';
	if(current_page != -1){
		curret_name = book[current_page].name;
	}
	book = []; //reset
	var index = 0;
	var encoding = 'UTF-8';
	if(get_id('option_sjis').checked){
		encoding = 'Shift_JIS';
	}
	var loader = function(e){
		book[index] = {};
		book[index].name = files[index].name;
		book[index].text = e.target.result.replace(/\r\n/g, '\n');
		index++;
		if(index < files.length){
			var reader = new FileReader();
			reader.onload = loader;
			reader.readAsText(files[index], encoding);
		}else{
			split_file_to_pages(false);
			var page_num = 0;
			for(var i = 0; i < book.length; i++){
				if(book[i].name === curret_name){
					page_num = i;
					break;
				}
			}
			page_view(page_num);
		}
		e = null;
	}
	var reader = new FileReader();
	reader.onload = loader;
	reader.readAsText(files[index], encoding);
}

function split_view(){
	var disp = 'none';
	if(get_id('option_split_view').style.display == 'none'){
		disp = 'block';
	}
	get_id('option_split_view').style.display = disp;
	split_change();
}

function split_change(){
	var disp = 'none';
	if(get_id('split_type').value == 'splitregex'){
		disp = 'inline';
	}
	get_id('split_regex').style.display = disp;
	disp = 'none';
	var val = get_id('split_type').value;
	if(val == 'concat' || val == 'splitconcat'){
		disp = 'inline';
	}
	get_id('concat_head_view').style.display = disp;
}

function split_area(){
	book = [];
	var page = {};
	page.text = get_id('maintext').value.replace(/\r\n/g, '\n');
	var concat_mode = (get_id('split_type').value === 'concat');
	if(concat_mode){
		page.name = concat_page_name;
	}else{
		page.name = '';
	}
	book[0] = page;
	split_file_to_pages(true);
	page_view(0);
}

function split_file_to_pages(from_split_area){
	var split_type = get_id('split_type').value;
	var concat_head = get_id('concat_head').value;
	var newbook = [];
	var narou_file = false;
	var filename_max = 0;
	for(var i = 0; i < book.length; i++){
		var file = book[i];
		if(-1 != file.name.search(/^N([0-9]{4})([A-Z]{2})\-([\d]+)\.txt$/i)){
			narou_file = true;
		}
		if(filename_max < file.name.length){
			filename_max = file.name.length;
		}
	}
	if(narou_file && split_type === 'none' ){
		split_type = 'nameonly';
	}
	var concat_text = [];
	if(split_type != 'none'){
		for(var i = 0; i < book.length; i++){
			var file = book[i];
			var complete = false;
			var part_left = '\n------------------------- 第';
			var part_right = '部分開始 -------------------------\n【サブタイトル】\n';
			var part_end = -1;
			var part_mark = part_left + '1' + part_right;
			if(!complete && (split_type === 'auto' || split_type==='naroubackup')){
				part_end = file.text.indexOf(part_mark);
			}
			if(-1 != part_end){
				var part_start = 0;
				var k = 0;
				while(-1 != part_end){
					var page = {};
					page.name = file.name;
					var title = '';
					if(part_start === 0){
						title = '/【情報ヘッダ】';
					}else{
						pos_start = part_start + part_mark.length;
						var pos_end = file.text.indexOf('\n', pos_start);
						if(-1 != pos_end){
							var title = file.text.substr(pos_start, pos_end - pos_start);
							if( 20 < title.length ){
								title = title.substr(0, 30) + '..';
							}
							title = '/' + title;
						}
					}
					page.name += title;
					k++;
					part_mark = part_left + k + part_right;
					part_end = file.text.indexOf(part_mark, part_end);
					var part_end2 = part_end;
					if(-1 === part_end2){
						part_end2 = file.text.length;
					}
					page.text = file.text.substr(part_start, part_end2 - part_start);
					newbook.push(page);
					part_start = part_end;
				}
				complete = true;
			}
			if(!complete){
				var concat_head = get_id('concat_head').value;
				var head = -1;
				part_mark = '\n' + concat_head;
				var head_top = false;
				if(split_type === 'auto' || split_type==='splitconcat'){
					head_top = (file.text.substr(0, concat_head.length) === concat_head);
					if(head_top){
						head = 0;
					}else{
						head = file.text.indexOf(part_mark);
					}
				}
				if(head != -1 && head < 3000){
					var k = 1;
					if(head_top){
						part_end = concat_head.length;
					}else{
						part_end = head + part_mark.length;
					}
					while(-1 != part_end){
						var page = {};
						page.name = file.name;
						k++;
						var pos_end = file.text.indexOf('\n', part_end);
						if(-1 != pos_end){
							var title = file.text.substr(part_end, pos_end - part_end);
							if(from_split_area){
								var re = title.match(/^[_\d]+\/([^\\\/<>:\*\?]+)\/([\s\S]+)$/);
								var sub = '';;
								if(re){
									sub = re[2];
									if( 20 < sub.length ){
										sub = sub.substr(0, 30) + '..';
									}
									sub = '/' + sub;
								}else{
									re = title.match(/^[_\d]+\/([\s\S]+)$/);
								}
								if(re){
									var re_file = re[1];
									var re2 = re[1].match(/_+$/);
									if(re2){
										re_file = re_file.substr(0, re_file.length - re2.length);
									}
									title = re_file + sub;
								}
								page.name = title;
							}else{
								if( 20 < title.length ){
									title = title.substr(0, 30) + '..';
								}
								page.name += '/' + title;
							}
							part_end = file.text.indexOf(part_mark, pos_end + 1);
							if(part_end != -1){
								part_end += part_mark.length;
							}
						}else{
							part_end = -1;
						}
						if(2 === k && -1 === part_end){
							// 1個しかないので分割しない
							break;
						}else{
							multi_match = true;
						}
						var part_end2 = part_end;
						if(-1 === part_end2){
							part_end2 = file.text.length;
						}else{
							part_end2 -= part_mark.length;
							if(pos_end + 1 < file.text.length && file.text.charAt(pos_end) === '\n'){
									pos_end += 1;
							}
							if(pos_end + 1 < file.text.length && file.text.charAt(pos_end) === '\n'){
									pos_end += 1;
							}
						}
						page.text = file.text.substr(pos_end, part_end2 - pos_end);
						newbook.push(page);
					}
					if(multi_match){
						complete = true;
					}
				}
			}
			if(!complete){
				var ret = file.text.match(/^[■□◆◇▼▽▲△●○]/m);
				if((split_type === 'auto' || split_type==='headsign') && ret && ret.index < 3000){
					var k = 1;
					var part_start = 0;
					var part_end = ret.index;
					var part_mark = '\n' + ret[0];
					var multi_match = false;
					while(-1 != part_end){
						var page = {};
						page.name = file.name;
						k++;
						var pos_start = part_end;
						var pos_end = file.text.indexOf('\n', pos_start);
						if(-1 != pos_end){
							var title = file.text.substr(pos_start, pos_end - pos_start);
							if( 20 < title.length ){
								title = title.substr(0, 30) + '..';
							}
							page.name += '/' + title;
							part_end = file.text.indexOf(part_mark, pos_end + 1);
							if(-1 != part_end){
								part_end += 1;
							}
						}else{
							part_end = -1;
						}
						if(2 === k && -1 === part_end){
							// 1個しかないので分割しない
							break;
						}else{
							multi_match = true;
						}
						var part_end2 = part_end;
						if(-1 === part_end2){
							part_end2 = file.text.length;
						}
						page.text = file.text.substr(part_start, part_end2 - part_start);
						newbook.push(page);
						part_start = part_end;
					}
					if(multi_match){
						complete = true;
					}
				}
			}
			if(!complete){
				var regex_str = get_id('split_regex_head').value;
				var regex_obj = null;
				var ret = null;
				var second_ret = null;
				try{
					if(split_type==='splitregex'){
						regex_obj = new RegExp(regex_str, 'mg');
						ret = regex_obj.exec(file.text);
						if(ret){
							second_ret = regex_obj.exec(file.text);
						}
					}
				}catch(e){
					alert('正規表現指定がエラーです。\n' + regex_str + '');
				}
				if(second_ret && ret.index < 3000){
					var k = 1;
					var part_start = 0;
					var part_end = ret.index;
					var part_mark = ret[0];
					var test = [];
					while(ret){
						test.push(part_end);
						var page = {};
						page.name = file.name;
						k++;
						if(second_ret){
							ret = second_ret;
							second_ret = null;
						}else{
							ret = regex_obj.exec(file.text);
						}
						var part_end2;
						if(ret){
							part_end = ret.index;
							part_end2 = part_end;
						}else{
							part_end2 = file.text.length;
						}
						page.text = file.text.substr(part_start, part_end2 - part_start);
						newbook.push(page);
						part_start = part_end;
					}
					complete = true;
				}
			}
			var filename_org = file.name;
			if(split_type === 'concat'){
				var limit = filename_max;
				if(20 < limit){
					limit = 20;
				}
				if(file.name.length < limit){
					file.name = (file.name + '____________________').substr(0, limit);
				}
			}
			if(!complete){
				if(-1 != filename_org.search(/^N([0-9]{4})([A-Z]{2})\-([\d]+)\.txt$/i)){
					var separeter = '\n********************************************\n';
					var head = file.text.indexOf(separeter);
					var pos_start = 0;
					if(head != -1 && head < file.text.length / 3){
						pos_start = head + separeter.length;
					}
					if(-1 == ' \t\n　'.indexOf(file.text.charAt(pos_start))){
						var pos_end = file.text.indexOf('\n', pos_start);
						if(pos_end != -1){
							var title = file.text.substr(pos_start, pos_end - pos_start);
							if( 20 < title.length ){
								title = title.substr(0, 20) + '..';
							}
							file.name += '/' + title;
						}
					}
				}
			}
			if(split_type === 'concat'){
				if(!from_split_area){
					var num = '';
					if(10 <= book.length && i + 1 <= 9){
						num = '_';
					}
					if(100 <= book.length && i + 1 <= 99){
						num += '_';
					}
					num += i + 1;
					concat_text.push('\n' + concat_head + num + '/' + file.name + '\n');
				}
				concat_text.push(file.text);
				complete = true;
			}
			if(!complete){
				newbook.push(file);
			}
			book[i] = null;
		}
		if(split_type === 'concat'){
			var page = {};
			page.text = concat_text.join('\n');
			page.name = concat_page_name;
			newbook.push(page);
		}
		book = newbook;
	}
	get_id('start').value = button_start_val + '&メモリ更新';
	get_id('page_name').value = 'ページ' + (book.length + 1);
}

function concat_pages(){
	var concat_text = [];
	var concat_head = get_id('concat_head').value;
	var filename_max = 0;
	for(var i = 0; i < book.length; i++){
		var file = book[i];
		var re = file.name.match(/^([^\\\/<>:\*\?]+)\//);
		if(re && filename_max < re[1].length){
			filename_max = re[1].length;
		}
	}
	for(var i = 0; i < book.length; i++){
		var file = book[i];
		var num = '';
		if(10 <= book.length && i + 1 <= 9){
			num = '_';
		}
		if(100 <= book.length && i + 1 <= 99){
			num += '_';
		}
		num += i + 1;

		var limit = filename_max;
		if(20 < limit){
			limit = 20;
		}
		var name = file.name;
		var re = name.match(/^([^\\\/<>:\*\?]+)\//);
		if(re && re[1].length < limit){
			name = (re[1] + '____________________').substr(0, limit) + name.substr(re[1].length);
		}
		concat_text.push('\n' + concat_head + num + '/' + name + '\n');
		concat_text.push(file.text);
	}
	var page = {};
	page.name = concat_page_name;
	page.text = concat_text.join('\n');
	book = [];
	book.push(page);
	get_id('start').value = button_start_val + '&メモリ更新';
	get_id('page_name').value = 'ページ' + (book.length + 1);
	page_view(0);
}

function page_view(index){
	page_view_update(index, true);
}

function progress_box(){
	var myHeight = window.innerHeight - get_id('footers').clientHeight - 80;
	var output = '';
	if(0 < myHeight){
		output = '<div style="height:' + myHeight + 'px">解析中……</div>';
	}else{
		output = '解析中……';
	}
	return output;
}

function page_view_update(index, mode){
	current_page = index;
	if(mode){
		get_id('maintext').value = book[index].text;
	}
	get_id('result').innerHTML = progress_box();
	get_id('page_title').innerHTML = create_pages(index, true);
	get_id('page_title_tail').innerHTML = create_pages(index, false);

	if(last_check_type === 1){
		setTimeout(kanji_check, 30);
	}else{
		setTimeout(check_output, 30);
	}
}

function create_pages(index, top){
	var pages = '';
	if(top){
		pages += '<span id="filebar">ファイル制御：</span>　';
	}
	pages += '<input type="button" value="&lt;&lt;"';
	if(0 < index){
		pages += ' onclick="page_view(0);"';
	}else{
		pages += ' disabled';
	}
	pages += '>';
	pages += '<input type="button" value="＜"';
	if(0 < index){
		pages += ' onclick="page_view('+ (index - 1) +');"';
	}else{
		pages += ' disabled';
	}
	pages += '>';
	pages += '<input type="button" value="＞"';
	if(index < book.length - 1){
		pages += ' onclick="page_view('+ (index + 1) +');"';
	}else{
		pages += ' disabled';
	}
	pages += '>';
	pages += '<input type="button" value="&gt;&gt;"';
	if(index < book.length - 1){
		pages += ' onclick="page_view('+ (book.length - 1) +');"';
	}else{
		pages += ' disabled';
	}
	pages += '>';
	if(top){
		pages += '　<select id="book_page1">';
	}else{
		pages += '　<select id="book_page2">';
	}
	for(var i = 0; i < book.length; i++){
		pages += '<option value="' + i + '"';
		if(i == index){
			pages += ' selected';
		}
		pages += '>';
		pages += (i + 1) + '.' + html_escape(book[i].name);
		if(i == index){
			pages += '●';
		}
		pages += '</option>';
	}
	pages += '</select>';
	pages += '<input type="button" onclick="select_page(';
	if(top){
		pages += 'true';
	}else{
		pages += 'false';
	}
	pages += ');" value="移動">';
	if(top){
		pages += '　　<input type="button" value="全クリア" onclick="all_clear()">';
		if(1 < book.length){
			pages += '　<input type="button" value="ページ結合" onclick="concat_pages()">';
		}
	}
	return pages;
}

function select_page(top){
	if(top){
		page_view(parseInt(get_id('book_page1').value));
	}else{
		page_view(parseInt(get_id('book_page2').value));
	}
}

function start_check(){
	last_check_type = 0;
	start_check2();
}

function start_kanji_check(){
	last_check_type = 1;
	start_check2();
}

function start_check2(){
	if( -1 < current_page ){
		var page = book[current_page];
		var textarea = get_id('maintext').value.replace(/\r\n/g, '\n');
		if(textarea !== page.text){
			page.text = get_id('maintext').value;
			var up = str_update;
			if(-1 == page.name.indexOf(up)){
				page.name += up;
			}
		}
		page_view_update(current_page, false);
	}else{
		get_id('result').innerHTML = progress_box();
		get_id('page_title').innerHTML = '';
		get_id('page_title_tail').innerHTML = '';
		if(last_check_type === 1){
			setTimeout(kanji_check, 30);
		}else{
			setTimeout(check_output, 30);
		}
	}
}

function area_clear(){
	document.mainform.maintext.value = "";
}

function all_clear(){
	area_clear();
	current_page = -1;
	book = [];
	get_id('start').value = button_start_val;
	get_id('page_title').innerHTML = '';
	get_id('page_title_tail').innerHTML = '';
	get_id('result').innerHTML = '';
	get_id('page_name').value = 'ページ' + 1;
}

function area_sample(){
	var sample = '';
	sample += '　ある日、空らかユーフォーが降っていいた。\n';
	sample += 'そなん馬鹿なとこがあとは思わなだろうが、家の屋根に刺さってがいる。\n';
	sample += '「おはようごさいます。ご主人様」\n';
	sample += 'グレイが出てかてそう言った。\n';
	sample += '　ある日、空からユーフォーが降ってきた。\n';
	sample += 'そんな馬鹿なことがあるとは思わないだろうが、家の屋根に刺さっている。\n';
	sample += '「おはようございます。ご主人様」\n';
	sample += 'グレイが出てきてそう言った。\n';
	document.mainform.maintext.value = sample;
}

function add_page(){
	var page = {};
	page.name = get_id('page_name').value;
	page.text = get_id('maintext').value;
	book[book.length] = page;
	get_id('page_name').value = 'ページ' + (book.length + 1);
	page_view_update(book.length - 1, true);
}

function dic_change(){
	var disp = 'none';
	if(document.getElementById('book').value != 'include'){
		disp = 'block';
	}
	document.getElementById('userdic').style.display = disp;
	document.getElementById('userdicinfo').style.display = disp;
	if( disp === 'none' ){
		document.getElementById('dicinfo').style.display = 'none';
	}
}

function user_view(){
	var disp = 'none';
	if(document.getElementById('dicinfo').style.display == 'none'){
		disp = 'block';
	}
	document.getElementById('dicinfo').style.display = disp;
}


function fixnum(i){
	return ("_____" + i).substr(-6);
}
function dummy_hiradic_org(){}
const hiradic_org = 
`ぁ、
あ/五段カ
あ/五段ラ
あ/五段ワ
あ、
あぁ
ああ
ああい/五段ワ
ああした
ああしたまえ
ああして
ああしろ
ああすれば
ああそう
ああっ、
ああっ。
ああなの
ああなりゃ
ああなりゃあ
ああなる
ああなるか
ああなるかしら
ああなるから
あいうえお
あいさつ
あいつ
あいつら
あいにく
あいまい
あえ/五段ガ
あえて
あお/五段ラ
あお/形容詞
あか/形容詞
あからさま
あかる/形容詞
あかん
あが/五段カ
あが/五段ラ
あきらか
あきらめ
あきらめ/下一段
あきらめて
あきらめる
あきれ/下一段
あくせく
あくどい
あくび
あくまで
あくる日
あぐね/下一段
あぐら
あけ/下一段
あげ
あげ/下一段
あげく
あげたまえ
あこがれ/下一段
あこぎな
あご
あさ/五段ラ
あさまし/形容詞
あざ
あざと/形容詞
あざ笑/五段ワ
あしからず
あしら/五段ワ
あしらわれ/下一段
あずか/五段ラ
あずけ/下一段
あせ/下一段
あそ/五段バ
あそこ
あそこから
あた/五段ラ
あたい
あたかも
あたくし
あたし/人称名詞
あたしゃ
あたたか/形容詞
あたため/下一段
あたふた
あたらし/形容詞
あたりさわり
あだ名
あちこち
あちゃぁ
あちゃあ
あちゃー
あちら
あっ
あっけ
あっけない
あっけなかった
あっけなく
あっけに
あっけらかん
あっさり
あっそう
あったま/五段ラ
あっち
あっちこち
あっと
あっというまに
あっぱれ
あつ/形容詞
あつま/五段ラ
あつめ/下一段
あつらえ/下一段
あて
あて/下一段
あてが/五段ワ
あでやか
あと
あどけ
あながち
あなた
あの
あのころ
あはは
あばら家
あひる
あび/上一段
あびせ/下一段
あふれ/下一段
あふれんばかり
あぶ/五段ラ
あぶく
あぶな/形容詞
あぶみ
あま/五段ラ
あま/形容詞
あますところ
あまた
あまつさえ
あまねく
あまり
あまりない
あみだくじ
あや/五段サ
あやうく
あやか/五段ラ
あやつ/五段ラ
あやつ/人称名詞
あやふや
あやま/五段ラ
あやめ
あら
あら/五段ワ
あらかじめ
あらかた
あらすじ
あらたな
あらたに
あらば
あらま
あらまぁ
あらまあ
あらゆる
あらら。
あられもない
あらわ
あり
ありうる
ありえない
ありえる
ありか
ありかも
ありがた/形容詞
ありがたがる
ありがたみ
ありがたや
ありがち
ありがと
ありがとう
ありがとな
ありがとね
ありきたり
ありげ
ありさま
ありす
ありすぎ
ありすぎて
ありすぎる
ありったけ
ありっちゃあり
ありふれ/下一段
ありましたら
ありゃ
ありゃあ
ありゃりゃ
ある
ある/五段カ
あるいは
あるか
あるかしら
あるから
あるきっかけ
あるじ
あるとき
あるとは
あるまい
あるまじき
あるよ
あるよう
あるわ
あるわけ
あるわよ
あるん
あるんか
あれ
あれぇ
あれど
あれどう
あれどっち
あれば
あれま
あれよ
あれより
あれら
あれれ
あろう
あわされ/下一段
あわただし/形容詞
あわてて
あわや
あわよくば
あわれ
あんかけ
あんぐり
あんぜんな
あんた/人称名詞
あんだけ
あんだよ
あんだろう
あんちゃん
あんとき
あんな
あんなふう
あんなら
あんま
あんまり
あー
い/上一段
い/五段イク
い/五段ラ
い/五段ワ
い〈
いい
いいえ。
いいかが
いいぞ
いいだしっぺ
いいだろ
いいだろう
いいっこなし
いいなぁ
いいなり
いいよ
いいよう
いいように
いいわ
いいわけではない
いいんじゃ
いえ〈、
いえあの〈、
いえその〈、
いえーい
いお、
いおさめ
いか/五段サ
いかが
いかがなもの
いかがわし/形容詞
いかつい
いかなる
いかに
いかれ/下一段
いかん
いかんよ
いきさつ
いきなり
いきやがった
いきやがったり
いきやがる
いくつ
いくつか
いくつかの
いくつから
いくつも
いくつもの
いくつもり
いくどか
いくばく
いくばくか
いくら
いくらかまし
いけしゃあしゃあ
いささか
いざ
いざこざ
いざという
いざとなると
いざとなれば
いじ/五段ラ
いじく/五段ラ
いじけ/下一段
いじめ/下一段
いじめっ子
いじめられっ子
いじらし/形容詞
いじわる
いずれ
いずれか
いせかい
いそ/五段ガ
いそう
いそがし/形容詞
いそし/五段マ
いた
いた/五段サ
いた/形容詞
いたずら
いただ/五段カ
いたちごっこ
いたとて
いたの
いたのか
いたぶる
いたまえ
いたるところ
いたんだ、
いたんだぞ、
いだ/五段カ
いち、
いちおう
いちご
いちばん
いちゃ
いちゃいけ
いちゃいちゃ
いちゃいます
いちゃもん
いっこ
いっさい
いっしょ
いっそ
いっそう
いっそのこと
いったい
いったん
いっちばーん
いっちょ
いっつも
いってきます
いってきまーす
いってらっしゃい
いってらっしゃーい
いっとき
いっとこ
いっぱい
いっぺん
いっぽう
いっ切
いつ
いつか
いつから
いつぞや
いつつ
いつのまに
いつのまにか
いつまで
いつまでも
いつも
いて
いてちゃ
いとまがない
いとも簡単
いとわない
いな/五段サ
いななき
いばら
いびつ
いびり
いぶかし/五段マ
いぶかし/形容詞
いぶかしげ
いま
いまい
いまいち
いまかいまか
いまさら
いましがた
いますぐ
いまだ
いまどき
いまに
いまは
いままで
いまや
いみじくも
いや
いや/形容詞
いやぁ
いやぁ、
いやあ、
いやが/五段ラ
いやしさ
いやしない
いやな
いやはや
いやらし/形容詞
いやん
いよう
いらした
いらして
いらだ/五段タ
いらだたし/形容詞
いらっしゃ/五段ナサル
いらっと
いらねぇ
いらねえ
いらねー
いら立
いるかつ
いるぞ
いるぞと
いるっちゃ
いれ/下一段
いれずに
いれば
いろいろな
いろんな
いわく
いわしめ
いわずとも
いわない
いわば
いわゆる
いわれ
いわれ/下一段
いわれのない
いわれはない
ぅ。
う/五段タ
う/五段マ
う/五段ラ
う、
うう、
ううん
うえ
うえ/下一段
うかが/五段ワ
うかつ
うかべ/下一段
うがい
うがち
うけ/下一段
うご/五段カ
うごか/五段サ
うごめ/五段カ
うさぎ
うさんくさ/形容詞
うさん臭
うざい
うざった/形容詞
うじゃうじゃ
うす/形容詞
うすぼんやり
うすら
うず/五段カ
うずくま/五段ラ
うずめ/下一段
うそ
うそでしょ
うそぶ/五段カ
うた/五段ワ
うたた寝
うだ/五段ラ
うだつ
うち
うちら
うっ、
うっかり
うっすら
うっせえ
うっそう
うっちゃ/五段ラ
うっと
うっとうし/形容詞
うっとり
うっぱら/五段ワ
うっぷん
うつ
うつくし/形容詞
うつつ
うつぶせ
うつむ/五段カ
うつらうつら
うつろ
うつろ/五段ワ
うとまし/形容詞
うどん
うな/五段ラ
うなが/五段サ
うなぎ
うなされ/下一段
うなじ
うなず/五段カ
うなずきあう
うなだれ/下一段
うな重
うぬぼれ/下一段
うね/五段ラ
うひょ
うふふ〈、
うぷっと
うへぇ、
うへえ、
うま/形容詞
うまくい/五段イク
うまみ
うまれ/下一段
うま味
うま塩
うむ
うめ/五段カ
うめえ
うめたて/下一段
うやうやし/形容詞
うやむや
うら/五段マ
うらやま
うら若
うるさ/形容詞
うるせぇ
うるせえ
うれ/下一段
うれし/形容詞
うろたえ/下一段
うろちょろ
うろつ/五段カ
うろつきまわ/五段ラ
うろ覚
うわ〈、
うわぁ
うわあ
うわごと
うわさ
うわっ
うわばみ
うん
うん、
うんざり
うんたら
うんち
うんちく
うんにゃ
うんぬん
うーむ
うーん
ぇ、
え/下一段
え、
えぇ、
ええ
ええい
ええよ
えくぼ
えぐ/五段ラ
えぐい
えぐみ
えげつない
えこひいき
えっ
えっち
えっちらおっちら
えっと
えっへん
えへへ
えへへへ
えら/五段バ
えら/形容詞
えんどう
えー、
えー。
えーじゃあ
えーっと
えーと
ぉ、
お/五段カ
お/五段サ
お/五段ラ
お/五段ワ
お、
おあいにく
おあずけ
おあつらえ/下一段
おい。
おいくら
おいし/形容詞
おいそれ
おいち
おいちい
おいてきぼり
おいてけぼり
おいで
おいといて
おいら/人称名詞
おぅ、
おう、
おうち
おうよ
おぉ、
おお/形容詞
おお、
おおう
おおき/形容詞
おおざっぱ
おおせ/下一段
おおっと
おおっぴら
おおまか
おおむね
おおよそ
おおらか
おおわれ/下一段
おか/五段サ
おかあさま
おかあさん
おかえり
おかけ/下一段
おかげ
おかげん
おかし
おかし/形容詞
おかず
おかみさん
おかめ
おかゆ
おかわり
おかんむ/五段ラ
おき/上一段
おぎゃぁ
おぎゃあ
おぎゃー
おく/五段ラ
おくび
おくれ
おくれ/下一段
おこ/五段サ
おこがましい
おこっと
おこな/五段ワ
おこぼれ
おご/五段ラ
おさげ
おさま/五段ラ
おさめ/下一段
おさらい
おさらば
おさんぽ
おざなり
おし/形容詞
おしえ/下一段
おしおき
おしっこ
おしどり
おしぼり
おしまい
おしめ
おしゃか
おしゃぶり
おしゃべり
おしゃれ
おしらせ
おしり
おじ
おじい
おじさま
おじさん
おじゃま
おじゃん
おすすめ
おすそ
おせっかい
おそ/形容詞
おそば
おそらく
おそるおそる
おそれ
おそろい
おそろし/形容詞
おぞまし/形容詞
おたく/人称名詞
おだて
おだて/下一段
おち
おち/上一段
おちゃめ
おちゃらけ/下一段
おちょく/五段ラ
おちんちん
おっ、
おっかな/形容詞
おっかなびっくり
おっき/形容詞
おっきな
おっくう
おっさん
おっしゃ/五段ナサル
おっす
おっちゃん
おっちょこちょい
おっと
おっとり
おっぱい
おっぱじめ
おっぱじめ/下一段
おつかれ
おつまみ
おつもり
おつゆ
おでこ
おでん
おと/五段サ
おとうさま
おとうさん
おとがめ
おとぎ
おとずれ/下一段
おとなし/形容詞
おとり
おど/五段ラ
おどか/五段サ
おどけ
おどけ/下一段
おどろおどろしい
おどろ木
おなか
おなご
おなじ
おなじみ
おにぃさん
おにぃちゃん
おにい
おにいさん
おにいちゃん
おにぎり
おにーさん
おにーちゃん
おぬし/人称名詞
おねぇさん
おねえ
おねえさん
おねがい
おねだり
おねーさん
おのず
おのの/五段カ
おのれ
おはぎ
おはよ
おはよう
おはようございます
おば
おばあ
おばさん
おばちゃん
おぱんつ
おひさし
おひざ元
おひたし
おひとつ
おひとり
おひねり
おびえ/下一段
おびき
おびただし/形容詞
おふくろ
おふたり
おへそ
おべっか
おほほほ
おほほほほ
おほほほほほ
おぼえ/下一段
おぼつかない
おぼれ/下一段
おぼろげ
おまえ/人称名詞
おまかせ
おまかわ
おまけ
おまじない
おまたせ
おままごと
おまる
おまわり
おみくじ
おみまい
おみやげ
おむすび
おむつ
おめぇ
おめえ
おめえぇ
おめおめ
おめでた/形容詞
おめでと
おめでとう
おめにかか/五段ラ
おめめ
おめー
おも/五段ワ
おも/形容詞
おもいっきり
おもしれー
おもしろ/形容詞
おもちゃ
おもてなし
おもね/五段ラ
おもむろ
おもわず
おや、
おやじ
おやすみ
おやすみぃ
おやすみなさい
おやすみなさーい
おやつ
おやまあ
おやめ
およ/五段ガ
およし
およそ
および
およぶ
おり/上一段
おれ/下一段
おろ/五段サ
おろか
おろそか
おわかり
おんなじ
おんぶ
おんぼろ
おー、
おー。
おーい
お兄
お姉
お母
お父
お膝元
お茶
お菓子
か
か/五段カ
か/五段サ
か/五段タ
か/五段マ
か/五段ワ
か。
かあちゃん
かい、
かいくぐ/五段ラ
かいね
かいねえ
かえ/下一段
かえ/五段サ
かえ/五段ラ
かか/五段ラ
かかあ
かかげ/下一段
かかりっきり
かかわ/五段ラ
かが
かが/五段マ
かがめ/下一段
かきあげ/下一段
かきむし/五段ラ
かき分
かぎり
かぎ裂
かくいう
かくかくしかじか
かくして
かくれんぼ
かぐわし/形容詞
かけ
かけ/下一段
かけっこ
かけら
かけらも
かさば/五段ラ
かさり
かざ/五段サ
かざ/五段ラ
かしげ/下一段
かしこま/五段ラ
かしず/五段カ
かしら
かじ/五段ラ
かす/五段ラ
かすか
かすかな
かすかに
かすむ
かすめ/下一段
かすめた
かすら
かすりもしない
かぞえ/下一段
かた
かた/形容詞
かたじけない
かたじけねぇ
かたち
かたづ/五段カ
かたづけ/下一段
かたど/上一段
かちあ/五段ワ
かっこ
かっこいい
かっこよく
かっこわる/形容詞
かっこ悪
かっこ良
かっさば/五段カ
かっさら/五段ワ
かっさらわれ/下一段
かった
かったか
かったかしら
かったから
かったし
かったら
かったらし/形容詞
かったり
かっちょ
かっちょ悪
かっちり
かっぽじ/五段ラ
かつ
かつて
かと
かどうか
かな/五段ワ
かな、
かなぁ
かなあ、
かなえ/下一段
かなぐり
かなし/形容詞
かなり
かね/下一段
かねえ、
かねがね
かの。
かのぅ、
かのう、
かのぉ、
かのお、
かのよう
かは
かば/五段ワ
かばん
かぶ/五段ラ
かぶさ/五段ラ
かぶせ/下一段
かぼす
かぼちゃ
かま/五段サ
かま/五段ワ
かまで
かまど
かみしめ/下一段
かも
かもしれ
かもしれない
かもしれぬ
かもしれん
かゆ/形容詞
かゆし
かよ/五段ワ
かよ、
から
から/五段マ
から/形容詞
からいる
からか/五段ワ
からかめちゃくちゃ
からがら
からきし
からくり
からしつこい
からしつこく
からず
からずれて
からずっと
からっきし
からっぽ
からな、
からね、
からよ、
からり
かり/上一段
かる/形容詞
かれこれ
かろうじて
かわ/五段カ
かわ/五段サ
かわ/五段ラ
かわい/形容詞
かわいが/五段ラ
かわいそう
かわいらし/形容詞
かを
かんがえ/下一段
かんじ
かんたん
かんたんな
かんだ
かんな
かんね
かんぴょう
が
が/五段ラ
がか/五段ラ
がくり
がけ
がけず
がけない
がしゃん
がしら
がぜん
がた/形容詞
がたまたま
がち
がちゃ
がちゃがちゃ
がっかり
がっくし
がっくり
がっこう
がっしり
がっちり
がっつ/五段カ
がっつり
がっぽ
がっぽり
がてら
がぶ飲
がまし/形容詞
がむしゃら
がめつい
がゆい
がらみ
がらりと
がら空
がれき
がんば/五段ラ
がーん
き/上一段
き/五段カ
き/五段ラ
きえ/下一段
きがつ/五段カ
きけんな
きこえ/下一段
きさま
きし/五段マ
きしめん
きそう
きた
きたい
きたす
きたな/形容詞
きたまえ
きたら
きたり
きたんでしょ
きたんです
きちっと
きちゃい
きちゃいけない
きちゃう
きちゃえば
きちゃおう
きちゃった
きちん
きちんと
きっかけ
きっかり
きっちり
きっと
きっぱり
きっぷ
きつ/形容詞
きつめ
きて
きてた
きてる
きなさい
きのう
きのこ
きびし/形容詞
きま/五段ラ
きました
きまして
きましょう
きます
きません
きめ/下一段
きもち
きゃあ
きゃいきゃい
きゃっ
きゃっきゃ
きゃー
きやがった
きやがりました
きやがります
きやがりますか
きやがりますから
きやがる
きゅうり
きゅっと
きゅん
きゅんと
きょうび
きょときょと
きょとり
きょとん
きょろきょろ
きょろり
きらい
きらいがある
きらいな
きらびやか
きらめ/五段カ
きらり
きりもみ
きりり
きれ
きれ/下一段
きれい
きれいな
きわど/形容詞
きわめて
きをつけ/下一段
きをてら/五段ワ
きんぴら
ぎくしゃく
ぎこちな/形容詞
ぎっくり腰
ぎっこん
ぎっしり
ぎったん
ぎっちぎち
ぎっちり
ぎみ
ぎゃあ
ぎゅうぎゅう
ぎゅって
ぎゅっと
ぎょっと
ぎょろり
ぎらつ/五段カ
ぎるど
ぎんちゃく
く/五段マ
く/五段ワ
くく/五段ラ
くぐ/五段ラ
くぐも/五段タ
くぐり抜
くさ
くさ/形容詞
くさ/五段ラ
くしゃくしゃ
くしゃっと
くしゃみ
くじ
くじけ/下一段
くじら
くす/五段マ
くすぐ/五段ラ
くすぐった/形容詞
くすっと
くすね/下一段
くすぶ/五段ラ
くすり
くすん
くずおれ/下一段
くせ
くそ
くそう
くたば/五段ラ
くたびれ/下一段
くだ/五段ラ
くださ/五段ナサル
くださ/五段ワ
くだん
くちばし
くちゃくちゃ
くちゅくちゅ
くっ〈、
くっきり
くっそ
くっちゃべ/五段ラ
くっつ/五段カ
くっ付
くつ、
くつがえ/五段サ
くつろ/五段ガ
くつわ
くど/形容詞
くね/五段ラ
くの字
くぱぁ
くぱあ
くぱって
くぱっと
くびれ/下一段
くべ/下一段
くぼ/五段マ
くまさん
くまなく
くみたて/下一段
くも/五段ラ
くゆらせ/下一段
くら/五段サ
くら/五段マ
くら/五段ワ
くら/形容詞
くらいなもの
くらって
くらっと
くらべ/下一段
くらま/五段サ
くらり
くりぬ/五段カ
くりゃ
くりゃぁ
くりゃあ
くり抜
くる
くるぶし
くるり
くるんと
くれ
くれ/下一段
くれぐれ
くれぐれも
くれそう
くれば
くれるか
くれるかしら
くろ/形容詞
くわえ/下一段
くわし/形容詞
くわって
くわっと
くわない
くん
くんかくんか
くんです
くノ一
ぐいって
ぐいっと
ぐいと
ぐうたら
ぐうの音
ぐさって
ぐさっと
ぐしゃ
ぐしゃぐしゃ
ぐしゃり
ぐしょぐしょ
ぐじゃぐじゃ
ぐすん
ぐだつ/五段カ
ぐちゃぐちゃ
ぐちゃっと
ぐちゅぐちゅ
ぐちょぐちょ
ぐっすり
ぐったり
ぐっちゃぐちゃ
ぐって
ぐっと
ぐてんぐてん
ぐでって
ぐでっと
ぐにゃり
ぐぬぬ
ぐへへ
ぐらい
ぐらいのもの
ぐらつ/五段カ
ぐらり
ぐらんぐらん
ぐりん
ぐるって
ぐるっと
ぐるみ
ぐるり
ぐるる
ぐるるる
ぐるるるる
ぐわって
ぐわっと
ぐんって
ぐんっと
ぐーすか
け/下一段
け/五段サ
けがれ/下一段
けしかけ/下一段
けしからん
けして
けじめ
けたたまし/形容詞
けち
けっきょく
けっこう
けっして
けど
けどさ。
けな/五段サ
けりが
けりがつ/五段カ
けりつけ/下一段
けりを
けれど
けれども
ければ
けん制
げ〈
げっそり
げっぷ
げふん
げんきな
げんなり
こ/五段ガ
こ/五段マ
こ/形容詞
こい、
こいつ
こいつら
こう
こういう
こういっちゃ
こうし
こうしそう
こうした
こうしたら
こうして
こうしてる
こうしろ
こうなりゃ
こうなりゃぁ
こうなりゃあ
こうなる
こうなるか
こうなるかしら
こうなるから
こうべ
こおろぎ
こき使
こぎつけた
こぎつける
こくり
こくん
こけ/下一段
こけおどし
こげ茶
ここ
ここいら
ここか
ここから
ここぞ
ここのつ
ここら
こさせうる
こさせた
こさせつつ
こさせない
こさせながら
こさせる
こさせろ
こしあん
こしぎんちゃく
こしたことは
こしらえ
こしらえ/下一段
こじつけ
こじゃれ/下一段
こじらせ/下一段
こじれ/下一段
こじ付
こじ開
こす/五段ラ
こそ
こそあれ
こそあれど
こそすれ
こそすれど
こそばゆ/形容詞
こぞって
こたえ/下一段
こたつ
こだま
こだわ/五段ラ
こちとら
こちょこちょ
こちら
こぢんまり
こっから
こっそり
こった
こっち
こっちこい
こっちゃ
こっちゃない
こってり
こっぴどく
こつがあ/上一段
こつがあ/五段ラ
こつがい/五段ラ
こと
ことがある
ことごとく
ことば
こともなげ
ことやら
ことわざ
こな/五段サ
こない
こなかった
こなかったし
こなかったら
こなく
こなくて
こなくても
こなければ
こなごなに/ザ変
こねくり
こねる
この
このあいだ
このかた
このたび
このまま
こびり
こぶし
こほん
こほんっと
こぼ/五段サ
こぼれ
こぼれ/下一段
こま/五段サ
こま/五段ラ
こまか/形容詞
こまごま
こまめ
こまれ/下一段
こみ
こめかみ
こも/五段ラ
こやつ/人称名詞
こよう
こよなく
こら
こらえ
こらえて
こらえる
こられ
こられた
こられたら、
こられて
こられました
こられます
こられる
こりごり
こりゃ
こりゃぁ
こりゃあ
これ
これから
これしき
これず
これぞ
これた
これたのだが
これっきり
これっぽっち
これて
これでもか
これら
これる
ころ
ころっと
ころりと
ころん
こわ/五段サ
こわ/形容詞
こわば/五段ラ
こわれ/下一段
こん
こんがらが/五段ラ
こんがり
こんぐらい
こんだけ
こんど
こんな
こんなん
こんにちは
こんにゃく
こんばんは
こん棒
ご、
ごうかな
ごきげんよう
ごきって
ごきっと
ごく
ごくまれ
ごくり
ござ/五段ナサル
ござ/五段ワ
ござらん
ごしらえ
ごしらえ/下一段
ごじゃる
ごたえ
ごたついて
ごたつく
ごちそう
ごちそうさま
ごちゃごちゃ
ごちゃ混
ごちょごちょ
ごちる
ごっくん
ごっこ
ごっそり
ごった煮
ごった返
ごっちゃ
ごつい
ごと
ごとき
ごとく
ごとりと
ごにょごにょ
ごね/五段ラ
ごはん
ごひいき
ごほん
ごほん〈、
ごぼう
ごまか/五段サ
ごまん
ごみ
ごめん
ごめんなさい
ごもっとも
ごゆっくり
ごらん
ごらんにな/五段ラ
ごり押
ごろ
ごろつき
ごろん
さ
さ/五段カ
さ/五段サ
さ、
さ〈
さぁ
さぁ、
さぁこれ
さあ、
さあこれ
さあな
さあね
さいころ
さえ
さえぎ/五段ラ
さえず/五段ラ
さえずり
さえも
さえもら/五段ワ
さかのぼ/五段ラ
さが/五段サ
さが/五段ラ
さきほど
さくって
さくっと
さくら
さげ/下一段
ささくれ
ささげ/下一段
ささって
ささっと
ささや/五段カ
ささやか
さざなみ
さざめ/五段カ
さざ波
さしあたって
さしずめ
さしたる
さしもの
さじ
さす/五段ラ
さすが
さず
させうる
させた
させつつ
させながら
させる
させろ
さそ/五段ワ
さぞ
さっき
さっきから
さっくり
さっさと
さっそく
さって
さっと
さっぱり
さつま揚
さて
さておき
さなか
さながら
さなぎ
さにも
さば/五段カ
さばき
さび/下一段
さびし/形容詞
さびれ/下一段
さほど
さぼ/五段ラ
さま
さまざま
さまよ/五段ワ
さみし/形容詞
さむ/形容詞
さめ/下一段
さめざめ
さもなくば
さやか
さよう
さようなら
さら
さら/五段サ
さら/五段ワ
さらしかねない
さらって
さらっと
さらなる
さらに
さらば
さらり
さりげな/形容詞
さりとて
さり気
さる、
さること
され
されず
されそう
された
されたい
されたがる
されたく
されたくて
されたら
されたり
されちゃ
されちゃう
されて
されてた
されてたり
されてちゃ
されてる
されど
されない
されぬ
される
されるか
されるかしら
されるから
さわ/五段ガ
さわ/五段ラ
さわやか
さん
さんざっぱら
さんざん
さんしょの木
さんっ子
さんぽ
さんら
さーん
ざくって
ざくっと
ざく切
ざっくばらん
ざっくり
ざって
ざっと
ざま
ざまぁ
ざまぁみろ
ざまあ
ざまあない
ざまあみろ
ざまーみろ
ざら
ざらい
ざる
ざわ、
ざわっ、
ざわつ/五段カ
ざわめ/五段カ
ざわり
ざんばら
し
し/五段ナ
し/五段ラ
しあ/五段ワ
しあわせな
しい
しいて
しおらし/形容詞
しおり
しか
しか/五段ラ
しかか/五段ラ
しかけ/下一段
しかし
しかした
しかしながら
しかたありませぬ
しかたありません
しかたが
しかたがありませぬ
しかたがありません
しかたがない
しかたがなく
しかたな
しかたない
しかたなく
しかった
しかったし
しかったら
しかったらし/形容詞
しかったり
しかない
しかねない
しかねません
しかねる
しかめ/下一段
しかも
しかり
しかるべき
しが/五段ラ
しがた/形容詞
しがち
しがな/形容詞
しがみ
しがみつ/五段カ
しがらみ
しきたり
しきり
しく
しくじ/五段ラ
しくて
しくない
しぐさ
しぐれ
しげに
しこたま
しこり
しご/五段カ
しさ
しすぎず
しすぎて
しすぎる
しずかな
しそう
しそびれ/下一段
した
したい
したか
したかしら
したから
したが/五段ラ
したきり
したく
したくて
したたか
したっきり
したて
したまえ
したやつ
したやつら
したら
したり
しだ/五段サ
しだす
しちまいたい
しちまう
しちまえ
しちまおうか
しちゃ
しちゃ/五段ワ
しちゃいけず
しちゃいけない
しちゃいや
しちゃいやだ
しちゃだめ
しっかり
しっくり
しっとり
しっぱなし
しっぺ返
しっぽ
しつけ/下一段
しつこ/形容詞
しつっこ/形容詞
しつつ
して
してい/下一段
してい/五段イク
していきなり
していただ/五段カ
していつでも
してくる
してくれ
してくれず
してくれた
してくれたまえ
してくれたら
してくれたり
してくれて
してくれていた
してくれている
してくれてる
してくれる
してた
してたまるもの
してたら
してちゃ
してて
してや/五段ラ
してやんよ
してる
してろ
してんな
してんの
してんのか
しでか/五段サ
しといた
しといたら
しといて
しときましょう
しときゃ
しとく
しとけ
しとけば
しとこ
しとこう
しどろもどろ
しな
しな/五段ラ
しなあ、
しない
しないか
しないから
しないん
しながら
しなきゃ
しなく
しなくちゃ
しなくて
しなくな/五段ラ
しなくなって
しなくもない
しなさい
しなやか
しなやかな
しにくい
しにくく
しね、
しねえ、
しの/五段ガ
しのばれ
しのばれる
しのぶ
しはじめ
しはじめ/下一段
しば/五段カ
しばし
しばらく
しびれ/下一段
しぶき
しぶと/形容詞
しぼ/五段マ
しま/五段ラ
しま/五段ワ
しまく/五段ラ
しました
しまして
しましょ
しましょう
します
しません
しまった
しまったし
しまったら
しまったらし/形容詞
しまったり
しまって
しまってた
しまってる
しまーす
しみ/上一段
しみじみ
しめ/下一段
しゃあしゃあ
しゃが/五段マ
しゃがれ/下一段
しゃきしゃき
しゃくし
しゃくり
しゃしゃり
しゃぶ/五段ラ
しゃぶしゃぶ
しゃべ/五段ラ
しゃれ
しゃれ/下一段
しゃんとして
しやが/五段ラ
しやす/形容詞
しやすくて
しゅう
しゅうない
しゅんと
しょう
しょうか
しょうから
しょうがない
しょうゆ
しょげ
しょせん
しょっちゅう
しょっぱ/形容詞
しょっぱな
しょぼ/形容詞
しょぼしょぼ
しょぼん
しょもしょも
しょんぼり
しよう
しようぜ
しよっか
しよっと
しよる
しらせ/下一段
しらっと
しらばっくれ/下一段
しらべ/下一段
しらみつぶし
しらみ潰
しりあ/五段ワ
しり目
しれっと
しれない
しれぬ
しれません
しろ
しろ/形容詞
しろよ
しわ
しわくちゃ
しんじ/上一段
しんせつな
しんと静
しんど/形容詞
しんぱいな
しんみり
じぃさん
じぃちゃん
じいさん
じいちゃん
じきに
じじい
じた
じたい
じたばた
じっくり
じっと
じっとり
じて
じとり
じと目
じない
じなかった
じなく
じなければ
じまい
じみ/下一段
じみた
じめって
じめっと
じゃ
じゃぁ
じゃあ
じゃありません
じゃあるまい
じゃが
じゃがいも
じゃがな
じゃじゃん
じゃじゃーん
じゃじゃ馬
じゃった
じゃって
じゃな、
じゃない
じゃないよ
じゃないよう
じゃないわ
じゃね
じゃねぇ
じゃねえ
じゃねーか
じゃねーと
じゃねーの
じゃねーよ
じゃねーわ
じゃねーんだ
じゃねーんだよ
じゃねーんだわ
じゃまな
じゃよ。
じゃれ
じゃろ、
じゃろう
じゃわ
じゃん
じゅう
じゅうたん
じゅうぶんな
じゅる
じゅるり
じゅるる
じゅわっと
じゅわり
じゆうな
じょうずな
じょうぶな
じりって
じりっと
じり貧
じる
じれ/下一段
じろり
じわって
じわっと
じわり
じんと
じんわり
じーさん
じーちゃん
じーって
じーっと
す/五段カ
す/五段マ
す/五段ラ
すうって
すうっと
すえかねた
すえかねて
すえかねる
すえた臭
すかさず
すが/五段ラ
すがすがしい
すがすがしく
すがろう
すきな
すき焼
すぎ
すぎ/上一段
すぎず
すぎて
すぎてる
すぎない
すぎる
すく/五段マ
すく/五段ワ
すくな/形容詞
すくめ/下一段
すぐ
すぐさま
すぐに
すぐには
すぐれて
すげぇ
すげえ
すげな/形容詞
すげない
すげー
すこし
すこぶる
すご/五段サ
すご/形容詞
すごすぎ/上一段
すごーい
すごーく
すさまじ/形容詞
すさん
すす/五段マ
すす/五段ラ
すすけ
すすって
すすっと
すすり
すずし/形容詞
すずめ
すたこらさっさ
すだ/五段タ
すっからかん
すっかり
すっきり
すっご/形容詞
すって
すっと
すっとぼけ
すっとぼけ/下一段
すっぱ/形容詞
すっぱり
すっぴん
すっぽ
すっぽり
すっぽんぽん
すっ飛
すて/下一段
すてきな
すでに
すとん
すなわち
すね
すね/下一段
すのこ
すばしっこ/形容詞
すばらし/形容詞
すぱって
すぱっと
すべ/五段ラ
すべからく
すべき
すべきか
すべきかどうか
すべく
すべし
すべて
すぼま/五段ラ
すま/五段サ
すま/五段ワ
すまん
すみっこ
すみません
すみませーん
すみれ
すら
すらっと
すらり
すらりと
すりこぎ
すりつぶ/五段サ
すりゃ
すりゃぁ
すりゃあ
する
するか
するかしら
するから
するすべ
するっきゃ
するっと
すると
するとか
するとき
するとこ
するとこういう
するところ
するとは
するとはいえ
するなと
するのは
するやつ
するり
するん
すれども
すれば
すれ違
すわ/五段ラ
すわ〈、
すんご/形容詞
すんじゃ
すんぞ
すんとも
すんな
すんなり
すんの
すーはー
ずい
ずいぶん
ずうずうし/形容詞
ずうっと
ずくめ
ずしん
ずずい
ずっしり
ずっと
ずつ
ずばり
ずば抜
ずぶぬれ
ずぶ濡
ずぼら
ずら/五段サ
ずらか/五段ラ
ずらっと
ずらり
ずり、
ずり下
ずる
ずる/形容詞
ずるって
ずるっと
ずれ
ずれ/下一段
ずんぐり
ずんぐりむっくり
ずーっと
せい
せいか
せいかも
せいじょ
せいぜい
せいだ
せいだろう
せいで
せいです
せいら
せいろ
せが/五段マ
せがたか/形容詞
せき止
せき込
せこ/形容詞
せざるを
せしめ/下一段
せず
せずに
せせこまし/形容詞
せせらぎ
せせら笑
せっかく
せっかち
せっかん
せっせと
せっつ/五段カ
せつない
せて
せぬ
せねば
せび/上一段
せま/形容詞
せめぎ
せめて
せよ
せよう
せり上
せり出
せる
せるかどうか
せわしな/形容詞
せん
せーの
ぜ、
ぜぇ、
ぜったい
ぜひ
ぜんぶ
そ/五段ラ
そ/五段ワ
そいつ
そいつら
そう
そういう
そういうと
そういえば
そうか
そうかい
そうかしら
そうかも
そうした
そうしたい
そうしたく
そうしたまえ
そうしたら
そうして
そうしてる
そうしよ
そうしよう
そうしよっ
そうだ
そうだった
そうだったっけ
そうだったら、
そうっすね
そうとう
そうな/五段ラ
そうなの
そうよ
そがれ
そぎ落
そぐ/五段ワ
そげ/下一段
そこ
そこか
そこかしこ
そこかしら
そこから
そこで
そこです
そこでは
そこではたと
そこまで
そこら
そこらじゅう
そこんとこ
そしたら
そして
そしり
そそ/五段ガ
そそ/五段ラ
そそ〈、
そそくさ
そそそ
そそっかし/形容詞
そそのか/五段サ
そだて/下一段
そちら
そっか
そっくり
そっけな/形容詞
そっち
そっちのけ
そっと
そっぽ
そつな/形容詞
そなえ/下一段
そなた
そなたら
その
そのうえ
そのうち
そのため
そのまま
そば
そばだてて
そびえ
そびえ/下一段
そびれ/下一段
そぶり
そぼろ
そむ/五段カ
そゆこと
そよ/五段ガ
そよ風
そら/五段サ
そら〈
そりゃ
そりゃぁ
そりゃあ
それ
それから
それこそ
それじゃ
それじゃあ
それぞれ
それだけ
それだけど
それっきり
それっぽい
それで
それです
それでは
それでも
それとて
それとも
それともう
それどころか
それなのに
それなら
それならば
それなり
それに
それにもかかわらず
それは
そればかりか
そればかりでなく
それまで
それゆえ
それゆえに
それよか
それら
それらしき
それを
そろ/五段ワ
そろばん
そろり
そんくらい
そんぐらい
そんじゃ
そんじょ
そんだけ
そんで
そんとき
そんな
そんなふう
そんなやり取
そんなん
そん時
そん色
そーでした
そーです
そーゆー
ぞ、
ぞい
ぞぅ、
ぞう、
ぞぉ、
ぞお、
ぞくって
ぞくっと
ぞくり
ぞって
ぞっと
ぞろい
ぞわって
ぞわっと
ぞんざい
ぞんじ/上一段
た/五段タ
た。
た〈
たい
たいした
たいして
たいせつな
たいてい
たいへんな
たいまつ
たお/五段サ
たおれ/下一段
たか/五段ラ
たか/形容詞
たか。
たかが
たかだか
たが/五段ラ
たきゃ
たき火
たぎ/五段ラ
たくさん
たくとも
たくない
たくなかった
たくなかったら
たくなって
たくなる
たくはない
たくはなる
たくまし/形容詞
たくら/五段マ
たくわえ/下一段
たぐい
たげな
たこ焼
たしか
たしかに
たしかめ/下一段
たしな/五段マ
たじろ/五段ガ
たすか/五段ラ
たすけ/下一段
たずさえ/下一段
たそう
たぞ、
たた/五段カ
たた/五段マ
たた/五段ラ
たたえ/下一段
たたず/五段マ
たたっ斬
たたない
たたっと
ただ
ただいま
ただし
ただし/形容詞
ただちに
ただれ/下一段
たちまち
たちゃ
たっけ
たっぷり
たて/下一段
たとえ
たとえば
たど/上一段
たどたどし/形容詞
たどり着
たなび/五段カ
たの/五段マ
たのし/五段マ
たのし/形容詞
たび
たびに
たぶらか/五段サ
たぶん
たべ/下一段
たま/五段ラ
たまえ
たまげた
たまったものではない
たまったもんじゃない
たまに
たまには
たまねぎ
たまりにたまった
たむろ
ため
ため/下一段
ため/五段サ
ためし
ためすぐ
ために
ためにも
ためら/五段ワ
たやす/形容詞
たゆた/五段ワ
たゆん
たより
たら
たらず
たらふく
たり
たり/上一段
たる
たるもの
たるんで
たる者
たわ/五段マ
たわいない
たわいもない
たわごと
たわわ
たん
たんこぶ
たんたんと
たんぱく
だ
だ/五段サ
だ、
だ〈
だぁ。
だいこん
だいじょうぶ
だいじょうぶな
だいじょばない
だいじょーぶ
だいすきな
だいたい
だいぶ
だから
だからか
だからこそ
だかり
だかんな
だかんね
だが
だけ
だけか
だけかしら
だけかも
だけから
だけじゃなく
だけじゃなくて
だけだと
だけど
だけれど
だけれども
だし
だぜ。
だぞ、
だぞ。
だぞあれは
だっけ
だっこ
だった
だったか
だったかしら
だったから
だったし
だったっけ
だったら
だったらし/形容詞
だったり
だって
だってば
だってよ。
だてでは
だと
だとか、
だとしたら
だとしても
だな。
だなぁ
だなあ、
だなと
だなんて
だね。
だねえ
だの、
だのと
だぶつ/五段カ
だべ/五段ラ
だま/五段サ
だま/五段ラ
だめ
だめな
だめなら
だもの
だもん
だもーん
だよ。
だよぉ
だよな。
だよなあ
だよね。
だよん
だらけ
だらし
だらって
だらっと
だらり
だらん
だり
だる/形容詞
だるま
だれ
だれしも
だろ
だろう
だろうし
だわ。
だんまり
だんろ
ちいさ/形容詞
ちいさな
ちか/形容詞
ちが/五段ワ
ちぎ/五段ラ
ちくしょう
ちくせう
ちくっ
ちくって
ちくっと
ちくり
ちくわ
ちぐはぐ
ちげぇ
ちげえ
ちげー
ちっ、
ちっこ/形容詞
ちっさ/形容詞
ちっさい
ちったあ
ちったあぁ
ちったー
ちっちゃ/形容詞
ちっちゃな
ちっと
ちっぽけ
ちと
ちな/五段マ
ちひろ
ちび
ちび/上一段
ちびっこ
ちまう
ちまった
ちまったし
ちまったら
ちまったらし/形容詞
ちまったり
ちまっちゃ
ちまって
ちゃ/五段ワ
ちゃいけない
ちゃいない
ちゃいや
ちゃいる
ちゃだめ
ちゃちな
ちゃちゃちゃって
ちゃちゃちゃっと
ちゃちゃって
ちゃちゃっと
ちゃっかり
ちゃっちゃと
ちゃぶ
ちゃぶ台
ちゃら/形容詞
ちゃらんぽらん
ちゃん
ちゃんこ
ちゃんちゃら
ちゃんっ子
ちゃんと
ちゃーん
ちやほや
ちゅぱちゅぱ
ちょ〈、
ちょい
ちょいと
ちょうだい
ちょうちょ
ちょうちょう
ちょうど
ちょうどいい
ちょうどよ/形容詞
ちょくちょく
ちょこちょこ
ちょこって
ちょこっと
ちょこまか
ちょこん
ちょちょいと
ちょちょいのちょい
ちょちょって
ちょちょっと
ちょっ、
ちょっかい
ちょっくら
ちょっち
ちょっと
ちょっとばかし
ちょっぴし
ちょっぴり
ちょびっと
ちょろ/形容詞
ちょろい
ちょろちょろ
ちょろっと
ちょん切
ちら
ちら/五段サ
ちらって
ちらっと
ちらつく
ちらほら
ちらり
ちりばめ/下一段
ちりも積
ちりん
ちんけ
ちんたら
ちんちくりん
ちんぴら
ちんぷんかんぷん
っ、
っ。
っから
っけ
っしょ
っす、
っすか
っすよ
った
ったし
ったら
ったらし/形容詞
ったり
っち〈
っちま/五段ワ
っちゃ
っちゃ/五段ワ
っちゃいけない
っちゃいない
っちゃいや
っちゃだめ
っつーの
って
っている
ってた
ってたり
ってて
ってない
ってば
ってばっかり
ってる
ってんのか
っと
っぱなし
っぷり
っぽい
っぽかった
っぽく
っぽくて
っぽさ
っぽそう
つ/五段カ
つ/五段マ
つ/五段ラ
つい
ついぞ
ついで
ついでに
ついば/五段マ
つうーって
つうーっと
つか/五段マ
つか/五段ラ
つか/五段ワ
つか〈
つかの間
つかま/五段マ
つかれ/下一段
つがえ/下一段
つぎに
つぎはぎ
つぎ込
つく/五段サ
つく/五段ラ
つくづく
つくね
つぐ/五段マ
つけ
つけ/下一段
つけいる
つじつま
つたえ/下一段
つちか/五段ワ
つっかえ/下一段
つっけんどん
つつ
つつ/五段カ
つつ/五段マ
つつがなく
つづ/五段カ
つづけ/下一段
つとめ/下一段
つな/五段ガ
つないだ
つなが/五段ラ
つね/五段ラ
つば
つばさ
つぶ/五段サ
つぶ/五段ラ
つぶさ
つぶや/五段カ
つぶら
つぶらな
つぼ
つぼ/五段マ
つま/五段マ
つま/五段ラ
つまず/五段カ
つまらな/形容詞
つまるところ
つまんない
つまんね
つま先
つむ/五段ガ
つむ/五段ラ
つむじ
つめた/形容詞
つも/五段ラ
つゆ
つよ/形容詞
つら/形容詞
つられ/下一段
つり革
つる/五段マ
つるはし
つるり
つれてい/五段カ
つれない
つんざく
つんと
つんのめる
つーか
づか/五段ワ
づくり
づくろい
づけ
づけ/下一段
づま/五段ラ
づら/形容詞
て、
てい/五段イク
ていう
ていうか
ていけそうなら
ていねいな
ている
ているか
ているかしら
ているから
てか、
てか〈
てきとうな
てきぱき
てこいれ
てこずら
てこと
てた
てたら
てたらし/形容詞
てたり
てっきり
てっぺん
てつだ/五段ワ
てにいれ/下一段
てにはい/五段ラ
てば
てへ
てへっ
てへぺろ
てめぇ
てめえ
ても
てる
てんこ盛
てんてこ
てんで
てんぱ/五段ラ
てんぷら
てんやわんや
で
で/下一段
であります
でか/形容詞
でかけ/下一段
でかつて
でき
でき/上一段
できたて
できねぇ
できねー
でこぼこ
でしょ
でしょ。
でしょう
でしょうか
でしょうから
です
ですか
ですから
ですし
ですでに
ですね
ですよ
ですよね
ですら
ですわ
でたらめ
でっか/形容詞
でっかち
でっち
でっちあげる
でっぷり
でてきそう
でてきた
でてきたら
でてきて
でてくる
でてこない
でない
での
では
でも
でもう
でやんす
でより
でる
でんぐり
でーす
と
と/五段ガ
と/五段バ
と/五段ラ
とある
という
というか
ということ
ということわざ
というのは
といえなく
といえば
とうちゃん
とうっすら
とうに
とうの昔
とう句
とお/五段ラ
とお/形容詞
とおなじ
とおり
とか
とかく、
とがめ/下一段
とき
ときどき
ときめ/五段カ
ときめき
とく、
とくと
とくに
とくべつな
とぐろ
とこ
とこじゃ
とこで
とことん
ところ
ところが
ところで
ところでしょ
としか
としかいえない
とした
としたら
としたり
として
としてんの
とじ/上一段
とする
とたん
とっかえ
とっかかり
とっく
とっさ
とっちめて
とっつき
とっとと
とっぴ
とっ捕
とて、
とてつも
とてとて
とても
とでも
とど/五段カ
とどけ/下一段
とどま/五段ラ
とどめ
とどめ/下一段
となり
となりうる
とにかく
とにもかくにも
とのこと
とは
とはいうものの
とはいえ
とはいえず
とびきり
とびっきり
とぼけ
とぼけ/下一段
とま/五段ラ
とめ/下一段
とめどな/形容詞
とめどなく
とも
ともかく
ともだち
ともとれる
とやかく
とやら
とら/五段サ
とらえ/下一段
とらわれ/下一段
とりあえず
とりかえ/下一段
とりどり
とりな/五段サ
とりま、
とれ/下一段
とろけ/下一段
とろっとろ
とろみ
とろり
とろん
とわず
とんが/五段ラ
とんこつ
とんずら
とんちんかん
とんでも
とんでもなく
とんと
とんぼ
ど/五段カ
どいつ
どいて
どう
どういう
どういた/五段サ
どういたしまして
どうか
どうかしら
どうした
どうしたい
どうしたら
どうして
どうしてた
どうしても
どうしてる
どうしよう
どうしようか
どうしようかしら
どうすっか
どうする
どうするか
どうするかしら
どうすんべ
どうなるから
どうせ
どうぞ
どうだい
どうだろう
どうなる
どうなるか
どうなるかしら
どうなるから
どうにか
どうにも
どうも
どうや/五段ラ
どうやら
どうりで
どおり
どか/五段サ
どきまぎ
どきり
どぎつい
どぎまぎ
どくりと
どげんかせん
どげんかせんといかん
どこ
どこか
どこかしら
どこから
どこからか
どこぞ
どことなく
どこらへん
どころ
どころか
どさくさ
どさって
どさっと
どさり
どしん
どじょう
どす黒
どたばた
どちら
どちらか
どちらから
どちらも
どっか
どっから
どっきり
どっこい
どっこいしょ
どっこいどっこい
どっさり
どっしり
どっち
どっちか
どっちから
どっちつかず
どっと
どっぷり
どつきあい
どつき合
どつぼにはまって
どでか/形容詞
どどど
どなた
どの
どのみち
どばって
どばっと
どまり
ども
どや
どゆこと
どよめ/五段カ
どら焼
どれ
どれか
どれから
どろって
どろっと
どろり
どんくさ/形容詞
どんくらい
どんぐらい
どんぐり
どんだけ
どんと
どんな
どんぶらこ
どんぶり
どんより
どん底
どーした
どーする
どーすんだ
どーすんだよ
どーすんの
どーすんべ
どーせ
どーぞ
ど真
ど素人
な
な/五段カ
な/五段サ
な/五段ラ
な、
な。
なぁ、
なぁって
なぁと
なぁに
なあ、
なあと
なあに
なあに〈、
ない
ないか
ないかぎり
ないかしら
ないかも
ないから
ないがしろ
ないしょ
ないぞ
ないため
ないよ
ないよう
ないよね
ないより
ないわ
ないん
なお
なお/五段サ
なお/五段ラ
なおさら
なか
なかった
なかったし
なかったら
なかったらし/形容詞
なかったり
なかれ
なかんずく
なが/形容詞
ながら
なきゃ
なぎ倒
なく
なく/五段サ
なくちゃ
なくて
なくても
なくな/五段ラ
なくはない
なくもない
なけなし
なけりゃ
なけりゃぁ
なけりゃあ
なければ
なげ/下一段
なげない
なげなく
なご/五段マ
なさ
なさ/五段ラ
なさ/五段ワ
なさい
なさげ
なさそう
なし
なしか
なじ/五段ラ
なじませ
なじませ/下一段
なじみ
なじむ
なじんだ
なすすべ
なすすべもなく
なすりつ/五段カ
なすり付
なすり着
なす術
なせいで
なぜ
なぜか
なぜかしら
なぜだか
なぜなら
なぜならば
なぞ
なぞ/五段ラ
なぞらえ/下一段
なだめ/下一段
なっ、
なっ。
なったっす
なっちま/五段ワ
なっちゃ/五段ワ
なつかし/形容詞
なで/下一段
など
なに
なにげ
なにせ
なにとぞ
なにぶん
なにも
なにもかも
なにやら
なによそれ
なぬ〈
なの
なのか
なのかしら
なのかな
なのかなぁ
なのかも
なのじゃろう
なのだ、
なのだそう
なのだろう
なので
なのでしょう
なのです
なのと
なのに
なのは
なのよ
なのよね
なのよねえ
なのを
なび/五段カ
なびかせ/下一段
なぶ/五段ラ
なぶり殺
なべ
なま/五段ラ
なるっす
なまくら
なまぐさ/形容詞
なまじ
なまめかし/形容詞
なみ
なめ/下一段
なめ/五段サ
なめらか
なよ。
なら
なら/五段バ
なら/五段ワ
ならば
ならびに
ならべ/下一段
なり
なりうる
なりおおせ/下一段
なりた/五段カ
なりっぱなし
なりゃ
なりゃぁ
なりゃあ
なる
なるか
なるかしら
なるかも
なるから
なるころ
なるたけ
なるのにも
なるべく
なるほど
なるやら
なれ
なれ/下一段
なれそう
なんか
なんざ
なんじゃ
なんす
なんすよ
なんせ
なんぞ
なんたって
なんたら
なんたる
なんだ
なんだか
なんだから
なんだけど
なんだし
なんだぞ
なんだっけ
なんだって
なんだってば
なんだよ
なんだろ
なんだろう
なんだわ
なんちって
なんちゃって
なんちゃら
なんちゅう
なんつうか
なんて
なんで
なんでしょ
なんでしょう
なんです
なんですか
なんですから
なんでも
なんと
なんとか
なんとも
なんともはや
なんどき
なんども
なんない
なんなの
なんなのか
なんなのかしら
なんなら
なんなり
なんに
なんにも
なんねー
なんの
なんのかんの
なんぼ
なんぼの
なんも
なんやかんや
なんやで
なんやら
なんよ
なんら
なんらか
なー
なーんにも
なーんも
に
に/上一段
にいっと
にえ/下一段
におい
において
におう
にが/形容詞
にぎやか
にぎやかな
にぎわい
にぎわう
にく/形容詞
にくべ/下一段
にげ/下一段
にこやか
にこり
にしって
にしっと
にしよ
にしよう
にしよっか
にじ/五段マ
にじませ
にじみ
にじむ
にじり
にじりよ/五段ラ
にじんで
にっこり
にっちもさっちも
にっと
につき
にて、
にてい/上一段
にとっちゃ
になかったら
になりた/五段カ
には
にはびこ/五段ラ
にぶちん
にまにま
にも
にもかかわらず
にもの、
にゃ。
にゃあ
にゃん
にゅるりと
にょきって
にょきっと
にょきにょき
によらず
によ/五段ラ
にら/五段マ
にらめっこ
にろくでも
にわかに
にんじん
にんまり
ぬ/五段ガ
ぬいぐるみ
ぬかりな/五段カ
ぬかる/五段マ
ぬかるむ
ぬか喜
ぬくもり
ぬぐ/五段ワ
ぬめり
ぬる/形容詞
ぬるま湯
ぬるり
ぬれ/下一段
ね/下一段
ね。
ねぇ
ねえ
ねぎら/五段ワ
ねぐら
ねじ
ねじ/五段ラ
ねじくり
ねじれ/下一段
ねたまれ/下一段
ねっとり
ねば
ねぶ/五段ラ
ねむ/五段ラ
ねむ/形容詞
ねんごろ
ねーし
ねーだろ
ねーだろう
の
の/五段マ
の/五段ラ
のぅ。
のう。
のか
のかい
のかつて
のかな
のから
のが
のけ/下一段
のけぞ/五段ラ
のこ/五段サ
のこ/五段ラ
のこぎり
のこれら
のじゃ
のじゃろ
のせ/下一段
のぞ/五段カ
のぞきこ/五段マ
のぞみ
のたう/五段タ
のたうちまわ/五段ワ
のたく/五段ラ
のたま/五段ワ
のた打
のだ
のだが
のだけ
のだけど
のだし
のだと
のだろう
のち、
のちに
のちの
のちは
のっか/五段ラ
のっけ/下一段
のっそり
のっと/五段ラ
のっとり
のっぴき
ので
のでしょ
のでしょう
のです
のど
のどか
のに
のにも
のは
のはず
のば/五段サ
のほほん
のぼ/五段ラ
のぼせ/下一段
のみ
のみならず
のめ/下一段
のめり
のも
のもつ
のもと
のもの
のよ。
のよう
のよねえ
のらり
のりかえ/下一段
のろけ
のろし
のろま
のを
のんき
のんびり
のんべんだらり
は
は/五段カ
は/五段ラ
はぁ
はぁい
はあ、
はい/五段ラ
はい、
はか/五段ラ
はかど/五段ラ
はかな/形容詞
はからず
はが/五段サ
はがき
はぐらか/五段サ
はぐれ/下一段
はこ/五段バ
はさ/五段マ
はさ。
はざま
はし/五段ラ
はしご
はしっこい
はしっこさ
はしゃ/五段ガ
はじ/五段カ
はじ/五段マ
はじき
はじま/五段ラ
はじめ/下一段
はす向
はず
はず/五段サ
はず/五段マ
はずかし/形容詞
はずれ/下一段
はせ/下一段
はたき
はたして
はたと
はたまた
はたら/五段カ
はた迷惑
はだけ/下一段
はちきれんばかり
はちみつ
はちゃめちゃ
はち切
はっきり
はっちゃけ
はっちゃけ/下一段
はっと
はっはっは
はっはっはっは
はつらつ
はて/下一段
はて〈、
はてさて
はな/五段サ
はなから
はなはだ
はにかむ
はね/下一段
はばか/五段ラ
はびこ/五段ラ
はま/五段ラ
はみ出
はめ/下一段
はめ込
はや/形容詞
はやむなく
はやめた
はら/五段マ
はら/五段ワ
はらりと
はらわた
はりき/上一段
はるか
はるばる
はれ/下一段
はんこ
はーい
ば、
ばぁさま
ばぁさん
ばぁちゃん
ばあさま
ばあさん
ばあちゃん
ばい菌
ばか
ばかげ/下一段
ばかし
ばかたれ
ばかに
ばかばかし/形容詞
ばからし/形容詞
ばかり
ばきり
ばさみ
ばさりと
ばしっと
ばしゃって
ばしゃっと
ばしゃばしゃ
ばしゃん
ばしゃーん
ばたつかせ/下一段
ばたり
ばちって
ばちっと
ばちん
ばっか
ばっかり
ばっきり
ばっさり
ばっしゃ
ばったばった
ばったり
ばったん
ばっちり
ばって
ばっと
ばつが悪
ばつぐん
ばつの悪
ばて/下一段
ばば臭
ばら/五段サ
ばらつ/五段カ
ばらま/五段カ
ばら撒
ばら肉
ばりで
ばりに
ばりの
ばれ/下一段
ばーか
ばーさま
ばーさん
ばーちゃん
ぱぁっと
ぱあっと
ぱくって
ぱくっと
ぱくつく
ぱくり
ぱしゃん
ぱたり
ぱちくり
ぱちり
ぱちん
ぱちんこ
ぱっくり
ぱったり
ぱっちり
ぱっちん
ぱっつん
ぱって
ぱっと
ぱっぱか
ぱなし
ぱぱって
ぱぱっと
ぱらり
ぱりって
ぱりっと
ぱんつ
ひ/五段カ
ひぃ〈、
ひいおじぃ
ひいおじい
ひいおじー
ひいおばぁ
ひいおばあ
ひいおばー
ひいき
ひいじぃ
ひいじい
ひいじー
ひいばぁ
ひいばあ
ひいばー
ひかり
ひきこも/五段ラ
ひきつ/五段ラ
ひく/形容詞
ひぐらし
ひけらか/五段サ
ひげ
ひさし
ひさびさ
ひざ
ひざまず/五段カ
ひしめ/五段カ
ひしゃげ/下一段
ひし形
ひじ
ひずみ
ひそ/五段マ
ひそか
ひそめ/下一段
ひたすら
ひたむき
ひた走
ひた隠
ひっか/五段カ
ひっかえ
ひっかか/五段ラ
ひっかけ/下一段
ひっきりなし
ひっくり
ひっくるめ/下一段
ひっそり
ひったく/五段ラ
ひっつ/五段カ
ひっつか/五段マ
ひっぱ/五段ラ
ひっぱた/五段カ
ひっぱって
ひつような
ひでえ
ひでぇ
ひと、
ひとえに
ひとかけ
ひとかけら
ひときわ
ひとくくり
ひとけた
ひとしきり
ひとたび
ひとたまり
ひとっ走
ひとっ跳
ひとっ飛
ひとつ
ひとつぶ
ひとつまみ
ひととき
ひとまず
ひとまとめ
ひとり
ひとりごち/上一段
ひとりごつ
ひとりでに
ひと塊
ひと月
ひど/形容詞
ひどいめに
ひど過
ひにかけ/下一段
ひね/五段ラ
ひねくれ/下一段
ひのき
ひび
ひまな
ひもじい
ひや/五段サ
ひやり
ひゅって
ひゅっと
ひゅーひゅー
ひょいって
ひょいっと
ひょいと
ひょいひょい
ひょうきん
ひょこり
ひょっこり
ひょっと
ひょろっと
ひょん
ひよこ
ひよっこ
ひら/五段カ
ひらがな
ひらめ/五段カ
ひらり
ひりつく
ひる/五段マ
ひるがえ/五段サ
ひるがえ/五段ラ
ひれ伏
ひろ/五段ワ
ひろ/形容詞
ひんしゅく
ひんやり
ひん曲
ひ弱
びいき
びくっと
びくとも
びくともしていない
びくともしない
びくり
びくん
びしっと
びしばし
びしゃびしゃ
びしょぬれ
びしょびしょ
びしょ濡
びちゃびちゃ
びっくらこ/五段カ
びっくり
びっしょり
びっしり
びっちり
びび/五段ラ
びゅって
びゅっと
びゅんびゅん
びゅーん
びよーん
ぴく、
ぴくって
ぴくっと
ぴくり
ぴくん
ぴしゃり
ぴしり
ぴた、
ぴたり
ぴっかぴか
ぴったり
ぴっちり
ぴっと
ぴょこぴょこ
ぴょこん
ぴょん
ぴょんぴょん
ぴん、
ぴんっと
ぴんと
ぴーん
ふ/五段カ
ふ/五段マ
ふ/五段ラ
ふい
ふいに
ふぅ、
ふぅっと
ふう、
ふうっと
ふうな
ふうに
ふうん
ふえ/下一段
ふか/五段サ
ふがい
ふくざつな
ふくよか
ふくら/五段マ
ふくらはぎ
ふくらみ
ふくれっ面
ふけ/下一段
ふさ/五段ガ
ふさが/五段ラ
ふさわし/形容詞
ふざけ/下一段
ふしぎな
ふせ/下一段
ふせ/五段ラ
ふた
ふたつ
ふため/五段カ
ふたり
ふたりっきり
ふだん
ふち
ふっ、
ふっくら
ふっと
ふっふっふ
ふっ飛
ふてぶてし/形容詞
ふて腐
ふと
ふと/五段ラ
ふと/形容詞
ふとした
ふにゃっと
ふにゃふにゃ
ふにゃり
ふにゃん
ふふ〈、
ふふっ
ふふふ〈、
ふふふふ〈、
ふふん
ふべんな
ふむ、
ふもと
ふやか/五段サ
ふやけ/下一段
ふらっと
ふらつ/五段カ
ふらり
ふら付
ふり
ふる/五段ワ
ふる/形容詞
ふるま/五段ワ
ふわっと
ふわもこ
ふわり
ふん
ふんぎり
ふんす
ふんぞり
ふんだく/五段ラ
ふんだん
ふんっ
ふんわり
ふーん
ふ化
ぶ/五段ラ
ぶさた
ぶすっと
ぶちかま/五段サ
ぶちこめ/下一段
ぶちのめ/五段サ
ぶちまけ/下一段
ぶちゅぶちゅ
ぶち上
ぶち切
ぶち壊
ぶち当
ぶち抜
ぶち撒
ぶち殺
ぶち破
ぶち込
ぶっかけ/下一段
ぶっきらぼう
ぶっきら棒
ぶったおれ/下一段
ぶった切
ぶっちぎり
ぶっちゃけ
ぶっちゃけ/下一段
ぶっつけ
ぶっと/形容詞
ぶっとい
ぶっ倒
ぶっ壊
ぶっ掛
ぶっ放
ぶっ殺
ぶっ通
ぶっ飛
ぶつか
ぶつか/五段ラ
ぶつくさ
ぶつけ/下一段
ぶつ切
ぶらつ/五段カ
ぶらつく
ぶらり
ぶら下
ぶり
ぶりっこ
ぶれ/下一段
ぶわっと
ぶん
ぶ厚
ぷい
ぷくっと
ぷげら
ぷち
ぷっくらと
ぷっくり
ぷっつり
ぷつり
ぷはっ
ぷりっと
ぷりん
ぷるっと
ぷるっぷる
ぷるん
ぷんすか
へ
へ/五段ラ
へい、
へいっ
へぇ〈、
へこ/五段マ
へこたれ/下一段
へこたれず
へそ
へそくり
へたくそ
へたな
へたり
へたれ
へっちゃら
へっぴり腰
へっぽこ
へつら/五段ワ
へと
へにゃり
へにょへにょ
へのへのもへじ
へば/五段ラ
へまを/サ変
へん
へんな
へー、
へーー、
へーーー、
べ、
べからず
べき
べく
べし
べし、
べたつ/五段カ
べた惚
べちゃっと
べちゃべちゃ
べちょべちょ
べったり
べっちょり
べっとり
べつに
べんりな
ぺこっと
ぺこり
ぺしっと
ぺしゃんこ
ぺたり
ぺたりと
ぺたん
ぺたんこ
ぺちゃくちゃ
ぺちゃぺちゃ
ぺっこり
ぺったんこ
ぺらぺーら
ぺろっと
ほ/五段ラ
ほい
ほう
ほうが
ほうじ茶
ほうと
ほうに
ほうの
ほうは
ほうへ
ほうれんそう
ほうれん草
ほうを
ほえ面
ほか
ほくそ笑
ほくろ
ほぐ/五段サ
ほぐれ/下一段
ほこり
ほころ/五段バ
ほころばせ/下一段
ほざ/五段カ
ほし
ほし/形容詞
ほしが/五段ラ
ほそ/形容詞
ほそぼそ
ほだ/五段サ
ほっかほか
ほっこり
ほっそり
ほっつき
ほっと
ほっぺ
ほっぺた
ほっほっほ
ほっほっほっ
ほっほっほっほ
ほっほっほっほっ
ほっぽ/五段ラ
ほっぽらか/五段サ
ほっぽり
ほつれ/下一段
ほとばし/上一段
ほとぼり
ほとり
ほとんど
ほど
ほど/五段カ
ほどがある
ほどこ/五段サ
ほのかな
ほのかに
ほのぼの
ほのめか/五段サ
ほほ
ほほう
ほほえ/五段マ
ほほえまし/形容詞
ほぼ
ほめ/下一段
ほら
ほれ〈、
ほろ苦
ほんそれ
ほんと
ほんとう
ほんの
ほんのり
ほんま
ほんわか
ぼいん
ぼうっと
ぼか/五段サ
ぼかん
ぼく/人称名詞
ぼけ
ぼさっと
ぼそっと
ぼそり
ぼたん
ぼっかり
ぼっこぼこ
ぼったく/五段ラ
ぼっち
ぼっとん
ぼや/五段カ
ぼやい/上一段
ぼやか/五段サ
ぼやっと
ぼろ
ぼろい
ぼんやり
ぼーっと
ぽい
ぽかん
ぽく
ぽさ
ぽた
ぽちって
ぽちっと
ぽっかり
ぽっきり
ぽっこり
ぽっちゃり
ぽっと
ぽつり
ぽつん
ぽにょぽにょ
ぽよん
ぽろっと
ぽろり
ぽんと
ま/五段カ
ま/五段タ
ま〈。
まぁ
まあ
まい
まい/五段ラ
まい、
まいど
まおう
まか/五段サ
まかな/五段ワ
まかり
まが/五段ラ
まがい
まがまがし/形容詞
まがりなり
まき散
まぎれ/下一段
まく
まく/五段ラ
まくしたて/下一段
まぐれ
まけ/下一段
まこと
まごう
まごうことなき
まごつ/五段カ
まさか
まさぐ/五段ラ
まさしく
まさに
まし
ましい
ました
ましたら
まして
ましょ
ましょう
ましょっか
ましろ
まじ
まじ/五段ラ
まじかに
まじめ
まじめな
まじゅつ
まじわ/五段ラ
ます
ますか
ますから
ますし
ますね
ますよ
ますよう
ますよね
ますわ
まず
まず/形容詞
ませ
ませた
ませて
ませぬ
ません
ませんか
まぜ/下一段
また
また/五段ガ
またた/五段カ
または
またもや
まだ
まだしも
まだら
まちがえ/下一段
まっさかさま
まっさら
まっしぐら
まっしろな
まっすぐ
まったく
まったり
まっとう
まっぴら
まつり
まで
までも
まと/五段ワ
まとま/五段ラ
まとめ/下一段
まとも
まとわ/五段ラ
まどろ/五段マ
まどろっこし/形容詞
まなざし
まなじり
まな板
まにあ/五段ワ
まね
まばた/五段カ
まばゆ/形容詞
まばら
まぶ/五段サ
まぶし/形容詞
まぶた
まほう
まほうつかい
まぼろし
まま
まみれ/下一段
まめな
まも/五段ラ
まもなく
まりあ
まる
まる/形容詞
まるきり
まるっきり
まるで
まれ
まろやか
まろやかな
まわ/五段サ
まわ/五段ラ
まんざら
まんじゅう
まんべんなく
まんま
まん丸
まーす
み/上一段
みえ/下一段
みえる
みかん
みが/五段カ
みしり
みじか/形容詞
みじめ
みじん
みすぼらし/形容詞
みずみずし/形容詞
みせ/下一段
みそ
みそ汁
みたまえ
みたろ
みっちり
みっつ
みっとも
みつか/五段ラ
みつけ/下一段
みどり
みな
みな/五段サ
みなぎ/五段ラ
みなさま
みみっち/形容詞
みんな
む/五段カ
むう〈、
むか/五段ワ
むかえ/下一段
むかし
むかつ/五段カ
むかつく
むくれ/下一段
むげには
むさぼ/上一段
むし/五段ラ
むしゃくしゃ
むしゃむしゃ
むしろ
むすっと
むずかし/形容詞
むずが/五段ラ
むず痒
むせ/下一段
むせ/五段バ
むだな
むち
むちゃくちゃ
むっつ
むっつり
むっと
むなし/形容詞
むにゃむにゃ
むむ〈、
むやみ
むらなく
むらむら
むりな
むろん
むわっと
め。
めい/下一段
めいっぱい
めか/五段サ
めがけ/下一段
めがさめ/下一段
めがね
めく/五段ラ
めぐ/五段ラ
めぐみ
めぐら/五段サ
めげ/下一段
めげそう
めざ/五段サ
めしあが/五段ラ
めずらし/形容詞
めだか
めちゃ
めちゃくちゃ
めちゃめちゃ
めっ
めっきり
めったなこと
めったな事
めったに
めった刺
めっちゃ
めっぽう
めでた/形容詞
めぼし/形容詞
めまい
めまぐるし/形容詞
めり込
めんこ/形容詞
めんど
めんどう
も
も/五段ガ
も/五段タ
も/五段マ
もう
もう/五段サ
もうしこ/五段マ
もうしばし
もうじき
もうすぐ
もうすこし
もうちょい
もうちょっと
もうもうと
もえ/下一段
もが/五段カ
もがれ/下一段
もぎ取
もくろ/五段マ
もぐ/五段ラ
もし
もしかしたら
もしかして
もしかすると
もしくは
もしばし
もじ/五段ラ
もたげ/下一段
もたげて
もたつ/五段カ
もたつく
もたない
もたら/五段サ
もちゃんと
もちろん
もっさり
もったい
もったいない
もったいぶる
もっちり
もってい/五段カ
もってこい
もってしても
もっと
もっとも
もっぱら
もつこと
もつれ/下一段
もつれさ/五段サ
もつれ合
もてな/五段サ
もてはや/五段サ
もとい
もとから
もとに
もとより
もど/五段サ
もど/五段ラ
もどかし/形容詞
もどき
もにょもにょ
もぬけの殻
もの
ものおじ
ものが
ものぐさ
ものだね
ものづくり
ものの
ものは
もはや
もみくちゃ
もめ
もら/五段ワ
もれなく
もろ
もろ/形容詞
もん
もんじゃ
もんだぞ
もんでしょ
もんです
もんどり
や
や/五段カ
や/五段マ
や/五段ラ
やぁん
やあ。
やあん
やい、
やおよろず
やおら
やかまし/形容詞
やが/五段ラ
やがて
やがりました
やがります
やがりますか
やがりますから
やきもき
やきもち
やくざ
やくだ/五段タ
やくにた/五段タ
やけ/下一段
やけに
やさぐれ/下一段
やさし/形容詞
やす/五段マ
やす/形容詞
やすり
やせ/下一段
やせ形
やたら
やだ、
やだっ
やっかい
やっかみ
やっちま/五段ワ
やっちゃ/五段ワ
やっちゃいけない
やっちゃだめ
やっちゃやだ
やっつけ/下一段
やって
やっと
やっぱ
やっぱり
やっべ
やっべえ
やつ
やつら
やつれ/下一段
やはり
やば/形容詞
やぶさか
やぶれ/下一段
やべえ
やまし/形容詞
やみくも
やむなく
やめ
やめ/下一段
やもしれぬ
やや
ややこし/形容詞
やら、
やら〈
やらか/五段サ
やらかしかねず
やらかしかねない
やられ
やりあう
やりがい
やりくり
やるか
やるかしら
やるから
やるから
やることなすこと
やるせない
やるっきゃ
やろう
やわらか
やわらか/形容詞
やんけ
やんごと
やんちゃ
やんなきゃ
やんや
やんわり
やーん
ゆ/五段カ
ゆいいつ
ゆいつ
ゆううつ
ゆうに
ゆうめいな
ゆうゆう
ゆうしゃ
ゆえ
ゆえに
ゆえん
ゆかり
ゆが/五段マ
ゆす/五段ガ
ゆす/五段ラ
ゆず/五段ラ
ゆだね/下一段
ゆっくり
ゆったり
ゆったりめ
ゆで/下一段
ゆとり
ゆらり
ゆる/五段ガ
ゆる/五段マ
ゆる/形容詞
ゆるふわ
ゆるやか
ゆーっくり
よ/五段サ
よ/五段バ
よ/五段ラ
よ/五段ワ
よ/形容詞
よ、
よいしょ
よぅ、
よう
ようこそ
ようじゃ
ようす
ようするに
ようだ、
ようで
ようでした
ようでしたら、
ようです
ようとする
ような
ようなやりとり
ようなら
ようならば
ように
ようにも
ようやく
よぉ、
よお、
よかった
よかったし
よかったら
よかったらし/形容詞
よかったり
よからぬこと
よかろう
よぎ/五段ラ
よくぞ
よくて
よくても
よくも
よけ/下一段
よければ
よこ/五段サ
よこせ
よご/五段サ
よごれ/下一段
よさげ
よしんば
よじ/五段ラ
よじ登
よせ〈、
よそ
よそよそし/形容詞
よだれ
よっ、
よっしゃ
よっちゃ
よっつ
よって
よってた
よってたかって
よってって
よってる
よっぽど
よど/五段マ
よどみなく
よな、
よなぁ
よね、
よねぇ、
よねえ
よほど
よみがえ/五段ラ
よりけり
よりどりみどり
よりはまし
よると
よれば
よろけ/下一段
よろこ/五段バ
よろし/形容詞
よろっと
よろめ/五段カ
よわ/形容詞
よわよわし/形容詞
ら〈
らから
らくな
らし/形容詞
らしいっちゃらしいし
らしからぬ
らしき
らせない
らちが
らちが明
らっしゃい
らっしゃった
らっしゃらない
らっしゃる
らで
らに
られ
られず
られそう
られた
られたく
られたくて
られたら
られたり
られちゃ
られちゃう
られて
られてた
られてたら
られてたり
られてる
られない
られぬ
られます
られますか
られますから
られません
られる
られるか
られるかい
られるかしら
られん
らを
りゃぁしない
りゃぁせぬ
りゃぁせん
りゃあしない
りゃあせぬ
りゃあせん
りゃしない
りゃせぬ
りゃせん
りりしい
りんご
る〈
れた
れたくて
れたら
れたり
れちゃ
れちゃう
れっきと
れば
れる
れんきんじゅつ
ろ、
ろう
ろうそく
ろくでなし
ろくでもない
ろくでもなく
ろくな
ろくに
ろくでも
ろっか
ろ過
わ/五段カ
わ/五段ラ
わ、
わぁ、
わあ
わぃ、
わい、
わか/五段サ
わか/五段ラ
わか/形容詞
わかれ/下一段
わかんねえ
わが
わがまま
わき
わきまえ/下一段
わき道
わけ
わざと
わし/人称名詞
わしゃわしゃ
わすれ/下一段
わずか
わずらわし/形容詞
わずらわ/五段サ
わた/五段サ
わた/五段ラ
わたあめ
わたくし/人称名詞
わたくしめ
わたし/人称名詞
わだかま/五段ラ
わちゃわちゃ
わっ、
わっと
わな
わね
わね。
わねぇ、
わねえ、
わび/上一段
わめ/五段カ
わめきたて/下一段
わよ。
わよっ
わよね
わら/五段ワ
わらわ
わりあい
わりと
わる/形容詞
われ/下一段
わわわ
わん
わん。
わんこ
わんさか
わーい
を
をしとき
をしに
をへて
ん、
んかなぁ
んじゃ
んじゃう
んじゃよ
んじゃろ
んじゃろう
んじゃん
んすか
んだ
んだい、
んだから
んだが
んだけど
んだし
んだぜ
んだぞ
んだっけ
んだった
んだったら
んだって
んだってば
んだね
んだよ
んだよな
んだら
んだり
んだろ
んだろう
んだわ
んで
んでしょ
んでしょう
んです、
んですか
んですから
んですが
んですよ、
んですよね、
んですわ、
んでた
んでたり
んでて
んでる
んなの
んなもん
んなら
んなわけ
んのか
んのに
んふふ
んふふふ
んふふふふ
んー
んーー
んーーー
`;

function dummy_hira2dic_org(){}
// 擬音などの重複文字の登録圧縮
// 'あ|へまら' => 'あへあへ', 'あまあま', 'あらあら'
const hira2dic_org = [
'あ|ぃいぅうせつはひへまらりるわん',
'い|えきがけじそちひぼやよらろ',
'う|いかきさしじすずだとにねはまむよりるろん',
'え|いへろん',
'お|いうえずたちどのほやよらろ',
'か|あいきくさじたちつなぱびぴぷゆらりん',
'が|あうおくこさしたちつはばぶぷみやらりん',
'き|いこしつびらりれん',
'きぁ|あいはぴわん',
'きゅ|あぽるん',
'きょ|とどろ',
'ぎ|いうくこざしすたちとらりん',
'ぎゃ|あおはん',
'ぎゅ|うるん',
'ぎょ|ろ',
'く|あいすただつどにねぱよらりるれん',
'ぐ|あいうきさしじずただちつにねびへらりるわん',
'け|したちばほらろん',
'げ|いえこしそふぷほぼらろ',
'こ|いきくげしすそちつてとねびほぽみらりれろん',
'ご|あうきくごしすそたつとてぶほみりろわん',
'さ|ぁあくてばびぶまらわん',
'ざ|ぁあくばぶらりわん',
'し|ぃおくげこずばぶまわ',
'じ|くぐたとめりろわん',
'しゃ|かきくらりん',
'じゃ|かきばぶらりん',
'しゅ|あうきこたぱぽるわん',
'じゅ|うくぶぼぽるわ',
'す|ぃいぅうかきくけごたはぱぴべぽやらりるれん',
'ず|ぃいうかきけこさしたばびぶぼぽらりるん',
'せ|いこふ',
'ぜ|ぃいぇえはん',
'そ|いうこもやよろわん',
'ぞ|くりろわ',
'た|じだびぷまむゆらるん',
'だ|ぁあくさばぶぼめらるん',
'ち|かきくびまらりろん',
'ちゃ|うかぷらり',
'ちゅ|うぴぷぽるん',
'ちょ|いきくこびぼめろん',
'ぢ|くぐたとめりろわん',
'つ|いかぎくぶやらるん',
'て|かくとろへれろん',
'で|かすたねぶれろわ',
'でぅ|ふ',
'と|うぎくげこたてぼぽろん',
'ど|ぅうかきくさしすたなばぱぼやれろん',
'な|ぁあかきぞでみむよん',
'に|ぁあぃいかぎくこたぱひぶまゃやよん',
'にゃ|ぁあぅうぉおごはむん',
'にゅ|る',
'にょ|きろ',
'ぬ|いきぎくけためらりるれ',
'ね|ぇえじちとばぬりる',
'の|ぅうこしそたびりろん',
'は|ぁあぃいきぐすぴふむめらわ',
'ば|ぁあぃいぅうきくぐさしたちつてぶらりれん',
'ぱ|いかきくこさしたちつふらりん',
'ひ|ぃいえくしそただまやよらり',
'ひゅ|るん',
'ひょ|いころ',
'び|ぃいきくしばらりろん',
'ぴ|かきくこしたちとよらりろん',
'ふ|ぅうかがきごさしつにひみむよらりるわん',
'ぶ|ぃいぅうかくすちつにひよらりるん',
'ぷ|ぃいかくしすちつによらりるわん',
'へ|ぃいぇえことなぼらろ',
'べ|きこしたちとらりろん',
'ぺ|かきこしたちとらりろん',
'ほ|ぃいぅうぇえかくこじとどもやらりるれろわ',
'ぼ|ぇえぅうぉおかきけこさそたちつとりろん',
'ぽ|あいかきくこそたちつとふむやよりろわん',
'ま|ぁあござじすずぜただちてねよるん',
'み|ぅうえきけこしすちにりるん',
'みゃ|ぁあぅうん',
'む|かきくぐざしずだちにふらりん',
'め|きそたもらりろ',
'も|ぁあぅうぉおがくぐこごさしじそぞたちとふみめやりろわん',
'や|ぁあぃいすだばほまめりれわん',
'ゆ|くさめらりるん',
'よ|しじせたちなぼむれろわ',
'ら|ぐぶりん',
'り|ん',
'る|ん',
'れ|あずろ',
'ろ|り',
'わ|ぁあぃいぉおきくさざしたなはらん',
'ん|ぐだでと'
];

function dummy_exdic_org(){}
const exdic_org = 
`あああああああああけけぅんも#あああ
あげた#まえ
あっても#う
あるか#も
あるか#わい
あるく#らい
あるわ#たくし
あるわ#たし
い#うわさ
い#して
いい#たします
いい#ただ
いい#ろいろ
いいわ#け
いう#いうえに
いう#ち
いう#わさ
いうな#じ
いかが#よく
いき#らめ
いき#れ
いき#れい
いく#せに
いく#ださ
いく#らい
いく#る
いくら#い
いけ#ど
いけ#れど
いさ#れて
いざ#ま
いざ#らい
いし#て
いた#くない
いた#くなかった
いた#くなっ
いた#くなる
いた#くは
いた#くも
いた#め
いたく#せ
いたく#らい
いただけた#ら
いたのか#も
いだく#らい
いちゃ#!つ
いつ#ながり
いつ#もり
いつも#がれ
いつも#り
いて#る
いているか#ら
いないか#も
いないか#ら
いままで#す
いや#すい
いや#すく
いや#すけれ
いや#すさ
いや#すそう
いや#つ
いや#めて
いや#や
いや#ら
いや#られ
いや#り
いや#ろう
いよ#りは
いるか#しら
うけ#ど
うけ#れど
うち#%ゃゅょ
うつ#もり
えっ#て
おいた#まえ
か#いろいろ
か#く
かい#い
かい#る
かい#ろいろ
かう#めい
かう#めか
かう#めき
かう#めく
かう#めけ
かく#らい
かけら#れ
かす#ぎ
かす#ぎず
かす#ぐ
かったか#%いしつともら
かつ#け
かと#か
かめちゃ#くちゃ
かも#う
かも#ともと
かも#のすご
から#ん
からい#い
からい#う
からい#えば
からい#く
からい#た
からい#つ
からう#すうす
からう#れし
からく#る
からく#るぶし
からさ#くっと
からさ#らに
からし#て
からし#ばらく
からみ#て
からみ#るみる
からみ#んな
からんだ#け
が#る
が#れた
が#れて
がかろ#うじ
がかろう#じ
がた#くさん
がた#どり
がた#びたび
がた#まに
がた#まら
がたく#さん
がち#くりって
がち#くりと
がち#ぐはぐ
がち#らちら
がち#らほら
がち#らり
がち#りばめ
がち#んぷん
がち#んまり
がちゃ#んと
きいた#め
きた#がっ
きた#がら
きた#がり
きた#がる
きた#がれ
きた#がろ
きよ#り
くくり#ぬ
くさ#せ%たるて
くさ#せない
くさ#まざま
くさ#れて
くそ#もそも
くそ#れ
くそ#んな
くみ#た
くれた#まえ
くれるか#%いしつともら
けす#ぎて
こうし#とく
こうし#とけ
こうし#ましょう
こうしたら#しい
こなした#まえ
さがす#べて
さくな#%っらりるれろ
さじ#%ゃゅょ
さす#ら
させた#く
させた#まえ
さなか#まど
された#まえ
されたく#らい
されるか#も
しい#い
しい#じっ
しい#ただき
しか#ゆし
しか#ら
しかし#て
しかし#ゃ
しかし#ゅ
しかし#ょ
しかし#らな
しかも#た
しく#ださ
しく#らい
しさ#え
しさ#れて
したい#くつ
したい#ざこざ
したい#たずら
したか#もしれ
したく#せ
したく#らい
しちゃい#けない
しつけ#!られ
してい#ただけ
していた#だく
していた#だけない
していた#だける
しているか#%いしつともら
してくれたら#しい
してた#くさん
してた#まに
してた#め
してた#めら
してた#り
しな#の
しな#んて
しないか#%いしつともら
しなん#て
しにな#る
しわ#か%っらりうれろん
しわ#ざと
じゃないよ#うな
すく#らい
すぐ#らい
すぐに#はじまる
すぐに#はじめる
すぐには#たと
すべきか#%いしつともら
するか#%いしつともら
するか#んじ
せい#くら
せい#たしま
そういうと#き
そういうと#こ
それじゃあ#たし
それじゃあ#んまり
それです#べて
たか#ら
たくなかったら#しい
ただ#け
ただ#ろう
たち#ちょうど
たつ#いで
たつ#もり
ためにも#う
たら#しい
たら#しく
だからか#もしれ
だけだけ#ど
だったか#%いしつともら
だと#も
ちゃんこ#れ
ちゃんこ#んにち
ちゃんこ#んばん
ってた#ら
ってんのか#しら
ついた#だき
つく#らい
つけ#れど
ているか#%いしつともら
てか#しら
ても#うじき
ても#らい
ても#らう
ても#らえ
ても#らお
ても#らっ
ても#らわ
でか#すか
でか#らくも
でか#わい
でか#わ%さしすせそ
でき#ちん
でき#ゃいきゃい
できるか#%いしつともら
です#いすい
です#く%いうえっわ
です#ぐ
です#ごい
です#ごく
です#さまじ
です#ぴすぴ
です#べすべ
です#べて
です#ませ
です#ませて
です#まない
です#まん
です#み
です#みそう
です#みません
です#む
です#めば
です#やすや
です#らり
です#り
です#る
です#れ
です#んで
です#んなり
ですら#り
でず#いぶん
でず#ばずば
でず#ぼら
でた#びたび
でた#またま
でた#まに
でた#め息
でちゃ#ちゃっと
でちゃ#ん
でつつ#%かきくけこい
での#このこ
での#たうち
での#ぼせ
での#み
での#らり
での#んびり
では#%ぁぃぅぇぇゃゅょ
では#がき
では#しゃ%いがぎぐげご
では#じめ
でも#ぞもぞ
でも#だえ
でも#ちろん
でも#てあそ
でも#めた
でも#やもや
でも#らい
でも#らう
でも#らえ
でも#らお
でも#らっ
でもう#れし
でもう#んざり
でよ#かった
でよ#く
でよ#ければ
でよ#れよれ
でよ#ろこ%ばびぶべぼん
でよ#ろし
でよ#ろめ
でろ#く%にな
というか#ら
とうる#さい
とうれ#し
とおっちゃ#ん
とおんな#じ
とか#かって
とか#かわり
とか#すか
とか#みしめ
とか#らか%わいうえおっ
とき#つい
とき#つく
とき#つけ
とき#つこ
とき#つさ
とき#て
とき#らめ
とき#り
とく#と
とこ#いつ
とこ#う
とこ#うして
とこ#うする
とこ#うだ
とこ#うで
とこ#うなる
とこ#こ
とこ#じ付
とこ#だわ
とこ#ちら
とこ#なし
とこ#なす
とこ#ぼ
とこ#まごま
とこ#れ
とこ#んな
とこ#んにゃく
とこで#す
ところで#す
ところで#は
ところで#も
とし#たたか
としか#ねない
とした#い
とした#まえ
として#た
として#る
となり#ま%しす
となり#ません
とは#がき
とは#ぐれ
とは#しゃぎ
とは#しゃぐ
とは#ちみつ
とは#らはら
とまった#く
とめ#ぐら
とめ#んど
とも#う
とも#てはや
とも#め
とも#よう
とも#ろもろ
とやら#れ%るてた
どうするか#しら
どけど#うにか
ないわ#け
ないわ#たくし
ないわ#たし
なお#かあ
なお#じい
なお#じさん
なお#とう
なお#ねえ
なお#ばあ
なお#もちゃ
なか#けら
なかったら#しい
なき#らめき
なく#らい
なくす#ぐ
なくちゃ#んと
なさ#まざま
なし#こり
なの#どか
なのです#ぐ
ならい#い
ならい#くら
ならい#ざ
ならい#ただ%いかきくけこ
ならい#つか
ならい#つも
ならせ#めて
ならばせ#めて
なりそう#なので
なるか#しら
なんだか#んだ
に#ゃ
に#ゅ
に#ょ
にえ#くぼ
にく#たば%っらりるれろ
にく#らい
にく#る
にく#れ%るたな
にくく#りつけ
にじり#じり
にず#ら
にた#くさん
にた#しなめ
にた#たえ
にた#どたど
にた#どり
にた#びたび
にた#またま
にた#まに
にた#むろ
にた#め息
にたく#さん
にちゃ#んと
になかったら#しい
には#がき
には#ぐれ
には#さむ
には#さん
には#しゃい
には#しゃぎ
には#しゃぐ
には#ねられ
には#ばかられ
には#まっ
には#まら
には#まり
には#まる
には#まれ
には#まろ
には#め
にも#う
にも#が%いかきくけこ
にも#ぐ%っらりるれろ
にも#ぞもぞ
にも#たら%さしすせそ
にも#たれ
にも#だえ
にも#つ
にも#ど%っらりるれろ
にも#どかし
にも#のが
にも#のすご
にも#のっぴ
にも#ので
にも#のに
にも#のは
にも#のを
にも#みくちゃ
にも#めて
にも#らう
にも#らえ
にも#らっ
にも#らわな
にも#れ
にも#ろい
によ#うやく
によ#ぎ
によ#く
によ#どみ
によ#り
によ#ろこ
によ#ろし
によ#ろしく
のか#か
のか#ぎ裂
のか#けら
のか#しら
のか#すか
のか#ばん
のか#まど
のか#もしれ
のか#わいい
のか#わいく
のかな#い
のかな#ど
のかな#り
のかな#んて
のかな#んと
のが#ら空
のが#んばり
のこって#り
のせ#い
のせ#めぎ
のだ#いぶ
のだ#から
のだ#さ
のだ#し
のだ#す
のだ#せ
のだ#そ
のだ#め
のだ#んまり
のだけ#れど
ので#かい
ので#き
ので#こぼこ
のです#ぐ
のです#ぐに
のです#ご
のです#ら
のです#んなり
のど#ういう
のど#ういった
のど#うでも
のど#こ
のど#たばた
のど#ちら
のど#れ
のど#んな
のに#こにこ
のに#じ%まみむめもん
のに#じん
のに#ゃ
のに#ゅ
のに#ょ
のに#んじん
のにも#う
のは#がき
のは#ざま
のは#しっこ
のは#しゃ%がぎぐげご
のは#じま%らりるれろ
のは#じめ
のは#ちみつ
のは#められ
のはず#る
のはず#れ
のまん#ま
のみ#すぼらし
のみ#な
のみ#んな
のめ#ちゃくちゃ
のめちゃ#くちゃ
のも#ふもふ
のも#ろもろ
のも#んだ
のもう#なずけ
のもの#だね
のや#ばい
のや#ばく
のや#ばさ
のや#ばすぎ
のや#ばそう
のよう#す
はいた#ずら
はかな#り
はき#ちんと
はき#ょとん
はき#らきら
はき#れい
はき#わめ
はく#すくす
はく#れ%るぬ
はく#れない
はく#れません
はけ#して
はざま#あ
はず#いぶん
はず#かずか
はず#るい
はず#るく
はず#るそう
はせ#いぜい
はせ#めて
はたと#え
はたまた#ま
はて#めえ
はて#めぇ
はなす#すべ
はまった#く
はめ#げ
はめ#ぐ%らりるれろん
はめ#まぐるし
はめ#ちゃくちゃ
はめちゃ#くちゃ
はや#%らりるれろん
はや#けに
はや#たら
はや#ばい
はや#むを
はや#めた
はや#めて
はや#れやれ
はや#ろう
はや#わらか
はやさ#ぐれ
はやめ#ていただ
ほうばっ#かり
ませんか#%いしつともら
までも#う
までも#ら%わいうえおっ
みて#ため
みな#おさ
みな#おし
みな#おす
みな#がら
みな#ど
みな#んて
むく#らい
むしろう#ち
も#しばらく
もう#かがえ
もう#ち
もう#なず%いかきくけこ
もう#まい
もう#まかった
もう#るさ
もう#るさい
もう#れしい
もう#れしく
もう#ろ覚
もうし#ばらく
もうす#ごい
もし#かたがない
もし#かたない
もし#た
もし#ちゃう
もし#て
もし#ない
もし#なかった
もし#なく
もし#なければ
もし#ばしば
もし#ばらく
もし#ます
もし#ゃ
もし#ゅ
もし#ょ
もし#れっと
もして#くれ
もたらした#まえ
もち#らほら
もつ#%いきくけこ
もつ#かない
もつ#かなく
もつ#なが
もつか#ない
もつか#なく
もの#ろけ
もの#んびり
もみ#んな
もめ#げず
もめ#げない
やめた#まえ
ようにも#の
よくも#うすぐ
よくもう#すぐ
よそ#りゃ
よりたい#てい
られた#まえ
られたく#らい
られたら#し%いかきくけこ
られてた#し%いかきくけこ
られるか#も
られるか#ら
れた#が%っらりるれろ
わいた#い
わな#い
んだよ#う
んだわ#たくし
んだわ#たし
んです#む
切っても#てな
同じく#らい
少しく#だけ
探しな#んて
来れたら#しい
燃えた#ぎらせ
生か#ら
画す#べき
画す#る
褒めた#たえる`;

function dummy_warndic_org(){}
const warndic_org = 
`あいずち/→あいづち(相槌..)
いおお/→いおう(言おう,硫黄..)
いかづち/いかずち(雷)
いきどうる/→いきどおる(憤る)
いづれ/→いずれ(何れ)
いなづま/→いなずま(稲妻)
うず高/→うずたか[く](堆[く])
うなづ[い,か,き,く,け,こ]/→うなず%(頷%)
おうい/→おおい(多い)／　◎おうい(王位,王威..)
おうかみ/→おおかみ(狼,オオカミ)
おうき/→おおき[い](大き[い])
おうせ/→おおせ(仰せ)
おうぜい/→おうぜい(大勢)
おうむね/→おおむね(概ね)
おうよそ/→おおよそ(凡そ)
おおさま/→おうさま(王様)
おおせい/→おうせい(旺盛, 王政)
おとづれ/→おとずれ[る](訪れ[る])
かしづ[い,か,き,く,け,こ]/→かしず%(傅%)
かねかね/→かねがね
がねかね/→かねがね
がねがね/→かねがね
がらから/→からがら
ぐれくれ/→くれぐれ
ぐれぐれ/→くれぐれ
こうり/→こおり(氷)
こじんまり/×→こぢんまり
こまこま/→こまごま
これっぼっち/→これっぽっち
こんにちわ/→こんにちは／　△こんにちわ
こんばんわ/→こんばんは／　△こんばんわ
ごとこと/→ことごと
ごまこま/→こまごま
ごまごま/→こまごま
ごりこり/→こりごり
ささめく/→さざめく
ざざめく/→さざめく
ざまさま/→さまざま
ざまざま/→さまざま
ざんさん/→さんざん
したします/→いたします(致します)
しましました/→しまいました
しみしみ/→しみじみ
じみしみ/→しみじみ
じみじみ/→しみじみ
すいません/→すみません
すいませーん/→すみませーん
ず[いて,いた]/→づいて([色]付%..)
ずかい/→づかい([色]使い,遣い..)
ずかな[い,か,く,ければ]/→ずかない([色]付かない..)
ずくし/→づくし([松茸]尽くし..)
ずくり/→づくり(作り,造り)
ずくろい/→づくろい([毛]繕い)
ずもり/→づもり(積もり)
ずらい/→づらい([扱い]辛い..)
ずらかった/→づらかった([扱い]辛らかった..)
ずらく/→づらく([扱い]辛らく..)
ずらさ/→づらさ([扱い]辛らさ..)
ずらそう/→づらそう([扱い]辛らそう..)／　◎ずらそう(ズラそう:移動する)
ぜいせい/→せいぜい
ぞれそれ/→それぞれ
ぞれぞれ/→それぞれ
たかたか/→たかだか
たけたけ/→たけだけ
たたちに/→ただちに
だかたか/→たかだか
だかだか/→たかだか
だけたけ/→たけだけ
だけだけ/→たけだけ
だだちに/→ただちに
ちかじか/→ちかぢか(近々)
ぢゃない/→じゃない
つくつく/→つくづく
つず[い,か,き,く,け,こ]/→つづ%(続%)
つず[っ,ら,り,る,れ,ろ]/→つづ%(綴%)
つねずね/→つねづね(常々)
つねつね/→つねづね(常々)
つまづ[い,か,き,く,け,こ]/→つまず%(躓%)
づくつく/→つくづく
づくづく/→つくづく
づくめ/→ずくめ([黒,良いこと]尽くめ)
づつ/→[3個]ずつ
づれ[すぎ,そう,て,た,ない,なかっ,なく,なければ,る,ます,ました,ません]/→ずれ%(ズレ%:滑って動く)／　◎づれ%(連,釣,吊,攣れ%)
とう[っ,ら,る,れ,ろ]/→とお%(通%)
とうり/→とおり(通り) or どうり(道理)
とおさん→とうさん
とおちゃん→とうちゃん
ときとき/→ときどき
とりとり/→とりどり
どう[ら,り,る,れ,ろ]/→どお%(通%)
どきとき/→ときどき
どりとり/→とりどり
どりどり/→とりどり
とおの昔/→とうの昔●●●●●未実装
なかんづく/→なかんずく(就中)
なりおうせ[すぎ,そう,て,た,ない,なかっ,なく,なければ,る,ます,ました,ません]/なりおおせ%
はるはる/→はるばる(遥々)
ばるはる/→はるばる(遥々)
ばるばる/→はるばる(遥々)
ひきづ[ら,り,る,れ,ろ,っ]/→ひきず%(引きず%)
ひざまづ[い,か,き,く,け,こ]/→ひざまず%(跪%)
ひずめ/→ひづめ
ふいんき/→ふんいき(雰囲気)
ふてふて/→ふてぶて
ぶてふて/→ふてぶて
ぶてぶて/→ふてぶて
ほうば[った,って,っ,ら,り,る,れ,ろ]/→ほおば%(頬張%)
ほそほそ/→ほそぼそ
ほどんど/→ほとんど(殆ど)
ほのう/→ほのお(炎)
ほのほの/→ほのぼの
ぼそほそ/→ほそぼそ
ぼそぼそ/→ほそぼそ
ぼのほの/→ほのぼの
ぼのぼの/→ほのぼの
むづかし/→むずかし(難し[い])
もしくわ/→もしくは(若しくは)
もよう[さない,さ,し,す,せ,そう,そ]/→もよお%(催%)
やむおえ[ない,なか,なき,なく,なけ,ず,ぬ,ん]/→やむをえ%(止むを得%)
やもおえ[ない,なか,なき,なく,なけ,ず,ぬ,ん]/→やむをえ%(止むを得%)
やもをえ[ない,なか,なき,なく,なけ,ず,ぬ,ん]/→やむをえ%(止むを得%)
ゆ[わない,わ,い,う,えそう,えない,えば,える,えた,えて,おう,った,って]/→い%(言%)／　◎ゆ%(結%)
ゆおお/→いおう(言おう)／　◎ゆおう(結おう)
ゆはない/→いわない(言わない)／　◎ゆわない(結わない)
ろおそく/→ろうそく(ロウソク,蝋燭)
わずらし[い,か,く,すぎ]/→わずらわし-い(煩わし-い)
今だに/→未だに
力づく/→力ずく
引きづ[っ,ら,り,る,れ,ろ]/→引きず%(ひきず%)
木ずち/→木づち(槌,鎚)
火やぶり/→火あぶり
煩し/→煩わし-い
腕づく/→腕ずく
膝まづ[い,か,き,く,け,こ]/×→跪%(ひざまず%)
金ずち/→金づち(槌,鎚)
額づ[い,か,き,く,け,こ]/→額ず%(ぬかず%)
駆けづり/→駆けずり
`;

const kanji_pre_dic_org = 
`アツ/形容詞
イ/五段イク
イジ/五段ラ
イカれ/下一段
ウザ/形容詞
ガキんちょ
キツ/形容詞
キモ/形容詞
キレ/下一段
ギュッて
クラスいち
クソったれ
グレ/下一段
グロ/形容詞
コケ/下一段
サボ/五段ラ
シメ/下一段
スレ/下一段
ズラ/五段サ
ズレ/上一段
ダサ/形容詞
ダメさ
ッて/サ変
ツッコ/五段マ
テコいれ
デカ/形容詞
デレ/下一段
ノ/五段ラ
ハゲ/下一段
バカげ/下一段
バテ/下一段
バレ/下一段
ビビ/五段ラ
ピンと
ピンときた
ブレ/下一段
プレイヤーたち
プレイヤーら
ボケ/下一段
ボケて
ボロ/形容詞
マツぼっくり
メンバーたち
メンバーら
モテ/下一段
モフ/五段ラ
ヤバ/形容詞
ワザとらし/形容詞
一切れ
一切れずつ
一目ぼれ
一緒くた
万事休す
上/五段ラ
上が/五段ラ
上げ/下一段
上ず/五段ラ
上手/形容詞
上手くい/五段イク
下/五段サ
下/五段ラ
下が/五段ラ
下げ/下一段
下さ/五段ラ
下さい
下にくま
下り/上一段
下ろ/五段サ
不味/形容詞
不安げ
不死になる
与え/下一段
且つ
並/五段バ
並べ/下一段
丸/形容詞
丸っこ/形容詞
丸ま/五段ラ
丸め/下一段
久しぶり
乗/五段ラ
乗じ/上一段
乗せ/下一段
乗っか/五段ラ
乗っけ/下一段
乞/五段ワ
乱/五段サ
乱れ/下一段
乾/五段カ
予め
争/五段ワ
事無かれ
事無く
互い
五月蝿/形容詞
亡/五段バ
亡く/五段サ
亡くな/五段ラ
亡ぼ/五段サ
交え/下一段
交じ/五段ラ
交ぜ/下一段
交わ/五段サ
交わ/五段ラ
人っきり
人づきあい
人なつっこ/形容詞
人びと
人懐っこ/形容詞
人集り
仇なす
仇名す
今しがた
今だに
介/五段サ
仕え/下一段
付/五段カ
付け/下一段
代/五段ラ
代わ/五段ラ
以て
仰/五段ガ
仰/五段ラ
仰せ
仰仰し/形容詞
任/五段サ
任じ/上一段
任せっきり
任ぜられ
企/五段マ
企て/下一段
企てて
伏/五段サ
伏せ/下一段
休/五段マ
休ま/五段ラ
会/五段ワ
会わ/五段サ
会話
伝/五段ワ
伝え/下一段
伝わ/五段ラ
伴/五段ワ
伸ば/五段サ
伸び/上一段
伸べ/下一段
伺/五段ワ
似/上一段
似せ/下一段
似つかわしく
似てい/上一段
佇/五段マ
位置づけ
低/形容詞
低め
住/五段マ
住ま/五段ワ
体たらく
何せ
何だか
何て
何らか
何れ
余/五段サ
余/五段ラ
余裕ぶっこ/五段カ
作/五段ラ
佩/五段カ
併/五段サ
使/五段ワ
使いき/五段ラ
使いきり
使いみち
例え/下一段
例えば
例にもれず
侍ら/五段サ
依/五段ラ
侮/五段ラ
侮りがた/形容詞
侵/五段サ
便り
係り
促/五段サ
保/五段タ
信じ/上一段
信/ザ変
修め/下一段
俯/五段カ
俯/五段サ
俺んち
倒/五段サ
倒れ/下一段
倒壊
借り/上一段
倣/五段ワ
偉/形容詞
偏/五段ラ
停/五段マ
偲/五段バ
偽/五段ラ
傅/五段カ
備え/下一段
催/五段サ
傷/五段マ
傷め/下一段
傾/五段カ
傾/五段ガ
傾げたい
傾げたく
傾め
働/五段カ
僕んち
儚/形容詞
償/五段ワ
優し/形容詞
優れ/下一段
儲か/五段ラ
充て/下一段
先ず
先っちょ
先っぽ
先んじ/上一段
先生
先細/五段ラ
克/五段タ
光/五段ラ
免じ/上一段
免れ/下一段
入/五段ラ
入りびた/五段ラ
入れ/下一段
全う
全う/サ変
全く
全て
八方ふさがり
再び
冒/五段サ
写/五段サ
冷え/下一段
冷た/形容詞
冷ま/五段サ
冷め/下一段
冷や/五段サ
冷やか/五段サ
凄/五段マ
凄/形容詞
凄まじ/形容詞
凌/五段ガ
凍/五段ラ
凍え/下一段
凍てつ/五段カ
凛凛し/形容詞
凝/五段ラ
凝ら/五段サ
処/五段サ
凪/五段ガ
凪ぎ
凭れ/下一段
凹/五段マ
出/下一段
出/五段サ
出かけ/下一段
出くわ/五段サ
出しっぺ
出しゃば/五段ラ
出てから
出ま/五段サ
出来/上一段
分/五段カ
分/五段ラ
分か/五段ラ
分かりゃしない
分かりゃあしない
分れ/下一段
分離
切/五段ラ
切っかけ
切ら/五段サ
切れ/下一段
刈/五段ラ
列/サ変
初っぱな
初め/下一段
初初し/形容詞
判/五段ラ
別れ/下一段
利/五段カ
刷/五段ラ
刺/五段サ
刺さ/五段ラ
刻/五段マ
剃/五段ラ
削/五段ガ
削/五段ラ
前んち
剝/五段カ
剝/五段ガ
剝/五段サ
剝が/五段サ
剝がれ/下一段
剣なぎ
剥/五段カ
剥/五段ガ
剥/五段サ
剥が/五段サ
剥がれ/下一段
割/五段カ
割/五段ラ
割れ/下一段
創/五段ラ
劈/五段カ
力ずく
力づく
力尽く
加え/下一段
劣/五段ラ
助か/五段ラ
助け/下一段
努め/下一段
励/五段マ
励ま/五段サ
労/五段ワ
効/五段カ
勉強
動/五段カ
動か/五段サ
動じ/上一段
勘ぐ/五段ラ
勘づ/五段カ
勘付/五段カ
勘違/五段ワ
務/五段マ
務ま/五段ラ
勝/五段タ
勝手知ったる
募/五段ラ
勢い
勢いよく
勤し/五段マ
勤ま/五段ラ
勤め/下一段
勧/五段マ
匂/五段ワ
包/五段マ
化/五段サ
匿/五段ワ
半ば
半べそ
半べそ
半壊
占め/下一段
危う/形容詞
危な/形容詞
危なっかし/形容詞
危ぶまれ/下一段
即ち
卸/五段サ
厚/形容詞
原っぱ
厭/五段ワ
厳し/形容詞
厳然たる
去/五段ラ
参/五段ラ
参じ/上一段
及/五段バ
及び
及ぼ/五段サ
反/五段ラ
反ら/五段サ
収ま/五段ラ
収め/下一段
取/五段ラ
取れ/下一段
取締/五段ラ
受け/下一段
口ごも/五段ラ
口ずさ/五段マ
口づけ
古/形容詞
古び/上一段
古め
叩/五段カ
叩きつけ/下一段
叩きのめ/五段サ
叫/五段バ
召/五段サ
可愛/形容詞
可愛いくて
可笑し/形容詞
叱/五段ラ
叶/五段ワ
司/五段ラ
吃/五段ラ
合/五段サ
合/五段ワ
合わ/五段サ
合わさ/五段ラ
吊/五段ラ
同じ
同じく
同じくらい
名指し
名指し/サ変
吐/五段カ
吐しゃ
向/五段カ
向か/五段ワ
吞/五段マ
吠え/下一段
否め
否めない
含/五段マ
含め/下一段
吸/五段ワ
吹/五段カ
吹っかけ/下一段
呆れ/下一段
呈/五段サ
告/五段ガ
呑/五段マ
呟/五段カ
周り
呪/五段ワ
味わ/五段ワ
味わい
呷/五段ラ
呻/五段カ
呼/五段バ
呼ばわり
命じ/下一段
和/五段マ
和ら/五段ガ
和らげ/下一段
咎め/下一段
咬/五段マ
咲/五段カ
咽び
哀し/形容詞
哀れ/五段マ
哀れな
品ぞろえ
唱え/下一段
唸/五段ラ
問/五段トウ
啜/五段ラ
喋/五段ラ
喘/五段ガ
喚/五段カ
喚/五段バ
喜/五段バ
喜ば/五段サ
喜ばし/形容詞
喰/五段ワ
喰いぶち
喰ら/五段ワ
喰らいつ/五段カ
営/五段マ
嗄れ/下一段
嗅/五段ガ
嗤/五段ワ
嘆/五段カ
嘆かわし/形容詞
嘗め/下一段
嘘っぱち
嘲/五段ラ
噓っぱち
噛/五段マ
噛りつ/五段カ
噛り付/五段カ
噤/五段マ
噴/五段カ
嚙/五段マ
嚙りつ/五段カ
嚙り付/五段カ
囀/五段ラ
囁/五段カ
回/五段サ
回/五段ラ
因みに
困/五段ラ
囲/五段マ
囲/五段ワ
図/五段ラ
図図し/形容詞
固/形容詞
固ま/五段ラ
固め
固め/下一段
土ぼこり
在/五段ラ
地べた
垂ら/五段サ
垂れ/下一段
埋ま/五段ラ
埋め/下一段
埋もれ/下一段
執り
基/五段カ
基づ/五段カ
堀/五段ラ
堅/形容詞
堕ち/上一段
堪/五段ラ
堪えき/五段ラ
報じ/上一段
報せ
報せ/下一段
塗/五段ラ
塞/五段ガ
塞が/五段ラ
塡ま/五段ラ
塡め/下一段
填ま/五段ラ
填め/下一段
増/五段サ
増え/下一段
増や/五段サ
墜/五段サ
墜ち/上一段
墜と/五段サ
壊/五段サ
壊れ/下一段
売/五段ラ
売れ/下一段
変え/下一段
変わ/五段ラ
変わり
外/五段サ
外れ/下一段
多/形容詞
多からん
多からんこと
多かれ
多くい/上一段
多め/下一段
多分
多少
大き/形容詞
大きさ
大きな
大きめ
大げさ
大っぴら
大まか
大人し/形容詞
大人び/上一段
天ぷら
太/五段ラ
太/形容詞
太っちょ
太め
太め/下一段
太めな
太もも
太太し/形容詞
失/五段ワ
失く/五段サ
失せ/下一段
奇をてら/五段ワ
奏で/下一段
契/五段ラ
奢/五段ラ
奥ゆかし/形容詞
奨め/下一段
奪/五段ワ
奪いつ/五段カ
女女し/形容詞
好/五段マ
好かれ/下一段
好き
好まし/形容詞
如く
妖しげ
妨げ/下一段
妬/五段マ
始ま/五段ラ
始め/下一段
姿かたち
威張りくさ/五段ラ
娶/五段ラ
媚び/上一段
嫁/五段ガ
嫉まし/形容詞
嫌/五段ワ
嫌い
嫌いな
嫌が/五段ラ
嫌がらせ
嬉し/形容詞
嬲/五段ラ
孕/五段マ
存じ/上一段
存ぜぬ
学/五段バ
学校いち
守/五段ラ
安/形容詞
安め
安ら/五段ガ
完ぺき
宙ぶらりん
定ま/五段ラ
定め/下一段
宛が/五段ワ
宛て
実/五段ラ
宥め/下一段
害をなす
宿/五段サ
宿/五段ラ
寂し/形容詞
寂れ/下一段
寄/五段ラ
寄こ/五段サ
寄せ/下一段
富/五段マ
寒/形容詞
寒寒し/形容詞
寛/五段ガ
寝/下一段
寝/五段ラ
寝か/五段サ
寝そべ/五段ラ
寝ぼけ/下一段
察せ/下一段
寸分たがわない
寸分たがわぬ
封じ/上一段
射/上一段
射/五段サ
尊/五段バ
尊/形容詞
尋ね/五段ラ
導/五段カ
小さ/形容詞
小ささ
小さな
小さめ
小じんまり
小っちゃ/形容詞
小ぶり
少し
少しくだけ
少しくだけた
少しくだけて
少し/形容詞
少しなら
少な/形容詞
少なからず
少なかれ
少なめ
尖/五段サ
尖/五段ラ
尖ら/五段サ
就/五段カ
尻すぼみ
尻もち
尽く/五段サ
尽くせり
尾ひれ
尾びれ
居/上一段
屈/五段マ
屈め/下一段
届/五段カ
届け/下一段
属/五段サ
履/五段カ
崇め/下一段
崖っぷち
崩/五段サ
崩れ/下一段
嵌/五段ラ
嵌ま/五段ラ
嵌め/下一段
嵩/五段マ
巡/五段ラ
巡ら/五段サ
巧/形容詞
差/五段サ
已むなく
巻/五段カ
巻きたち
帯び/上一段
帰/五段サ
帰/五段ラ
常とう
干/五段サ
干からび/上一段
干乾び/上一段
平た/形容詞
平べったい
平らげ/下一段
幸い
幸せ
幸せな
幼/形容詞
幾つ
幾ばく
広/形容詞
広が/五段ラ
広げ/下一段
広ま/五段ラ
広め
広め/下一段
広広し/形容詞
庇/五段ワ
座/五段ラ
座/五段ワ
廃れ/下一段
延ば/五段サ
延び/上一段
建/五段タ
建て/下一段
廻/五段サ
廻/五段ラ
弄/五段バ
弄/五段ラ
引/五段カ
引きず/五段ラ
引きつ/五段ラ
引きはが/五段サ
引っ
引っかか/五段ラ
引っかけ/下一段
引っくり
引っこ
引っぱ/五段ラ
弱/五段ラ
弱/形容詞
弱っち/形容詞
弱ま/五段ラ
弱め/下一段
弱らせ/下一段
弱弱し/形容詞
張/五段ラ
強/形容詞
強ま/五段ラ
強め
強め/下一段
強めな
弾/五段カ
弾/五段マ
当/五段タ
当/五段ラ
当た/五段ラ
当てずっぽう
彩り
彫/五段ラ
彷徨/五段ワ
待/五段タ
待ちぼうけ
後ずさ/五段ラ
後れ
後ろ
後ろめた/形容詞
後ろめたい
後退/五段ラ
従/五段ワ
得/下一段
得意げ
得意げな
微笑/五段マ
微笑まし/形容詞
微笑ましげ
心がけ/下一段
心づもり
必ず
必ずいる
必死
忌/五段マ
忌忌し/形容詞
忍/五段バ
志/五段サ
忘れ/下一段
忙し/形容詞
応え/下一段
応じ/上一段
快く
念じ/上一段
念話
忽ち
怒/五段ラ
怒ら/五段サ
怖/形容詞
怖じ/上一段
怖れ/下一段
怖ろし/形容詞
思/五段ワ
思いきや
思いきり
思いた/五段タ
思いっきり
思いつ/五段カ
思いつつ
思いつめ/下一段
思いやる
思うまま
思しき
思わしく
怠らず
急/五段ガ
急きょ
怪し/五段マ
怪し/形容詞
怯/五段マ
怯え/下一段
恐/形容詞
恐らく
恐るる
恐れ/下一段
恐ろし/形容詞
恥じ/上一段
恥じら/五段ワ
恥ずかし/形容詞
恥ずかしながら
恥ら/五段ワ
恨/五段マ
恨めし/形容詞
息づ/五段カ
恵まれ/下一段
悉く
悍まし/形容詞
悔し/形容詞
悟/五段ラ
悦/五段バ
悩/五段マ
悩まし/形容詞
悪/形容詞
悪びれ/下一段
悪ぶ/五段ラ
悲し/五段マ
悲し/形容詞
悲しみにくれ
悼/五段マ
惑/五段ワ
惑わ/五段サ
惚け/下一段
惚れ/下一段
惜し/五段マ
惜しげも
惨め
惨めさ
想/五段ワ
惹/五段カ
愉し/形容詞
意
愚痴り
愛/五段サ
愛い
愛おし/五段マ
愛し/五段マ
感じ/上一段
感づ/五段カ
慈し/五段マ
慌て/下一段
慎/五段マ
慎まし/形容詞
慕/五段ワ
慣ら/五段サ
慣れ/下一段
慣れっこ
憂う
慰め/下一段
憎/五段マ
憎/形容詞
憎き
憎憎し/形容詞
憐れ/五段マ
憑/五段カ
憑/五段マ
憑/五段ラ
憤/五段ラ
憧れ/下一段
懇ろ
懐/五段カ
懐かし/形容詞
懐かしむ
懐っこい
懲/五段ラ
懲らしめ/下一段
懲り/上一段
懸か/五段ラ
成/五段サ
成/五段ラ
成すすべ
戒め
戒め/下一段
戦/五段ワ
戯れ/下一段
戸締り
戻/五段サ
戻/五段ラ
手がけ/下一段
手こず/五段ラ
手ごわい
手ずから
手づかみ
手のひら
手ほどき
打/五段タ
打ちすえ/下一段
打ちのめした
打ちひしが/五段ラ
払/五段ワ
扱/五段ワ
承/五段ラ
抉/五段ラ
抑え/下一段
投げ/下一段
投じ/下一段
抗/五段ワ
抗わ/五段サ
折/五段ラ
抜/五段カ
抜か/五段サ
抜け/下一段
抱/五段カ
抱え/下一段
抱きつ/五段カ
抱っこ
押/五段サ
押さえ/下一段
押しつけがまし
担/五段ガ
担/五段ワ
拒/五段マ
拗ね/下一段
拗らせ/下一段
拗れ/下一段
拘/五段ラ
拙/五段カ
招/五段カ
拝/五段マ
拠り
拡げ/下一段
括/五段ラ
拭/五段カ
拭/五段ワ
拵え/下一段
拾/五段ワ
持/五段タ
持た/五段サ
持たれつ
持ちつ
持ちつつ
持ってい/五段イク
指/五段サ
挑/五段マ
挙げ/下一段
挟/五段マ
挟ま/五段ラ
挫/五段カ
振/五段ラ
振りほど/五段カ
振る/五段ワ
挿/五段マ
捌/五段カ
捕/五段マ
捕/五段ラ
捕ま/五段ラ
捕まえ/下一段
捕らえ/下一段
捗/五段ラ
捜/五段サ
捜/五段ラ
捧げ/下一段
捨て/下一段
捩じ/五段ラ
据え/下一段
捲/五段ラ
捲れ/下一段
捻/五段ラ
捻じ/上一段
授か/五段ラ
授け/下一段
掘/五段ラ
掛か/五段ラ
掛かり
掛かる
掛け/下一段
掠/五段ラ
掠め/下一段
採/五段ラ
探/五段サ
探/五段ラ
接/五段ガ
控え/下一段
控えめ
推/五段サ
掬/五段ワ
掲げ/下一段
掴/五段マ
掴ま/五段ラ
掴まえ/下一段
掻/五段カ
揃/五段ワ
揃え/下一段
揉/五段マ
揉め/下一段
描/五段カ
提げ/下一段
揚げ/下一段
換え/下一段
換わ/五段ラ
握/五段ラ
握ら/五段サ
握握し/形容詞
揶揄/五段ワ
揺/五段ラ
揺さぶ/五段ラ
揺ら/五段ガ
揺ら/五段サ
揺らめ/下一段
揺らめ/五段カ
揺る/五段ガ
揺るが/五段サ
揺れ/下一段
損な/五段ワ
搦め
携え/下一段
搾/五段ラ
摂/五段ラ
摘/五段マ
摘ま/五段マ
摺/五段ラ
撃/五段タ
撒/五段カ
撫で/下一段
撫でくり
撮/五段ラ
擂/五段ラ
操/五段ラ
擦/五段ラ
擽った/形容詞
攣/五段ラ
攫/五段ワ
支え/下一段
改ざん
改め/下一段
攻め/下一段
放/五段サ
放/五段タ
放/五段ラ
敏/形容詞
救/五段ワ
敗/五段ラ
教え/下一段
教わ/五段ラ
敢えず
散/五段ラ
散ら/五段サ
散らば/五段ラ
散りばめ/下一段
敬/五段ワ
数え/下一段
数分
整/五段ワ
敵/五段ワ
敷/五段カ
斃/五段サ
斜め
斬/五段ラ
断/五段タ
断/五段ラ
断じ/上一段
断たれ/下一段
断わ/五段ラ
新し/形容詞
新た
施/五段サ
日にち
日向ぼっこ
旨/形容詞
旨くい/五段カ
早/形容詞
早かれ
早とちり
早ま/五段ラ
早め/下一段
早めな
昂ぶ/五段ラ
昇/五段ラ
明かり
明け/下一段
明らか
明り
明る/形容詞
昏倒
易/形容詞
易し/形容詞
映/五段サ
映/五段ラ
映え/下一段
時がたち
時たま
晒/五段サ
晴ら/五段サ
晴れ/下一段
暑/形容詞
暖か/形容詞
暖ま/五段ラ
暖め/下一段
暗/形容詞
暗め/下一段
暫く
暮/五段サ
暮ら/五段サ
暮れ/下一段
暴/五段カ
暴れ/下一段
曇/五段ラ
曝/五段サ
曰く
曲が/五段ラ
曲がりくねった
曲がりくねる
曲がりなりに
曲がりなりにも
曲げ/下一段
書/五段カ
書きため
書きなぐ/五段ラ
替え/下一段
替わ/五段ラ
最た
有/五段サ
有/五段ラ
望/五段マ
望まし/形容詞
望むらくは
朝っぱら
期/五段サ
木こり
末永く
朽ち/上一段
来い
来た
来たきり
来たっきり
来たれ
来ちゃ
来て
来ている
来てから
来てない
来てる
来ない
来る
来れ
来れそう
来れた
来れたら
来れて
来れない
来れる
松ぼっくり
果た/五段サ
果て/下一段
枯れ/下一段
染ま/五段ラ
染め/下一段
柔らか
柔らか/形容詞
栄え/下一段
根こそぎ
根ざ/五段サ
根っこ
案じ/上一段
梳/五段カ
棲/五段マ
植え/下一段
植わ/五段ラ
検め/下一段
極ま/五段ラ
極まれり
極め/下一段
楽し/五段マ
楽し/形容詞
楽ちん
構/五段ワ
模/五段ラ
横たわ/五段ラ
横なぎ
欠/五段カ
欠け/下一段
欠けら
次/五段ガ
欲し/形容詞
欺/五段カ
歌/五段ワ
歓/五段バ
止/五段マ
止ま/五段ラ
止め/下一段
正/五段サ
正し/形容詞
歩/五段カ
歩/五段マ
歪/五段マ
歯がゆ/形容詞
歯ぎしり
死/五段ナ
死にぞこな/五段ワ
死んじま/五段ワ
殆ど
殆どの
殆んど
殉/ザ変
残/五段サ
残/五段ラ
殴/五段ラ
殺/五段サ
殺/五段ラ
殺し
毒づ/五段カ
毒毒し/形容詞
比べ/下一段
毛がよだつ
毛のよだつ
毛もよだつ
気がつ/五段カ
気づ/五段カ
気に
気にな/五段ラ
気になさらず
気になさらないで
気になさる
気もそぞろ
気付/五段カ
気持ち
気持ちい
気持ちい/形容詞
気持ちよ/形容詞
気持ちよさげ
水あめ
水浸しにな/五段ラ
永/形容詞
永遠たれ
求/五段マ
求め/下一段
汗だく
汗ば/五段マ
汚/五段サ
汚/形容詞
汚れ/下一段
汲/五段マ
決ま/五段ラ
決め/下一段
沈/五段マ
沸/五段カ
沸か/五段サ
治/五段サ
治/五段ラ
治ま/五段ラ
治め/下一段
沿/五段ワ
沿ぐ/五段ワ
泊/五段マ
泊/五段ラ
泊ま/五段ラ
泣/五段カ
泣きべそ
泥んこ
注/五段ガ
泳/五段ガ
洗/五段ワ
洩ら/五段サ
洩れ/下一段
活か/五段サ
活き
流/五段サ
流れ/下一段
流行り
浅/形容詞
浅からぬ
浅はか
浮/五段カ
浮か/五段バ
浴び/上一段
浴びせ/下一段
浸/五段ラ
浸か/五段ラ
消/五段サ
消え/下一段
涌/五段カ
涙ぐ/五段マ
涙ぐまし/形容詞
涸れ/下一段
涼/五段マ
涼し/形容詞
淀/五段マ
淋し/形容詞
淡/形容詞
深/形容詞
深ま/五段ラ
深め/下一段
混/五段マ
混ざ/五段ラ
混じ/五段ラ
混ぜ/下一段
混む
淹れ/下一段
添/五段ワ
清/形容詞
清め/下一段
清清し/形容詞
渇/五段カ
済/五段マ
済ま/五段サ
渋/五段ラ
渋/形容詞
減/ザ変
減/五段ラ
減ら/五段サ
渡/五段サ
渡/五段ラ
温か/形容詞
温ま/五段ラ
温め/下一段
温もり
測/五段ラ
湧/五段カ
湯あみ
湿/五段ラ
湿ら/五段サ
満/五段タ
満た/五段サ
満ち/上一段
満足げ
準/ザ変
溜/五段ラ
溜ま/五段ラ
溜め/下一段
溢/五段サ
溢れ/下一段
溶/五段カ
溺れ/下一段
滅/五段バ
滅び/上一段
滅ぼ/五段サ
滑/五段ラ
滑らか
滑らかさ
滞/五段ラ
滲/五段マ
滴/五段ラ
滾/五段ラ
漁/五段ラ
漂/五段ワ
漏えい
漏ら/五段サ
漏れ/下一段
演じ/上一段
漕/五段ガ
漬け/下一段
漲/五段ラ
漸く
潔/形容詞
潔く
潜/五段マ
潜/五段ラ
潜め/下一段
潤/五段サ
潤/五段マ
潤/五段ワ
潰/五段サ
潰れ/下一段
澄ま/五段サ
激おこ
激し/形容詞
濁/五段サ
濁/五段ラ
濃/形容詞
濃いめ/形容詞
濡ら/五段サ
濡れ/下一段
火あぶり
火炙り
灯/五段サ
灯/五段ラ
灯り
災い
炊/五段カ
炒/五段ラ
炒め/下一段
点/五段カ
点/五段サ
為/五段サ
為ごかし
焚/五段カ
無/形容詞
無き
無いまま
無きにしもあらず
無く
無く/五段サ
無くな/五段ラ
焦/五段ラ
焦が/五段サ
焦がれ/下一段
焦げ/下一段
焦ら/五段サ
然り
焼/五段カ
焼きつ/五段カ
焼きた/五段タ
焼け/下一段
煌びやか
煌め/五段カ
煎じ/上一段
照/五段ラ
照ら/五段サ
照れ/下一段
煩/形容詞
煩わ/五段サ
煩わし/形容詞
煮/上一段
煮え/下一段
煮えくり
煮えたぎ/五段ラ
煮えたぎら/五段サ
煮っころがし
煽/五段ラ
煽て/下一段
熟/五段サ
熱/形容詞
燃え/下一段
燃えたぎ/五段ラ
燃や/五段サ
燻/五段サ
燻/五段ラ
爆ぜ/下一段
爛/上一段
爛やか
爛れ/下一段
片っぽ
片づけ
片づけ/下一段
牛耳/五段ラ
物おじ
物怖じ
物物し/形容詞
牽/五段カ
犯/五段サ
狂/五段ワ
狂わ/五段サ
狙/五段ワ
狩/五段ラ
独り
独りごち/上一段
狭/形容詞
猛/五段ラ
猛猛し/形容詞
猫じゃらし
猿ぐつわ
獲/五段ラ
玉ねぎ
珍し/形容詞
現/五段サ
現れ/下一段
瑞瑞し/形容詞
甘/形容詞
甘え/下一段
甘えんぼ
甘ったる/形容詞
甘め
甘やか/五段サ
甘んじ/上一段
甘酢あん
甚く
甚だし/形容詞
生/五段マ
生/五段ラ
生い
生え/下一段
生か/五段サ
生き/上一段
生じ/上一段
生まれ/下一段
生まれたて
生生し/形容詞
産/五段マ
産まれたて
甦/五段ラ
田んぼ
由由し/形容詞
申/五段サ
画/五段サ
畏ま/五段ラ
畏れ/下一段
留ま/五段ラ
留め/下一段
番め
畳/五段マ
畳まな
疎/形容詞
疎まし/形容詞
疎まれ/下一段
疎ら
疎んじ/上一段
疑/五段ラ
疑/五段ワ
疑わし/形容詞
疲れ/下一段
疼/五段カ
病/五段マ
痒/形容詞
痛/五段マ
痛/形容詞
痛まし/形容詞
痛み
痛め/下一段
痛痛し/形容詞
痩せ/下一段
痩せぎす
痺れ/下一段
癒/五段サ
癒や/五段サ
発/五段サ
発/五段タ
発動
登/五段ラ
白/五段マ
白/形容詞
白白し/形容詞
皺くちゃ
盗/五段マ
盗/五段ラ
盛/五段ラ
盛ん
目ざとく
目じり
目ぼし/形容詞
目まぐるし/形容詞
目論/五段マ
直/五段サ
直/五段ラ
直ぐ
直ち
相づち
相容れ/下一段
省/五段カ
看做/五段サ
真っ
眠/五段ラ
眠/形容詞
眠た/形容詞
眠たげ
眩/形容詞
眩し/形容詞
眺め/下一段
着/上一段
着/五段カ
着せ/下一段
睦まじ/形容詞
睨/五段マ
瞑/五段ラ
瞬/五段カ
知/五段ラ
知らしめ
知らしめ/下一段
知らせ/下一段
知らないひと
知らんぷり
短/形容詞
短め
短めな
研/五段ガ
砕/五段カ
破/五段ラ
破け/下一段
破れ/下一段
硬/形容詞
硬め
硬めな
確か
確かにそら
確かめ/下一段
確り
磨/五段カ
磨/五段ラ
示/五段サ
祀/五段ラ
祈/五段ラ
祓/五段ワ
祝/五段ワ
神神し/形容詞
祟/五段ラ
祭/五段ラ
禁じ
禁じ/上一段
禁ずる
禍禍し/形容詞
禿げ/下一段
私め
科/五段サ
秘め/下一段
秘めたる
移/五段サ
移/五段ラ
移動
稼/五段ガ
積/五段マ
積も/五段ラ
穏やか
穢れ/下一段
究め/下一段
空/五段カ
空っぽ
穿/五段カ
穿/五段タ
穿たれ/下一段
突/五段カ
突っ
突っぱね/下一段
窘め/下一段
窶/五段サ
窺/五段ワ
立/五段タ
立ちはだかる
立て/下一段
立てかけ/下一段
竦/五段マ
竦め/下一段
端っこ
競/五段ラ
競/五段ワ
笑/五段マ
笑/五段ワ
答え/下一段
築/五段カ
篭/五段ラ
篭め/下一段
篭も/五段ラ
篭もり
籠め/下一段
籠も/五段ラ
籠もり
籠り
粘/五段ラ
糞ったれ
約分
紅/形容詞
納ま/五段ラ
納む
納め/下一段
紙くず
紛い
紛ら/五段サ
紛らわ/五段サ
紛らわし/形容詞
紛れ/下一段
素晴らし/形容詞
紡/五段ガ
細/形容詞
細か/形容詞
細め
細め/下一段
細めて
細めな
細細し/形容詞
終/五段ラ
終/五段ワ
終わ/五段ラ
組/五段マ
経/五段タ
経ず
結/五段バ
結/五段ワ
結わえ/下一段
絞/五段ラ
絞め/下一段
絡/五段マ
絡ま/五段ラ
統べ/下一段
絶/五段タ
絶や/五段サ
継/五段ガ
続/五段カ
続け/下一段
綴/五段ラ
綴じ/上一段
綻/五段バ
綿あめ
総くずれ
総じ/上一段
総て
締ま/五段ラ
締め/下一段
編/五段マ
緩/五段マ
緩/形容詞
緩め/下一段
緩めな
緩やか
練/五段ラ
縊/五段ラ
縋/五段ラ
縛/五段ラ
縫/五段ワ
縮/五段マ
縮ま/五段ラ
縮め/下一段
縮れ/下一段
繋/五段ガ
繋が/五段ラ
織/五段ラ
繕う
繰/五段ラ
纏/五段ワ
纏ま/五段ラ
纏め/下一段
置/五段カ
置いて/五段イク
置いてい/五段イク
置いてきぼり
置いてけぼり
置いといた
置いといて
罰せ/下一段
罵/五段ラ
美し/形容詞
美味/形容詞
美味し/形容詞
群が/五段ラ
群れ/下一段
羨まし/形容詞
羨/五段マ
羽ばた/五段カ
習/五段ワ
習わ/五段サ
翳/五段サ
翻/五段サ
老いぼれ
考え/下一段
耐え/下一段
耐えき/五段ラ
耕/五段サ
耳たぶ
耽/五段ラ
聞/五段カ
聞こえ/下一段
聡/形容詞
聴/五段カ
肉まん
肉肉し/形容詞
肩がこ/五段ラ
肩すかし
育/五段タ
育/五段マ
育て/下一段
背/五段カ
胸ぐら
脂っこ/形容詞
脅/五段サ
脆/形容詞
脱/五段ガ
脱が/五段サ
腐/五段ラ
腕ずく
腕っぷし
腫れ/下一段
腰ひも
腹いせ
腹ごしらえ
腹ごなし
膝まづ/五段カ
膨ら/五段マ
膨れ/下一段
臨/五段マ
自ず
自殺
臭/五段ワ
臭/形容詞
至/五段ラ
至らしめ/下一段
至り
至れり
致/五段サ
興/五段ラ
興ざめ
興じ/上一段
舌なめずり
舌舐めずり
舐め/下一段
舞/五段ワ
良/形容詞
良いかしら
良からぬ
良かれ
良さそう
色あせ/下一段
色とりどり
色んな
色色し/形容詞
艶かし/形容詞
艶めかし/形容詞
艶艶し/形容詞
芋づる
苔む/五段サ
花びら
苛/五段マ
苛立/五段タ
苛立たし/形容詞
苛苛し/形容詞
若/形容詞
若若し/形容詞
苦/形容詞
苦し/五段マ
苦し/形容詞
苦苦し/形容詞
苦苦しげ
茂/五段ラ
茶化/五段サ
茶色/形容詞
茹で/下一段
草むら
荒/五段バ
荒/五段マ
荒/形容詞
荒げ/下一段
荒ら/五段サ
荒らげ/下一段
荒れ/下一段
荒荒し/形容詞
華やか
華やかさ
華華し/形容詞
萎/五段マ
萎び/上一段
落/五段サ
落ち/上一段
落っこち/上一段
落と/五段サ
葉っぱ
著/五段サ
葬/五段ラ
蒔/五段カ
蒸/五段サ
蒸か/五段サ
蒸ら/五段サ
蒸れ/下一段
蔑/五段マ
蔑ろ
蔓延/五段ラ
薄/形容詞
薄っす/形容詞
薄っすら
薄っぺら
薄め/下一段
薄れ/下一段
薙/五段ガ
薦め/下一段
藹藹し/形容詞
蘇/五段ラ
蘇ら/五段サ
虐げ/下一段
虐め/下一段
虚ろ
虫けら
蝕/五段マ
蝶つがい
蠢/五段カ
血みどろ
行/五段カ
行/五段ワ
行きずり
行きつ/五段カ
行な/五段ワ
行われ/下一段
表/五段サ
表れ/下一段
表示
表記ゆれ
被/五段サ
被/五段ラ
被さ/五段ラ
裁/五段カ
裂/五段カ
装/五段ワ
補/五段ワ
褒め/下一段
褪せ/下一段
褪め/下一段
襲/五段ワ
要/五段ラ
覆/五段サ
覆/五段ワ
覆いつく/五段サ
見/上一段
見いだせない
見え/下一段
見くび/五段ラ
見す見す
見せ/下一段
見せびらか/五段サ
見つか/五段ラ
見つけ/下一段
見つめ/下一段
見よがし
見当もつ/五段カ
見栄っぱり
見紛/五段ワ
視/上一段
覗/五段カ
覚え/下一段
覚えたて
覚ま/五段サ
覚め/下一段
覧にな/五段ラ
親し/形容詞
親しむ
親告
観/上一段
角ば/五段ラ
解/五段カ
解/五段ラ
解く
解け/下一段
解せ/下一段
解れ/下一段
触/五段ラ
触れ/下一段
触/五段ラ
言/五段ワ
言いえて
言いき/五段ラ
言いくるめ/下一段
言いごも/下一段
言いだしっぺ
言いっこなし
言いふら/五段サ
言いよど/五段マ
言ち/上一段
言わ/五段サ
言わしめ/下一段
言わずもがな
言わせ/下一段
言わば
計/五段ラ
計ら/五段ワ
訊/五段カ
訊ね/五段ラ
討/五段タ
託/五段サ
記/五段サ
訛/五段ラ
訝し/五段マ
訝しげ
訪ね/五段ラ
訪れ/下一段
許/五段サ
訳/五段サ
診/上一段
試/五段サ
試/五段マ
詫び/上一段
詰/五段マ
詰ま/五段ラ
詰まらな/形容詞
詰め/下一段
話/五段サ
話題もちきり
詳し/形容詞
誇/五段ラ
誉め/下一段
誉れ
認/五段マ
認め/下一段
誓/五段ワ
誘/五段ワ
語/五段ラ
語ち/上一段
語ら/五段ラ
誤/五段ラ
誤魔化/五段サ
説/五段カ
読/五段マ
課/五段サ
誹/五段ラ
調え/下一段
調べ/下一段
調子こ/五段カ
調子づ/五段カ
請/五段ワ
諌め/下一段
論/ザ変
諦め/下一段
諦めもつく
諫め/下一段
諭/五段サ
謀/五段ラ
謂れ
謗り
講/ザ変
謝/五段ラ
譲/五段ラ
護/五段ラ
負/五段ワ
負け/下一段
負けじと
負わ/五段サ
貢がせ/下一段
貢/五段ガ
貪/五段ラ
貫/五段カ
責め/下一段
貯ま/五段ラ
貯め/下一段
貰/五段ワ
貶/五段サ
貶め/下一段
買/五段ワ
貸/五段サ
費や/五段サ
貼/五段ラ
賄/五段ワ
賑やか
賑やかな
賑わ/五段サ
賑わ/五段ワ
賜/五段ラ
賢/形容詞
質/五段サ
賭け/下一段
贈/五段ラ
赤/形容詞
赤ずきん
赤らめ/下一段
赤赤し/形容詞
赦/五段サ
走/五段ラ
赴/五段カ
起/五段サ
起き/上一段
起こ/五段サ
起こ/五段ラ
起/五段タ
超え/下一段
越/五段サ
越え/下一段
足
足/五段サ
足/五段ラ
足り/上一段
足繁く
跨/五段ラ
跨が/五段ラ
跪/五段カ
跳/五段バ
踊/五段ラ
踏/五段マ
踏まえ/下一段
踏みつけ/下一段
踏みにじ/五段ラ
蹲/五段ラ
蹴/五段ラ
蹴とば/五段サ
蹴りあ/五段ガ
躊躇/五段ワ
躍/五段ラ
躓/五段カ
身じろ/五段ガ
身ごも/五段ラ
躱/五段サ
躾/下一段
車いす
軋/五段マ
軋り
軟らか/形容詞
転/五段バ
転が/五段サ
転が/五段ラ
転げ/下一段
転じ/上一段
転生
軽/形容詞
軽め
軽んじ/上一段
軽軽し/形容詞
載/五段ラ
載せ/下一段
輝/五段カ
輪っか
轟/五段カ
轢/五段カ
轢かれ/下一段
辛/形容詞
辛うじて
辞め/下一段
辱め/下一段
辺り
込/五段マ
込んど/五段カ
辿/五段ラ
辿りつ/五段カ
辿辿し/形容詞
迎え/下一段
近/形容詞
近づ/五段カ
返/五段サ
返/五段ラ
返ら/五段サ
迫/五段ラ
述べ/下一段
迷/五段ワ
迸/五段ラ
迸ら/五段サ
追/五段ワ
追いつ/五段カ
追いつめ/下一段
追いや/五段ラ
追っ
退/五段カ
送/五段ラ
逃/五段サ
逃が/五段サ
逃げ/下一段
逃げおおせ/下一段
逃げのび/上一段
逃れ/下一段
逆ら/五段ワ
透/五段カ
這/五段ワ
這いず/五段ラ
這いつくば/五段ラ
這いつくば/五段ワ
通/五段サ
通/五段ラ
通/五段ワ
通じ/上一段
通せんぼ
逝/五段カ
速/形容詞
速め/下一段
造り
連れ/下一段
進/五段マ
逸ら/五段サ
逸れ/下一段
遂げ/下一段
遅/形容詞
遅かれ
遅め/下一段
遅めな
遅らせ/下一段
遅れ/下一段
遊/五段バ
運/五段バ
運動
過/五段タ
過ぎ/上一段
過ご/五段サ
過ち/上一段
道しるべ
道すがら
道のり
道ばた
達せ/下一段
違/五段ワ
違え/下一段
遠/形容詞
遠ざか/五段ラ
遠ざけ/下一段
遠のく
遡/五段ラ
遣/五段ワ
遣わ/五段サ
遣わしげ
適/五段ワ
遭/五段ワ
遮/五段ラ
選/五段バ
選/五段ラ
選りすぐ/五段ラ
遺/五段サ
避け/下一段
還/五段ラ
邪ま
部分
配/五段サ
配/五段ラ
酔/五段ワ
酔っぱら/五段ワ
酷/形容詞
酸っぱ/形容詞
酸っぱい
醒め/下一段
醜/形容詞
醸/五段サ
重/形容詞
重た/形容詞
重め
重り
重んじ/上一段
重重し/形容詞
野暮ったい
量/五段ラ
金ぴか
釘づけ
釣/五段ラ
鈍/五段ラ
鈍/形容詞
銘じ/上一段
鋭/形容詞
錆び/上一段
録/五段ラ
鍛え/下一段
鎮ま/五段ラ
鎮め/下一段
長/形容詞
長め
長めな
長らく
長生き
閃/五段カ
閉ざ/五段サ
閉じ/上一段
閉ま/五段ラ
閉め/下一段
開/五段カ
開け/下一段
間抜けさ
間違/五段ワ
間違いない
間違いなく
闘/五段ワ
防/五段ガ
阻/五段マ
降/五段ラ
降らし/上一段
降り/上一段
降ろ/五段サ
限/五段ラ
除/五段カ
陥/五段ラ
陰/五段ラ
陰りなく
隅っこ
隔/五段タ
隔て/下一段
際どい
障/五段ラ
隠/五段サ
隠ぺい
隠れ/下一段
隣り
雄雄し/形容詞
集/五段マ
集/五段ラ
集/五段ワ
集ま/五段ラ
集め/下一段
雇/五段ワ
雑じ/五段ラ
離/五段サ
離れ/下一段
難/形容詞
難かし/形容詞
難し/形容詞
雨もり
雨漏り
零/五段サ
零れ/下一段
震/五段ワ
震え/下一段
震わ/五段サ
霞/五段マ
露わ
青/形容詞
青ざめ/下一段
静か
静かな
静けさ
静ま/五段ラ
静め/下一段
非ず
靡/五段カ
面白/形容詞
靴ひも
鞣/五段サ
響/五段カ
頂/五段カ
預か/五段ラ
頬ずり
頬っぺた
頭ごなし
頷/五段カ
頻り
頼/五段マ
頼/五段ラ
頼もし/形容詞
頽れ/下一段
顔だち
顔ぶれ
願/五段ワ
類いまれ
類まれ
顰め/下一段
飛/五段バ
飛ば/五段サ
飛びずさ/五段ラ
飛びぬけ/下一段
飛びの/五段カ
食/五段サ
食/五段ワ
食いしば/五段ラ
食いっぱぐれ
食いつ/五段カ
食いつく/五段サ
食いぶち
食べ/下一段
食ら/五段ワ
食らわ/五段サ
飢え/下一段
飲/五段マ
飼/五段ワ
飽き/下一段
飽きたらず
飽くなき
飽くまで
飾/五段ラ
養/五段ワ
香/五段ラ
香ばし/形容詞
馬鹿げ/下一段
馳せ/下一段
馴/五段ラ
馴ら/五段サ
馴染/五段マ
駆/五段ラ
駆け/下一段
駆けずりまわ/五段ラ
駆動
騒/五段ガ
騒が/五段サ
騒がしい
騒がしく
騒がしさ
騒ぎ
騒騒し/形容詞
騙/五段サ
騙/五段ラ
驕/五段ラ
驚/五段カ
驚か/五段サ
骨ば/五段ラ
高/形容詞
高くそびえ/下一段
高じ/上一段
高ま/五段ラ
高め/下一段
高めな
魅かれ/下一段
魅く
魅せ/下一段
鳴/五段カ
鳴/五段ラ
鳴ら/五段サ
麗し/形容詞
麦わら
黄ば/五段マ
黄色/形容詞
黒/形容詞
黒ず/五段マ
黒黒し/形容詞
黙/五段ラ
黙とう
黙りこく/五段ラ
齎/五段サ
齧/五段ラ
`;

function bin_search_dic(dic, word){
	var left = 0;
	var right = dic.length;
	if(dic.length === 0){
		return -1;
	}
	while(left <= right){
		var center = Math.floor((left + right) / 2);
		var val = dic[center];
		if(val === word){
			return center;
		}
		if(val < word){
			left = center + 1;
		}else{
			right = center - 1;
		}
	}
	return -1;
}

function bin_search_dic_arr1(dic, word){
	var left = 0;
	var right = dic.length;
	if(dic.length === 0){
		return -1;
	}
	while(left <= right){
		var center = Math.floor((left + right) / 2);
		var val;
		if(dic[center] !== undefined){
			val = dic[center][0];
		}else{
			val = undefined;
		}
		if(val === word){
			return center;
		}
		if(val < word){
			left = center + 1;
		}else{
			right = center - 1;
		}
	}
	return -1;
}


function search_ex_dic(exdic, target, word){
	if(target.length < word.length){
		// たーげっとっ　「っゃゅょ」を検出
		if('っゃゅょ'.indexOf(word.charAt(target.length)) !== -1){
			let tto = false;
			if(word.charAt(target.length) === 'っ'){
				if(target.length + 1 <= word.length){
					if( word.charAt(target.length + 1) === 'て'){
						tto = true;
					}
				}
				if(target.length + 2 <= word.length){
					const poi1 = word.substr(target.length + 1, 1);
					const poi2 = word.substr(target.length + 2, 1);
					const poi2_2 = word.substr(target.length + 2, 2);
					// っぽそう　っぽい っぽく
					if(poi1 === 'ぽ' && ('いかきくけ'.indexOf(poi2) !== -1 || poi2_2 == 'そう') ){
						tto = true;
					} else if(poi1 === 'た' && poi2 === 'ら'){
						// ほげったら
						tto = true;
					} else if(poi1 === 'ち' && poi2 === 'ゃ'){
						// 頑張るっちゃ
						tto = true;
					} else if('。、，！？‼⁉」』】］〕≫〉'.indexOf(poi1) !== -1){
						// ばかっ」　そうだっ！
						tto = true;
					}
				}
			}
			if(tto === false){
				return [-2, -2];
			}
		}
	}
	var exdic_len = exdic.length;
	var a = bin_search_dic_arr1(exdic, target);
	if(a !== -1){
		var dic_target = exdic[a][0];
		for(var i = 1; i < exdic[a].length; i++){
			var dic_suffix = exdic[a][i];
			if(0x21 === dic_suffix.charCodeAt(0)){
				// 「いちゃ」「!つ」：「つ」以外の文字列だったら拒否
				if(dic_target.length + dic_suffix.length - 1 <= word.length
					&& dic_suffix.substr(1) !== word.substr(dic_target.length, dic_suffix.length - 1)){
					return [a, i];
				}
			}else if(0x25 === dic_suffix.charCodeAt(0)){
				// 「するか」「%いも」
				if(dic_target.length + 1 <= word.length
					&& -1 != dic_suffix.indexOf(word.charAt(dic_target.length))){
					return [a, i];
				}
			}
			var x = dic_suffix.indexOf('%');
			if(-1 != x){
				var w = dic_suffix.substr(0, x);
				var y = dic_suffix.substr(x + 1);
				if(dic_target.length + w.length + 1 <= word.length
					&& w === word.substr(dic_target.length, w.length)
					&& -1 != y.indexOf(word.charAt(dic_target.length + w.length))){
					// 「あいう」「え%いかきくけこ」
					return [a, i];
				}
			}else{
				if(dic_target.length + dic_suffix.length <= word.length
					&& dic_suffix === word.substr(dic_target.length, dic_suffix.length)){
					return [a, i];
				}
			}
		}
	}
	return [-1, -1];
}

function is_kanji(c){
	if((0x4e00 <= c && c <= 0x9fcf)
		|| (0x3400 <= c && c <= 0x4dbf)
		|| (0xf900 <= c && c <= 0xfadf)
		|| (0x3005 === c)){ // 々
		return true;
	}
	return false;
}

function is_katakana(c){
	if(0x30a1 <= c && c <= 0x30f4){
		return true;
	}
	return false;
}

function hira2dic_expand(dic){
	for(var i = 0; i < hira2dic_org.length; i++){
		var len = hira2dic_org[i].length;
		for(var k = 1; k < len; k++){
			if(hira2dic_org[i].charAt(k) == '|'){
				break;
			}
		}
		var head = hira2dic_org[i].substr(0, k);
		for(k++; k < len; k++){
			dic.push(head + hira2dic_org[i].charAt(k) + head + hira2dic_org[i].charAt(k));
		}
	}
	return dic;
}

function expand_word_info(dic_info, word, suffix, exdic_){
	var errors = [];
	var ret = [-1, -1, ''];
	function expand_word_ex_convert(a, suffix){
		var ex2 = null;
		var rematch = false;
		var rematch_new = false;
		var last = a.charAt(a.length-1);
		if(last === 'る'){
			ex2 = ['るし', 'んかーい', 'んかい', 'んじゃ', 'んじゃね', 'んじゃねぇ', 'んじゃねえ', 'んじゃねーか', 'んじゃねぇか', 'んじゃねえか', 'んじゃない',
					'んじゃん', 'んぞ', 'んだ', 'んだい', 'んだもん', 'んだよ', 'んだろ', 'んだろう',
					'んの', 'んのが', 'んのな', 'んのに', 'んのは', 'んのよ', 'んな', 'んなぁ', 'んなら'];
		}else if(last === 'た'){
			ex2 = ['たし', 'たら', 'たり'];
			rematch_new = true;
		}else if(last === 'だ'){
			ex2 = ['だし', 'だら', 'だり'];
			rematch_new = true;
		}if(ex2 !== null){
			var a_ = a;
			for(var m = 0; m < ex2.length; m++){
				var a2 = a_.substr(0, a_.length - 1) + ex2[m];
				if(a2 === suffix.substr(0, a2.length)){
					if(a.length < a2.length){
						a = a2;
						if(ex2[m] === 'るし'){
							rematch = true;
						}else{
							rematch = rematch_new;
						}
					}
				}
			}
		}
		return {ex:a, rematch:rematch};
	}
	function exclue_match(exclude, a, suffix){
		for(var p = 0; p < exclude.length; p++){
			var per = exclude[p].indexOf('%');
			var slash = exclude[p].indexOf('/');
			var arr;
			if(-1 !== per){
				arr = [];
				var len = exclude[p].length - per - 1;
				for(var r = 0; r < len; r++){
					arr.push(exclude[p].substr(0, per) + exclude[p].charAt(per + r + 1));
				}
			}else{
				arr = [exclude[p]];
			}
			for(var r = 0; r < arr.length; r++){
				var match = a.substr(a.length - slash) + '/' + suffix.substr(a.length, arr[r].length - slash - 1);
				if(match === arr[r]){
					return false;
				}
			}
		}
		return true;
	}
	for(var i = 0; i < dic_info.length; i++){
		if(dic_info[i] === ''){
			if(ret[2].length < word.length){
				var ex_ret = search_ex_dic(exdic_, word, word+suffix);
				if(-1 === ex_ret[0]){
					ret = [0, i, word];
				}
			}
		}else if(dic_info[i] === '人称名詞'){
			var ret_word = word;
			if(suffix.charAt(0) === 'ら'){
				ret_word = word + 'ら';
			}else if(suffix.substr(0,2) === 'たち'){
				ret_word = word + 'たち';
			}else if(suffix.substr(0, 2) === 'ども'){
				ret_word = word + 'ども';
			}
			if(ret[2].length < ret_word.length){
				var ex_ret = search_ex_dic(exdic_, ret_word, word+suffix);
				if(-1 === ex_ret[0]){
					ret = [0, i, ret_word];
				}
			}
		}else if(dic_info[i].substr(0,2) === '末尾'){
			var d = dic_info[i];
			var ext = d.substr(2);
			if(ext === suffix.substr(0, ext.length)){
				if(ret[2].length < word.length){
					var ex_ret = search_ex_dic(exdic_, word, word+suffix);
					if(-1 === ex_ret[0]){
						ret = [0, i, word];
					}
				}
			}
		}else if(dic_info[i].substr(0,2) === '五段'){
			var gyou = dic_info[i].substr(2);
			var data = [
				['カ',     '_かこきいくけ', 0,0],
				['イク',   '_かこきっくけ', 0,0],
				['ガ',     '_がごぎいぐげ', 0,1],
				['サ',     '_さそししすせ', 1,0],
				['タ',     '_たとちっつて', 0,0],
				['ナ',     '_なのにんぬね', 0,1],
				['バ',     '_ばぼびんぶべ', 0,1],
				['マ',     '_まもみんむめ', 0,1],
				['ラ',     '_らろりっるれん', 2,0], // わからない → わかんない
				['ナサル', '_らろりっるれい', 3,0],
				['ワ',     '_わおいっうえ', 0,0],
				['トウ',   '_わおいううえ', 4,0]];
			var match = false;
			for(var m = 0; m < data.length; m++){
				if(data[m][0] === gyou){
					var katuyou_type = data[m][1].indexOf(suffix.charAt(0)) - 1;
					if(-1 < katuyou_type){
						var ext = [
							/* 0書か */ ['されず', 'されそう', 'された', 'されていた', 'されている', 'されてた', 'されてて', 'されてる', 'されてろ', 'されて', 'される', 'され',
								'させられちゃ', 'させられそう', 'させられた', 'させられてろ', 'させられて', 'させられる', 'させられ', 'せず', 'せたい', 'せたく',
								'せた', 'せてた', 'せてて', 'せてる', 'せてろ', 'せて', 'せない',
								'せなかった', 'せなく', 'せよう', 'せよ', 'せるかどうか', 'せる', 'せろよ', 'せろ', 'せん', 'せ',
								'れず', 'れそう', 'れたい', 'れたくて', 'れたく', 'れちゃあ', 'れちゃ', 'れたきり', 'れたっきり', 'れた', 'れては', 'れない', 'れなった', 'れなくて', 'れなく',
								'れてた', 'れてて', 'れてる', 'れてろ', 'れて', 'れど', 'れぬ', 'れる', 'れよう', 'れん', 'れ'],
							/* 1書こ */ ['うっか', 'う', 'っか'],
							/* 2書き */ ['いただかない', 'いただかなく', 'いただき', 'いただく', 'いただけ', 'いただこう', 
								'かた', 'がたい', 'がたく', 'きったし', 'きったら', 'きったり', 'きった', 'きってく', 'きってろ', 'きってる', 'きって', 'きる', 'きり',
								'きれちゃ','きれず', 'きれていない', 'きれてない', 'きれない', 'きれぬ', 'きれば', 'きれ', 'きろうか', 'きろう',
								'たい', 'たかった', 'たがる', 'たがった', 'たがってる', 'たがってろ', 'たがって', 'たくて', 'たく',
								'たければ', 'たげなら', 'たげな', 'たげ', 'たそう', 'っぱなし',
								'なく', 'ながら', 'なさい', 'なさらない', 'なさらなかった', 'なさらなく', 'なさらなければ', 'なさり', 'なさる', 'なされ',
								'ようのない', 'よう', 'ゃ', ''],
							/* 3書い書け */ ['たから', 'たきり', 'たし', 'たっけ', 'たっきり', 'たのち', 'たの', 'たら', 'た', 'ていかない', 'ていかなく', 'ていたい', 'ていたく', 'ていた', 'ているし', 'ている',
								'ていろ', 'てかない', 'てかなく', 'てかなきゃ', 'てきた', 'てきてた', 'てきてる', 'てきて', 'てくるし', 'てくる',
								'てくれちゃ', 'てくれず', 'てくれた', 'てくれてて', 'てくれてた', 'てくれてる', 'てくれて', 'てくれば', 'てくれた', 'てくれぬ', 'てくれる', 'てくれん', 'てくれ', 'てくんない', 'てくんなく', 'てくんねえ', 'てくんねぇ', 'てく',
								'てた', 'てちゃ', 'てても', 'てて', 'ても', 'てない', 'てなくて', 'てなく', 'てみたい', 'ては',
								'てみたく', 'てみた', 'てみない', 'てみなかった', 'てみなくては', 'てみなく', 'てみる', 
								'てら', 'てりゃ', 'てる', 'てれば', 'てろ', 'て', 'といたら', 'といた', 'といて', 'といで', 'とくれ', 'とく', 'ときゃ', 'とけば', 'とけ', 'とらん',
								'ちまい', 'ちまう', 'ちまった', 'ちまってた', 'ちまってる', 'ちまって', 'ちまえば', 'ちまえ', 'ちまおう',
								'ちゃいそう', 'ちゃう', 'ちゃえば', 'ちゃえ', 'ちゃおう', 'ちゃお', 'ちゃだめ', 'ちゃやだ', 'ちゃった',
								'ちゃってた', 'ちゃっても', 'ちゃってる', 'ちゃってろ', 'ちゃって', 'ちゃわない', 'ちゃわなくて','ちゃわなく', 'ちゃ'],
							/* 4書く*/ ['うちに', 'から', 'かも', 'か', 'なり', 'なんて', 'べく', 'まい', 'まじ', 'より', 'みたい', 'みたかった', 'みたく', ''],
							/* 5書き書く書け */ ['そうだから', 'そうだった', 'そうだ', 'そうです', 'そうで', 'そうなら','そうな', 'そう'],
							/* 6書け */ ['うる','っつうか',  'っつうのか', 'っつうのが', 'っつうのも', 'っつうのは', 'っつうの', 'つつ', 'なんて', 'るから', 'るかも', 'るから', 'るか', 'るし', 'るわね', 'るわ', 'る', 'れちゃ', 'れば', 'ろ', 'ば', 'まい', 'まじ', 'ども', 'ど', 'りゃあな', 'りゃあね', 'りゃ', ''],
							/* 7なさい */ ['ましたから', 'ましたから', 'ましたか', 'ました', 'ましても', 'まして', 'ましょうから', 'ましょうか', 'ましょう', 'ましょ', 'ますから',
								'ますから', 'ますか', 'ますし', 'ます', 'まーす', 'ませぬ', 'ませんから', 'ませんか', 'ませんし', 'ません', 'ませ'],
							/* 8書か書け */ ['ざる', 'ず', 'にゃ', 'ぬ', 'ねば', 'んから', 'んか', 'んし', 'ん'],
							/* 9書か書け分かん */   ['ない', 'なかろうから', 'なかろうか', 'なかろう', 'なきゃ', 'なくなる', 'なくちゃ', 'なくても', 'なくて', 'なく', 'なければ', 'なさ', 'なすぎず', 'なすぎぬ', 'なすぎん', 'なすぎ', 'なそう',
								'なかった', 'ねぇ', 'ねえ'],
							/*10 書き書く分かん*/ ['なや', 'なよ', 'ならば', 'なら', 'な', ],
							/*11 書く書け*/ ['んかい', 'んかーい', 'んだろうから', 'んだろうから', 'んだろうか', 'んだろう', 'んだから', 'んだか', 'んだわ', 'んだ', 'んでしょう', 'んでしょ', 'んですから', 'んですか', 'んです', 'んで'],
							/*12 書く書け*/ ['']]; // 語尾なし
						var ext_map = [[[0,8,9],[1],[2,5,7,10],  [3], [4,5,10,11,12],[3,5,6,7,8,9,11,12]], // カイガナバマタ
						               [[0,8,9],[1],[2,3,5,7,10],[],[4,5,10,11,12],[3,5,6,7,8,9,11,12]], // サ
						               [[0,8,9],[1],[2,5,7,10],  [3], [4,5,10,11,12],[3,5,6,7,8,9,11,12],[9,10]], // ラ
						               [[0,8,9],[1],[2,5,6,10],  [3], [4,5,10,11,12],[3,5,6,8,9,11,12],  [7,12]], // トワ
						               [[0,8,9],[1],[2,5,7,10],  [3,4,5,10,11,12],[], [3,5,6,7,8,9,11,12]]]; // ナサル
						var ext_indexs = ext_map[data[m][2]][katuyou_type];
						for(var n = 0; n < ext_indexs.length; n++){
							var ext_arr = ext[ext_indexs[n]];
							var ex_prev = '';
							var ex_rematch = false;
							for(var k = 0; k < ext_arr.length; k++){
								var ex = ext_arr[k];
								// '脱いだ'
								if(data[m][3] === 1 && katuyou_type === 3 && ext_indexs[n] === 3){
									var one = ex.charAt(0);
									if(one === 'た'){
										ex = 'だ' + ex.substr(1);
									}else if(one === 'て'){
										ex = 'で' + ex.substr(1);
									}else if(one === 'と'){
										ex = 'ど' + ex.substr(1);
									}else if(ex.substr(0,2) === 'ちま'){
										ex = 'じ' + ex.substr(1);
									}else if(ex.substr(0,2) === 'ちゃ'){
										ex = 'じ' + ex.substr(1);
									}
								}
								if(ex_rematch){
									ex = ex_prev;
									ex_rematch = false;
								}else{
									var a = expand_word_ex_convert(ex, suffix.substr(1));
									if(a.rematch){
										ex_prev = ex;
										ex_rematch = true;
										k--;
									}
									ex = a.ex;
								}
								if(ex === suffix.substr(1, ex.length)){
									var ret_word = word + suffix.substr(0, ex.length + 1);
									var enable = true;
									var exclude = [
									 	'ては/るばる',
										'ても/ら%わいうえおっ', 'でも/ら%わいうえおっ', 'ていた/だ%かきくけこい', 'でいた/だ%かきくけこい',
										'てく/ださ%らりるれろいっ', 'でく/ださ%らりるれろいっ', 'し/こり', 'たら/し%いかきく', 'だら/し%いかきく',
										'てら/っしゃ', 'てら/れ%たってなる', 'ては/しゃ%がぎぐげごい', 'ど/んな',
										'た/まえ', 'た/め息', 'た/めいき', 'たい/くつ', 'たく/らい', 'たく/せ', 'か/ぎり', 'か/しら', 'か/もしれ',
										'な/ど', 'な/かれ', 'な/んか', 'な/んざ', 'な/んて', 'てちゃ/んと', 'でちゃ/んと', 'なよ/う', 'てく/れ', 'ちゃ/%わいうえおっ', 'んのよ/く'];
									enable = exclue_match(exclude, ex, suffix.substr(1));
									if(false === enable){
									}else if(suffix.substr(0,2) === 'する'){
										// (運)動す/る => 運動/する
										enable = false;
//									}else if(suffix.substr(0,3) === 'すべき'){
//										// (運)動す/べき => 動/すべき
//										enable = false;
									}else if(ex === '' && suffix.substr(0,3) === 'けれど'){
										// あるけ/れど => ある/けれど
										enable = false;
									}else if(ex.charAt(ex.length-1) === 'た' && suffix.charAt(ex.length+1) === 'が' &&
										0 < '_らりるれろっ'.indexOf(suffix.charAt(ex.length+2))){
										// skip 入れた/がる => 入れ/たがる
										ex = ex.substr(0, ex.length-1);
										ret_word = word + suffix.substr(0, ex.length + 1);
									}else if(ex === 'て' || ex === 'で'){
										var desu = ['ましたから', 'ましたか', 'ましたし', 'ました', 'ましても', 'まして', 'ましょうから', 'ましょうか',
											'ましょう', 'ましょ', 'ますから', 'ますか', 'ますし', 'ます', 'ませんから', 'ませんか', 'ませんし', 'ません', 'ませ'];
										for(var p = 0; p < desu.length; p++){
											if(desu[p] === suffix.substr(2, desu[p].length)){
												// '書けてます', '脱いでます'
												ret_word += desu[p];
												break;
											}
										}
									}
									if(enable){
										var ex_ret = search_ex_dic(exdic_, ret_word, word+suffix);
										if(-1 === ex_ret[0]){
											if(ret[2].length < ret_word.length){
												ret = [katuyou_type + 1, i, ret_word];
											}
										}
										break;
									}
								}
							}
						}
					}
					match = true;
					break;
				}
			}
			if(!match){
				errors.push('未知の五段活用 ' + word + '/' + dic_info[i]);
			}
		}else if(dic_info[i] === '上一段' || dic_info[i] === '下一段'){
			// 見る(上一段), 食べる(下一段)
			var ext = [['き', 'った', 'ってる', 'って', 'る', 'り', 'れちゃ', 'れぬ', 'れず', 'れ', 'ろうか', 'ろう'],
				['た', 'いです', 'い', 'かもしれない', 'かも', 'きり', 'くない', 'くなる', 'くて', 'く', 'げ', 'っきり', 'ひと', ''],
				['ち', 'まう', 'まった', 'まってた', 'まってる', 'まえば', 'まえ', 'まおう', 
				'ゃいそう', 'ゃいた', 'ゃいる', 'ゃいました', 'ゃいます', 'ゃう', 'ゃえば', 'ゃえ', 'ゃおう', 'ゃお', 'ゃだめ', 'ゃやだ', 'ゃった',
				'ゃってた', 'ゃっても', 'ゃってる', 'ゃってろ', 'ゃって', 'ゃわない', 'ゃ'],
				['っ', 'ぷり', 'ぱなし'],
				['つ', 'つ'],
				['て', 'いかない', 'いかなく', 'いたい', 'いたく', 'いた', 'いて', 'いる', 'いろ', 'かない', 'かなく', 'かなきゃ',
				'から', 'きたい', 'きたく', 'きた', 'きてた', 'きてる', 'きて', 'くる', 'くれず',
				'くれた', 'くれてて', 'くれてた', 'くれてる', 'くれて',
				'くれば', 'くれまい','くれる', 'くれん', 'くれ', 'く', 'た', 'て', 'ちゃ',
				'はくれまい',
				'られない', 'られぬ', 'られん', 'らんない', 'らんなかった', 'らんなく', 'る', 'ろ', ''],
				['と', 'く', 'らん'],
				['な', 'いから', 'いか', 'い', 'かろうから', 'かろうか', 'かろう', 'かった', 'がら',
				'きゃ', 'くなる', 'くちゃ', 'くても', 'くて', 'く', 'ければ', 'さい', 'さそう', 'さ', 'り'],
				['に', 'ゃ'],
				['す', 'ぎず', 'ぎた', 'ぎだぜ', 'ぎだよ', 'ぎだわ', 'ぎだ', 'ぎて', 'ぎでした', 'ぎでしょう', 'ぎです', 'ぎぬ', 'ぎる', 'ぎん', 'ぎ'],
				['ず', ''], ['ぬ', ''],
				['さ', 'せた', 'せてたくない', 'せてた', 'せてる', 'せてろ', 'せて', 'せない', 'せなかった', 'せる'],
				['ら', 'れず', 'れたい','れたく','れた', 'れぬ', 'れん',
				'れちゃあ', 'れちゃ', 'れてしまう', 'れてた', 'れてる', 'れてろ', 'れて', 'れない', 'れなくて', 'れなく', 
				'れなかった', 'れます', 'れる', 'れん', 'れ', 'んかった', 'んない', 'んなく', 'んなかった',
				'んねえ', 'んねぇー', 'んねぇ', 'んねー'],
				['ま', 'した', 'して', 'しょうから', 'しょうか', 'しょう', 'す', 'せんでした', 'せん', 'せ'],
				['れ', 'ない', 'なかった', 'なくて', 'なく', 'ませんでした', 'ません', 'ず', 'ぬ', 
				'ました', 'ます', 'たよう', 'たよ', 'たわよ', 'たわ', 'た', 'てた', 'てら', 'てる', 'てれば', 'てろ', 'て', 'てしまう',
				'ず', 'る', 'ば'],
				['る', 'かもしれない', 'とき', 'はず', 'ひと', 'んかい', ''],
				['ろ', 'よ', ''],
				['よ', 'うか', 'う', 'っか', ''],
				['り', 'ゃ'],
				['ん', 'なよ', 'なら', 'な', 'の', ''],
				['', '']];
			var ex_prev = '';
			var ex_rematch = false;
			for(var k = 0; k < ext.length; k++){
				var ex_first = ext[k][0];
				if(suffix.substr(0,1) === ex_first || ex_first === ''){
					for(var m = 1; m < ext[k].length; m++){
						var ex = ex_first + ext[k][m];
						if(ex_rematch){
							ex = ex_prev;
							ex_rematch = false;
						}else{
							var a = expand_word_ex_convert(ex, suffix);
							if(a.rematch){
								ex_prev = ex;
								ex_rematch = true;
								m--;
							}
							ex = a.ex;
						}
						if(ex === suffix.substr(0, ex.length)){
							var ret_word = word + ex;
							var exclude = ['ても/ら%わいうえおっ', 'ていた/だ%かきくけこい', 'てく/ださ%らりるれろいっ','し/こり', 'たら/し%いかきく', 
								'た/まえ', 'た/め息', 'た/めいき', 'たい/くつ', 'たく/らい', 'たく/せ', 'か/ぎり', 'か/しら', 'か/もしれ',
								'てちゃ/んと', 'てく/れ', 'ちゃ/%わいうえおっ', 
								'た/が%っらりるれろ'];
							var enable = exclue_match(exclude, ex, suffix);
							if(false == enable){
							}else{
								var ex_ret = search_ex_dic(exdic_, ret_word, word+suffix);
								if(ex_ret[0] === -1){
									if(ret[2].length < ret_word.length){
										ret = [7, i, ret_word];
									}
									break;
								}
							}
						}
					}
				}
			}
		}else if(dic_info[i].substr(0,2) === 'サ変' || dic_info[i].substr(0,2) === 'ザ変'){
			// サ変：愛する, 食する, 属する, 得する, 涙する, 排する, 配する, 廃する, 約する, 訳する, 略する
			// ザ変：論ずる, 講ずる, 信ずる, 転ずる
			var ext = [
				['さ', 'れる', 'れたい', 'れたらしい', 'れたらしく', 'れたら', 'れた', 'れても', 'せて', 'せる', 'せた', 'せても', 'せて'],
				['し', 'た', 'て', 'ない', 'なく', 'たい', 'よう', 'ろ', 'ますれば', 'ます', 'ました', 'まして', 'ませぬ',  'ません', ''],
				['す', 'るとき', 'るひと',  'るものの', 'るもの', 'る', 'れば', 'れど', 'れ'],
				['せ', 'ず', 'ない', 'ぬ', 'よ'],
				['', '']];
			var b_zahen = dic_info[i].substr(0,2) === 'ザ変';
			var ex_prev = '';
			var ex_rematch = false;
			for(var k = 0; k < ext.length; k++){
				var ex_first = ext[k][0];
				if(b_zahen){
					if(ex_first == 'さ'){ ex_first = 'ざ'}
					if(ex_first == 'し'){ ex_first = 'じ'}
					if(ex_first == 'す'){ ex_first = 'ず'}
					if(ex_first == 'せ'){ ex_first = 'ぜ'}
				}
				if(suffix.substr(0,1) === ex_first || ex_first === ''){
					for(var m = 1; m < ext[k].length; m++){
						var ex = ex_first + ext[k][m];
						if(ex_rematch){
							ex = ex_prev;
							ex_rematch = false;
						}else{
							var a = expand_word_ex_convert(ex, suffix);
							if(a.rematch){
								ex_prev = ex;
								ex_rematch = true;
								m--;
							}
							ex = a.ex;
						}
						var ret_word = word + ex;
						if(ex === suffix.substr(0, ex.length)){
							var ex_ret = search_ex_dic(exdic_, ret_word, word+suffix);
							if(ex_ret[0] === -1){
								if(ret[2].length < ret_word.length){
									ret = [7, i, ret_word];
								}
								break;
							}
						}
					}
				}
			}
		}else if(dic_info[i] === '形容詞'){
			// うれし/い よ/い
			var ext = [
				'かろう',
				'かったり', 'かったら', 'かった',
				'がったり', 'がったら', 'がった', 'がってた', 'がってて', 'がってる', 'がって', 'がらない', 'がられる', 'がられない', 'がられて', 'がられ', 'がら', 'がる', 'がり', 'がれば', 'がれ',
				'くぞんじた', 'くぞんじて', 'くぞんじ', 'くぞんずる',
				'くても', 'くて', 'くない', 'くなくても', 'くなくて', 'くなく', 'くなったら', 'くなったり', 'くなった', 'くなかったら', 'くなかった',
				'くならない', 'くならなかった', 'くならなくって', 'くならなくて', 'くならなく', 'くならぬ', 'くなる', 'くなり', 'く',
				'うございました', 'うございます', 'うございません', 'うござる', 'うござらん',
				'うぞんじた', 'うぞんじて', 'うぞんじ', 'うぞんずる', 'うない', 'う',
				'いのが', 'いのでしたし', 'いのでしたら', 'いのでしたり', 'いのでした', 'いのです', 'いので',	'いのは',
				'いですから', 'いですか', 'いです', 'いとき', 'いところ', 'いはず', 'いまま', 'い',
				'ければ',
				'さくらい', 'さだったら', 'さだった', 'さだって', 'さだ', 'さです', 'さでした', 'さです', 'さで', 'さ',
				'そうなら', 'そうな', 'そうだから', 'そうだったら〈', 'そうだったり', 'そうだった', 'そうだ', 'そう',
				'すぎず', 'すぎない', 'すぎなかったら', 'すぎなかった', 'すぎなくて', 'すぎなく', 'すぎぬ', 'すぎる', 'すぎたら', 'すぎた', 'すぎて', 'すぎ', 'すぎん',
				'め', 'み',
				'げ', ''
			];
			if(word.charAt(word.length - 1) != 'し'){
				// [う]ございます系は、前の音も変化することがあるがここでは未サポート
				// はやい→はよう, 重たい→重とう, 大きく→大きゅう
				// 「ク活用」の時は「よし」「悪し」の活用がある
				ext = ext.concat(['し']);
			}else{
				var ext2 = [
					'ゅうございました', 'ゅうございます', 'ゅうございません', 'ゅうござる', 'ゅうござらん',
					'ゅうぞんじた', 'ゅうぞんじて', 'ゅうぞんじ', 'ゅうぞんずる', 'ゅうない', 'ゅう'
				];
				ext = ext.concat(ext2);
			}
			for(var k = 0; k < ext.length; k++){
				var a = ext[k];
				if(a === suffix.substr(0, a.length)){
					var ret_word = word + a;
					if(a.substr(a.length-2, 2) === 'たら' && suffix.substr(a.length-2, 4) == 'しい'){
						// skip
					}else if(a === 'く' && suffix.substr(1, 2) === 'らい'){
						// skip おなじく/らい →おなじ/くらい
					}else{
						var ex_ret = search_ex_dic(exdic_, ret_word, word+suffix);
						if(-1 === ex_ret[0]){
							if(ret[2].length < ret_word.length){
								ret = [9, i, ret_word];
							}
						}
					}
				}
			}
		}else{
			errors.push('未知の単語情報 ' + word + '/' + dic_info[i]);
		}
	}
	if(0 < errors.length){
		return [-2, -1, errors];
	}
	return ret;
}


function check_output(){
	last_check_type = 0;

	var hoge = '';
	var error_info = [];
	var dic_type = document.getElementById('book').value;
	var hiradic;
	var exdic;
	var warndic;
	var warndic_del = [];
	var kanji_pre_dic;
	const exdic_arr = exdic_org.replace(/\r\n/g, '\n').replace(/#/g, '\n').split('\n');
	let hiradic_arr = hiradic_org.replace(/\r\n/g, '\n').split('\n');
	if(dic_type == 'include'){
		hiradic = hiradic_arr.concat();
		hiradic = hira2dic_expand(hiradic);
		exdic = exdic_arr;
		warndic = warndic_org.replace(/\r\n/g, '\n').split('\n');
		kanji_pre_dic = kanji_pre_dic_org.replace(/\r\n/g, '\n').split('\n');
	}else{
		var userdic = document.getElementById('userdic').value;
		userdic = userdic.replace(/\r\n/g, '\n').split('\n');
		if(dic_type == 'userdata'){
			hiradic = [];
			exdic = [];
			warndic = [];
			kanji_pre_dic = [];
			for(var i = 0; i < userdic.length; i++){
				var first_char = userdic[i].charAt(0);
				if(first_char === '*'){
					var x = userdic[i].substr(1).split('/');
					if(2 <= x.length){
						for(var a = 0; a < x.length - 1; a++){
							exdic.push(x[0], x[a+1]);
						}
					}else{
						error_info.push('例外辞書項目に/がありません ' + userdic[i]);
					}
				}else if(first_char === '#'){
					//none
				}else if(first_char === '-'){
					//none
				}else if(first_char === '!'){
					warndic.push(userdic[i].substr(1));
				}else if(first_char === '='){
					//none
				}else if(is_kanji(first_char.charCodeAt(0))){
					kanji_pre_dic.push(userdic[i]);
				}else if(is_katakana(first_char.charCodeAt(0))){
					kanji_pre_dic.push(userdic[i]);
				}else{
					hiradic.push(userdic[i]);
				}
			}
		}else if(dic_type == 'mixdata'){
			hiradic = [];
			exdic = [];
			warndic = warndic_org.replace(/\r\n/g, '\n').split('\n');
			kanji_pre_dic = [];
			var deldic = [];
			var delexdic = [];
			var len = userdic.length;
			for(var i = 0; i < len; i++){
				var first_char = userdic[i].charAt(0);
				if(first_char === '*'){
					var x = userdic[i].substr(1).split('/');
					if(2 <= x.length){
						for(var a = 0; a < x.length - 1; a++){
							exdic.push(x[0], x[a+1]);
						}
					}else{
						error_info.push('例外辞書項目に/がありません ' + userdic[i]);
					}
				}else if(first_char === '#'){
					delexdic.push(userdic[i].substr(1));
				}else if(first_char === '-'){
					deldic.push(userdic[i].substr(1));
				}else if(first_char === '!'){
					warndic.push(userdic[i].substr(1));
				}else if(first_char === '='){
					warndic_del.push(userdic[i].substr(1));
				}else if(is_kanji(first_char.charCodeAt(0))){
					kanji_pre_dic.push(userdic[i]);
				}else if(is_katakana(first_char.charCodeAt(0))){
					kanji_pre_dic.push(userdic[i]);
				}else{
					hiradic.push(userdic[i]);
				}
			}

			var hira_temp = hira2dic_expand(hiradic_arr.concat());
			var len2 = hira_temp.length;
			var len3 = deldic.length;
			for(var i = 0; i < len2; i++){
				var delhit = false;
				var word = hira_temp[i];
				for(var k = 0; k < len3; k++){
					if(word === deldic[k]){
						delhit = true;
						break;
					}
				}
				if(!delhit){
					hiradic.push(word);
				}
			}
			hira_temp = null;
			var len4 = exdic_arr.length;
			var len5 = delexdic.length;
			for(var i = 0; i < len4; i+=2){
				var delhit = false;
				var word = exdic_arr[i] + '/' + exdic_arr[i+1];
				for(var k = 0; k < len5; k++){
					if(word === delexdic[k]){
						delhit = true;
						break;
					}
				}
				if(!delhit){
					exdic.push(exdic_arr[i], exdic_arr[i+1]);
				}
			}
			kanji_pre_dic = kanji_pre_dic.concat(kanji_pre_dic_org.replace(/\r\n/g, '\n').split('\n'));
		}
		userdic = '';
	}

	for(var i = 0; i < hiradic.length; i++){
		var n = 0;
		var sep = hiradic[i].indexOf('/');
		if(-1 == sep){
			for(; n < hiradic[i].length; n ++){
				if(is_kanji(hiradic[i].charCodeAt(n))){
					break;
				}
			}
			if(n != hiradic[i].length){
				hiradic[i] = hiradic[i].substr(0, n) + '/' + '末尾' + hiradic[i].substr(n);
			}
		}
	}
	hiradic.sort();
	var hiradic_temp = [];
	var tango_prev = 'x';
	for(var i = 0; i < hiradic.length; i++){
		var word = hiradic[i];
		if(tango === tango_prev){
		}else{
			hiradic_temp.push(word);
			tango_prev = word;
		}
	}
	hiradic = [];
	var hiradic_info = [];
	var hiradic_len = 0;
	tango_prev = 'x';
	for(var i = 0; i < hiradic_temp.length; i++){
		var word = hiradic_temp[i];
		var sep = word.indexOf('/');
		var tango;
		var info;
		if(-1 != sep){
			tango = word.substr(0, sep);
			info = word.substr(sep + 1);
		}else{
			tango = word;
			info = '';
		}
		if(tango === tango_prev){
			hiradic_info[hiradic_info.length - 1].push(info);
		}else{
			hiradic.push(tango);
			hiradic_info.push([info]);
			tango_prev = tango;
		}
		var len = 0;
		if(info === '人称名詞'){
			len = 2;
		}else if(info.substr(0,2) === '五段'){
			len = 10;
		}else if(info === '下一段' || info === '上一段'){
			info = 10;
		}else if(info === '形容詞'){
			info = 6;
		}
		len += tango.length;
		if(hiradic_len < len){
			hiradic_len = len;
		}
	}
	hiradic_temp = null;
	if(exdic.length % 2 != 0 ){
		alert('例外辞書項目数不正' + exdic.length);
		return;
	}
	var exdic_temp = [];
	var exdic_length = exdic.length;
	for(var i = 0; i < exdic_length; i+=2){
		exdic_temp.push([exdic[i], exdic[i+1]]);
	}
	exdic_temp.sort(function(s1, s2){
			var ret = s1[0] - s2[0];
			if(ret === 0){
				return s1[1] - s2[1];
			}
			return ret;
		});
	var exdic_sort = [];
	exdic_length = exdic_temp.length;
	var prev_exdic_item = '';
	for(var i = 0; i < exdic_length; i++){
		if(exdic_temp[i][0] === prev_exdic_item){
			exdic_sort[exdic_sort.length - 1].push(exdic_temp[i][1]);
		}else{
			prev_exdic_item = exdic_temp[i][0];
			exdic_sort.push([prev_exdic_item, exdic_temp[i][1]]);
		}
	}
	// exdic = null;
	// exdic_temp = null;

	warndic.sort();
	kanji_pre_dic.sort();
	var kanji_pre_one_dic = [];
	var kanji_pre_two_dic = [];
	var kanji_pre_info = [];
	var pre_char = 'ｘ';
	var pre_two = 'x';
	var max_kanji = 0;
	for(var i = 0; i < kanji_pre_dic.length; i++){
		var k = 0;
		for(; is_kanji(kanji_pre_dic[i].charCodeAt(k)) || is_katakana(kanji_pre_dic[i].charCodeAt(k)); k++){}
		var one = kanji_pre_dic[i].substr(0, k);
		var two = kanji_pre_dic[i].substr(k);
		var hinsi = '';
		var pos = two.indexOf('/');
		if(-1 != pos){
			hinsi = two.substr(pos + 1);
			two = two.substr(0, pos);
		}
		if(pre_char != one){
			pre_char = one;
			pre_two = two;
			kanji_pre_one_dic.push(one);
			kanji_pre_two_dic.push([two]);
			kanji_pre_info.push([[hinsi]]);
			if(max_kanji < one.length){
				max_kanji = one.length;
			}
		}else{
			var x = kanji_pre_info;
			var y = x[x.length - 1];
			if(pre_two != two){
				kanji_pre_two_dic[kanji_pre_two_dic.length - 1].push(two);
				y.push([hinsi]);
				pre_two = two;
			}else{
				y[y.length - 1].push(hinsi);
			}
		}
	}
	kanji_pre_dic = null;

	warndic_del.sort();
	var warndic_temp = warndic;
	var warndic_sort = [];
	for(var i = 0; i < warndic_temp.length; i++){
		var s = warndic_temp[i];
		if(-1 != bin_search_dic(warndic_del, s)){
			continue;
		}
		var pos = s.indexOf('/');
		if(-1 != pos){
			// 'つず[か,き,く]' => ['つずか', 'つずき', 'つずく']
			var word = s.substr(0, pos);
			var info = s.substr(pos+1);
			var pos2 = word.indexOf('[');
			var pos3 = word.indexOf(']');
			if(-1 != pos2 && pos2 < pos3){
				var prev = word.substr(0, pos2);
				var multi = word.substr(pos2 + 1, pos3 - pos2 - 1).split(',');
				for(var k = 0; k < multi.length; k++){
					var word2 = prev + multi[k];
					if(-1 != bin_search_dic(warndic_del, word2)){
						continue;
					}
					var info2 = info.replace(/%/g, multi[k]);
					warndic_sort.push([word2, info2]);
				}
			}else{
				warndic_sort.push([word, info]);
			}
		}else{
			warndic_sort.push([s, '']);
		}
	}
	warndic_temp = null;
	warndic_sort.sort(function(a, b){
		if(a[0] < b[0]){
			return -1;
		}
		return 1;
	});
	var warndic_info = [];
	warndic = [];
	for(var i = 0; i < warndic_sort.length; i++){
		warndic.push(warndic_sort[i][0]);
		warndic_info.push(warndic_sort[i][1]);
	}
	warndic_sort = null;

	var option_linenum = document.getElementById("option_linenum").checked;
	var option_noneonly = document.getElementById("option_noneonly").checked;
	var option_nospace = document.getElementById("option_nospace").checked;
	var option_prev_kanji = false;

	var concat_mode = false;
	if(0 < book.length){
		var bookname = book[current_page].name;
		if(bookname === concat_page_name || bookname === (concat_page_name + str_update)){
			concat_mode = true;
		}
	}

	var text = document.mainform.maintext.value;
	text = text.replace(/\r\n/g, '\n');
	text = html_escape(text);

	var part_titles = [];
	var part_num = 1;
	var part_title_line = false;
	var concat_head = get_id('concat_head').value;

	var line_num = 1;
	var word_start = -1;
	var color_type = 0;
	var line_none_hit = false;
	var lines = [];
	var line_start = 0;
	var line_start2 = 0;
	var line_get = true;
	var line;
	var diff = 0;
	var line_tag = '';
	var spaceline = false;
	var ruby_end_r = -1;
	var ruby_end_diff = -1;
	for(var i = 0; i < text.length; i++){
		if(line_get){
			var line_end = text.length;
			for(var p = i; p < text.length; p++){
				if(0x0a === text.charCodeAt(p)){
					line_end = p + 1;
					break;
				}
			}
			line = text.substr(line_start, line_end - line_start);
			line_get = false;
			line_start2 = line_start;
			line_start = line_end;
			if(option_nospace){
				if( /^[ 　\t\r\n]*$/.test(line) ){
					spaceline = true;
				}else{
					spaceline = false;
				}
			}
			if(concat_mode){
				if(line.substr(0, concat_head.length) === concat_head){
					var part = '';
					part += '　　　・<a href="#part' + part_num + '">';
					part += line.replace('\n', '').substr(concat_head.length) + '</a>';
					part_titles.push(part);
					line_tag = '<a id="part' + part_num + '" href="#titles">';
					part_num++;
					part_title_line = true;
				}else{
					line_tag = '';
					part_title_line = false;
				}
			}
			diff = 0;
		}
		var r = i - line_start2 + diff;
		var word_end = -1;
		var word_period = false;
		var this_char = line.charCodeAt(r);
		var is_kana =false;
		var end_check = false;
		if(0 < ruby_end_r){
			if(r === ruby_end_r + (diff - ruby_end_diff)){
				ruby_end_r = -1;
			}
		}else if((0x3041 <= this_char && this_char <= 0x3094) || this_char == 0x30fc){
			is_kana = true;
			if(word_start < 0){
				word_start = r;
			}
		}else if(this_char === 0x7c || this_char === 0xff5c){
			var ruby_mode = 1;
			var char1 = line.charCodeAt(r + 1);
			var r1 = 1;
			while(char1 !== 0x0a && r + r1 < line.length){
				if(char1 === 0x7c || char1 === 0xff5c){
					break;
				}else if(char1 === 0x300a){ //《
					if(ruby_mode == 1){
						break;
					}else if(ruby_mode <= 10){
						ruby_mode = 100;
					}else{
						break;
					}
				}else if(char1 === 0x300b){ //》
					if(101 <= ruby_mode && ruby_mode <= 120){
						ruby_end_r = r + r1; // HIT
						ruby_end_diff = diff;
					}
					break;
				}else if(1 <= ruby_mode && ruby_mode <= 10){
					ruby_mode++;
					if(ruby_mode === 11){
						break;
					}
				}else if(100 <= ruby_mode){
					ruby_mode++;
					if(ruby_mode === 121){
						break;
					}
				}
				r1++;
				char1 = line.charCodeAt(r + r1);
			}
			end_check = true;
		}else{
			end_check = true;
		}
		if(end_check){
			if(0 <= word_start){
				word_end = r;
				// {[
				if( -1 != '　、。，．！？・…―〜～」』）】｝］〕＞≫〉》 .,}]"\';:!\?/)\n'.indexOf(line.charAt(r)) ){
					word_period = true;
				}
			}
		}
		if(r === line.length - 1 && 0 <= word_start){
			if(is_kana){
				word_end = r + 1;
			}else{
				word_end = r;
			}
			word_period = true;
		}
		if(0 < word_end){
			var word = line.substr(word_start, word_end - word_start);
			var word_len = word.length;
			// 末尾の'ー'2つ目以降を省略(1つめは後で考慮)
			for(var k = word.length - 1; 1 < k; k--){
				if(0x30fc === word.charCodeAt(k)){
					word_len--;
				}else{
					break;
				}
			}
			// 先頭の'ー'省略
			var k = 0;
			for(; k < word_len; k++){
				if(0x30fc === word.charCodeAt(k)){
				}else{
					break;
				}
			}
			word = word.substr(0, word_len);
			var word_start2 = word_start;
			word_start = -1;
			var prev_kanji = false;
			var prev_kata = false;
			var prev_char = '　';
			if(0 < word_start2){
				prev_char = line.charCodeAt(word_start2 - 1);
				if(is_kanji(prev_char)){
					prev_kanji = true;
				}else if(0x30a1 <= prev_char && prev_char <= 0x30f4){
					prev_kata = true;
				}
			}
			var prematch = false;
			var prev_str_kanji = '';
			var prev_str_kanji_org = '';
			var max_word = '';
			var word_type = '';
			var warn_info = '';
			var str_num = '零一二三四五六七八九十百千万億兆〇１２３４５６７８９０1234567890';
			if((word.charAt(0) === 'つ' || word.charAt(0) === 'こ')&& -1 != str_num.indexOf(String.fromCharCode(prev_char)) ){
				// 「三つ」などのつ
				if(word.charAt(1) === 'め'){
					k = 2;
				}else{
					k = 1;
				}
			}else if(prev_kanji || prev_kata){
				if(!option_prev_kanji){
					prev_kanji = false;
				}
				var max_len = word_start2;
				if(max_kanji < word_start2){
					max_len = max_kanji;
				}
				var m = -1;
				for(var n = 1; n <= max_len; n++){
					var prev_char2 = line.charCodeAt(word_start2 - n);
					if((!prev_kata && is_kanji(prev_char2)) || (prev_kata && is_katakana(prev_char2))){
						var str_kanji_org = line.substr(word_start2 - n, n);
						var str_kanji = str_kanji_org.replace(/(.)々/g, '$1$1');
						var p = bin_search_dic(kanji_pre_one_dic, str_kanji);
						if(-1 != p){
							m = p;
							prev_str_kanji = str_kanji;
							prev_str_kanji_org = str_kanji_org;
						}
					}
				}
				if(-1 != m){
					var two = kanji_pre_two_dic[m];
					for(var n = 0; n < two.length; n++){
						if(two[n].length <= word.length && two[n] === word.substr(0, two[n].length)){
							var word2 = prev_str_kanji + two[n];
							var info_ret = expand_word_info(kanji_pre_info[m][n], word2, line.substr(word_start2 + k + word2.length - prev_str_kanji.length), exdic_sort);
							if(0 <= info_ret[0]){
								// hit
								if(max_word.length < info_ret[2].length){
									max_word = prev_str_kanji_org.substr(0, prev_str_kanji_org.length) + info_ret[2].substr(prev_str_kanji_org.length);
									word_type = '';
									// warn判定
									for(var a = max_word.length; 0 < a; a--){
										var word3 = max_word.substr(0, a);
										var b = bin_search_dic(warndic, word3);
										if(-1 != b){
											var ex_ret = search_ex_dic(exdic_sort, word3, word3)
											if(-1 ===  ex_ret[0]){
												word_type = 'warn';
												warn_info = warndic_info[b];
											}
										}
									}
								}
							}else if(-2 === info_ret[0]){
								for(var x = 0; x < info_ret[2].length; x++){
									if(-1 === bin_search_dic(error_info, info_ret[2][x])){
										error_info.push(info_ret[2][x]);
										error_info.sort();
									}
								}
							}
						}
					}
				}
				if(prev_str_kanji.length < max_word.length){
					prematch = true;
				}
			}
			for(; k < word.length; k++){
				var n = hiradic_len;
				if(word.length - k < n){
					n = word.length - k;
				}
				var hit = false;
				if(prematch){
					prematch = false;
				}else{
					prev_str_kanji = '';
					prev_str_kanji_org = '';
					max_word = '';
					word_type = '';
				}
				for(; 0 < n ; n-- ){
					var word2 = word.substr(k, n);
					var word_period3 = false;
					var word_period4 = false;
					if(k + n == word.length){
						if(word_period){
							word_period4 = true;
						}
						word_period3 = true;
					}
					var word3 = word2 + '、';
					var word4 = word2 + '。';
					var m = bin_search_dic(warndic, word2);
					if(-1 != m){
						var ex_ret = search_ex_dic(exdic_sort, word2, word.substr(k))
						if(-1 ===  ex_ret[0] &&
								max_word.length - prev_str_kanji.length < word2.length){
							word_type = 'warn';
							max_word = word2;
							prev_str_kanji = '';
							warn_info = warndic_info[m];
						}
					}
					m = bin_search_dic(hiradic, word2);
					if(-1 != m){
						var info_ret = expand_word_info(hiradic_info[m], word2, line.substr(word_start2 + k + word2.length), exdic_sort);
						if(0 <= info_ret[0]){
							// hit
							if(max_word.length - prev_str_kanji.length < info_ret[2].length){
								max_word = info_ret[2];
								prev_str_kanji = '';
								warn_info = '';
							}
						}else if(-2 === info_ret[0]){
							for(var x = 0; x < info_ret[2].length; x++){
								if(-1 === bin_search_dic(error_info, info_ret[2][x])){
									error_info.push(info_ret[2][x]);
									error_info.sort();
								}
							}
							m = -1;
						}else{
							m = -1; // hit取り消し
						}
					}
					if(-1 === m && word_period3){
						m = bin_search_dic(hiradic, word3);
						if(-1 === m && word_period4){
							m = bin_search_dic(hiradic, word4);
						}
					}
					if(-1 === m && k === 0){
						var word5 = word2 + '〈';
						var word6 = word5 + '、';
						var word7 = word5 + '。';
						var m = bin_search_dic(hiradic, word5);
						if(-1 === m && word_period3){
							m = bin_search_dic(hiradic, word6);
							if(-1 === m && word_period4){
								m = bin_search_dic(hiradic, word7);
							}
						}
					}
					if(-1 != m){
						var ex_ret = search_ex_dic(exdic_sort, word2, word.substr(k));
						if(-1 === ex_ret[0]){
							if(max_word.length - prev_str_kanji.length < word2.length){
								max_word = word2;
								prev_str_kanji = '';
								warn_info = '';
							}
						}
					}
				}
				if(max_word.length - prev_str_kanji.length <= 0){
					// 未ヒット
					if(k === 0){
						// 「う、うかつ」のような最初の言葉を色分けする
						var n = 1;
						for(; n + word_start2 < line.length; n++){
							var a = line.charAt(word_start2 + n);
							if(-1 === '、。…・'.indexOf(a)){
								break;
							}
						}
						if(1 < n){
							if(word.charAt(0) === line.charAt(word_start2 + n)){
								max_word = word.charAt(0);
								prev_str_kanji = '';
								warn_info = '';
							}
						}
					}
				}
				if(0 <  max_word.length - prev_str_kanji.length){
					var p = prev_str_kanji.length;
					var s1;
					if(word_type==='warn'){
						if(0 < warn_info.length){
							s1 = '<span class="colorwarn" title="' + html_escape(warn_info) + '">'
						}else{
							s1 = '<span class="colorwarn">';
						}
						line_none_hit = true;
					}else{
						s1 = '<span class="color' + (color_type + 1) + '">';
						color_type = (color_type + 1) % 3;
					}
					var s2 = '</span>';
					var s_ = s1 + max_word + s2;
					line = line.substr(0, word_start2 + k - p) + s_ + line.substr(word_start2 + k + max_word.length - p);
					word_start2 += s1.length + s2.length;
					diff += s1.length + s2.length;
					k += max_word.length - p - 1;
					hit = true;
				}
				if(hit){
					prev_kanji = false;
				}else if(false === prev_kanji){
					var word3 = word.substr(k,1);
					if(word2 === 'ー' && k == word_len + 1){
						// 末尾のーを赤くしない
					}else{
						var n2 = word3.length;
						var s1 = '<span class="colornone">';
						var s2 = '</span>';
						var s_ = s1 + word3 + s2;
						line = line.substr(0, word_start2 + k) + s_ + line.substr(word_start2 + k + n2);
						word_start2 += s1.length + s2.length;
						diff += s1.length + s2.length;
						line_none_hit = true;
					}
				}else{
					if(1 < k){
						prev_kanji = false;
					}
				}
				prev_kata = false;
			}
			r = i - line_start2 + diff;
		}
		if(line.length - 1 === r){
			if(part_title_line){
				line_none_hit = true;
			}
			if(option_noneonly && false === line_none_hit){
				// この行は結果に加えない
			}else if(option_nospace && spaceline){
				// この行は結果に加えない
			}else{
				if( option_linenum ){
					var s4 = '<span class="linenum">';
					var s5 = ': </span>';
					var num = '';
					if(concat_mode){
						num += (part_num - 1) + '/';
					}
					num += fixnum(line_num);
					var s_ = s4 + num + s5;
					if(0 < line_tag.length){
						lines.push(s_ + line_tag + line + '</a>');
					}else{
						lines.push(s_ + line);
					}
				}else{
					if(0 < line_tag.length){
						lines.push(line_tag + line + '</a>');
					}else{
						lines.push(line);
					}
				}
				line_none_hit = false;
			}
			line_get = true;
			line_num++;
		}
	}

	text = '';
	var out_error = new Array(error_info.length);
	for(var i = 0;i < error_info.length; i++){
		out_error[i] = html_escape(error_info[i]);
	}
	var err_str = out_error.join('<br>');
	if(0 < err_str.length){
		text += err_str + '<hr>';
	}
	text += '　<span class="colorwarn">テキスト</span>：警告表示<br>';
	text += '　<span class="color1">あい</span><span class="color2">うえ</span><span class="color3">お</span>：識別結果<br>';
	text += '　<span class="colornone">かきくけこ</span>：識別失敗(誤字の可能性)<br><hr>';
	text += '■結果テキスト<br>';
	if(concat_mode){
		text += '<span id="titles"></span>' + part_titles.join('<br>') + '<hr>';
	}else{
		text += '';
	}
	text += lines.join('<br>');
	hoge = hoge.replace(/\n/g, '<br>');

	document.getElementById("result").innerHTML = '<div class="resultext">' + text + '<br>' + hoge + '</div>';
	if(0 < err_str.length){
		alert('エラーがあります。本文上部をご覧ください。');
	}
}

var kanji_list = [
	// 小学校で習う漢字(1年-6年)
	'一右雨円王音下火花貝学気九休玉金空月犬見五口校左三山子四糸字耳七車手十出女小上森人水正生青夕石赤千川先早草足村大男竹中虫町天田土二日入年白八百文木本名目立力林六',
	'引羽雲園遠何科夏家歌画回会海絵外角楽活間丸岩顔汽記帰弓牛魚京強教近兄形計元言原戸古午後語工公広交光考行高黄合谷国黒今才細作算止市矢姉思紙寺自時室社弱首秋週春書少場色食心新親図数西声星晴切雪船線前組走多太体台地池知茶昼長鳥朝直通弟店点電刀冬当東答頭同道読内南肉馬売買麦半番父風分聞米歩母方北毎妹万明鳴毛門夜野友用曜来里理話',
	'悪安暗医委意育員院飲運泳駅央横屋温化荷界開階寒感漢館岸起期客究急級宮球去橋業曲局銀区苦具君係軽血決研県庫湖向幸港号根祭皿仕死使始指歯詩次事持式実写者主守取酒受州拾終習集住重宿所暑助昭消商章勝乗植申身神真深進世整昔全相送想息速族他打対待代第題炭短談着注柱丁帳調追定庭笛鉄転都度投豆島湯登等動童農波配倍箱畑発反坂板皮悲美鼻筆氷表秒病品負部服福物平返勉放味命面問役薬由油有遊予羊洋葉陽様落流旅両緑礼列練路和',
	'愛案以衣位囲胃印英栄塩億加果貨課芽改械害街各覚完官管関観願希季紀喜旗器機議求泣救給挙漁共協鏡競極訓軍郡径型景芸欠結建健験固功好候航康告差菜最材昨札刷殺察参産散残士氏史司試児治辞失借種周祝順初松笑唱焼象照賞臣信成省清静席積折節説浅戦選然争倉巣束側続卒孫帯隊達単置仲貯兆腸低底停的典伝徒努灯堂働特得毒熱念敗梅博飯飛費必票標不夫付府副粉兵別辺変便包法望牧末満未脈民無約勇要養浴利陸良料量輪類令冷例歴連老労録',
	'圧移因永営衛易益液演応往桜恩可仮価河過賀快解格確額刊幹慣眼基寄規技義逆久旧居許境均禁句群経潔件券険検限現減故個護効厚耕鉱構興講混査再災妻採際在財罪雑酸賛支志枝師資飼示似識質舎謝授修述術準序招承証条状常情織職制性政勢精製税責績接設舌絶銭祖素総造像増則測属率損退貸態団断築張提程適敵統銅導徳独任燃能破犯判版比肥非備俵評貧布婦富武復複仏編弁保墓報豊防貿暴務夢迷綿輸余預容略留領',
	'異遺域宇映延沿我灰拡革閣割株干巻看簡危机揮貴疑吸供胸郷勤筋系敬警劇激穴絹権憲源厳己呼誤后孝皇紅降鋼刻穀骨困砂座済裁策冊蚕至私姿視詞誌磁射捨尺若樹収宗就衆従縦縮熟純処署諸除将傷障城蒸針仁垂推寸盛聖誠宣専泉洗染善奏窓創装層操蔵臓存尊宅担探誕段暖値宙忠著庁頂潮賃痛展討党糖届難乳認納脳派拝背肺俳班晩否批秘腹奮並陛閉片補暮宝訪亡忘棒枚幕密盟模訳郵優幼欲翌乱卵覧裏律臨朗論',
	// 常用漢字
	'亜哀握扱依偉威尉慰為維緯違井壱逸稲芋姻陰隠韻渦浦影詠鋭疫悦謁越閲宴援炎煙猿縁鉛汚凹奥押欧殴翁沖憶乙卸穏佳嫁寡暇架禍稼箇華菓蚊雅餓介塊壊怪悔懐戒拐皆劾慨概涯該垣嚇核殻獲穫較郭隔岳掛潟喝括渇滑褐轄且刈乾冠勘勧喚堪寛患憾換敢棺款歓汗環甘監緩缶肝艦貫還鑑閑陥含頑企奇岐幾忌既棋棄祈軌輝飢騎鬼偽儀宜戯擬欺犠菊吉喫詰却脚虐丘及朽窮糾巨拒拠虚距享凶叫峡恐恭挟況狂狭矯脅響驚仰凝暁斤琴緊菌襟謹吟駆愚虞偶遇隅屈掘靴繰桑勲薫傾刑啓契恵慶憩掲携渓継茎蛍鶏迎鯨撃傑倹兼剣圏堅嫌懸献肩謙賢軒遣顕幻弦玄孤弧枯誇雇顧鼓互呉娯御悟碁侯坑孔巧恒慌抗拘控攻更江洪溝甲硬稿絞綱肯荒衡貢購郊酵項香剛拷豪克酷獄腰込墾婚恨懇昆紺魂佐唆詐鎖債催宰彩栽歳砕斎載剤咲崎削搾索錯撮擦傘惨桟暫伺刺嗣施旨祉紫肢脂諮賜雌侍慈滋璽軸執湿漆疾芝赦斜煮遮蛇邪爵酌釈寂朱殊狩珠趣儒寿需囚愁秀臭舟襲酬醜充柔汁渋獣銃叔淑粛塾俊瞬准循旬殉潤盾巡遵庶緒叙徐償匠升召奨宵尚床彰抄掌昇晶沼渉焦症硝礁祥称粧紹肖衝訟詔詳鐘丈冗剰壌嬢浄畳譲醸錠嘱飾殖触辱伸侵唇娠寝審慎振浸紳薪診辛震刃尋甚尽迅陣酢吹帥炊睡粋衰遂酔随',
	'髄崇枢据杉澄瀬畝是姓征牲誓請逝斉隻惜斥析籍跡拙摂窃仙占扇栓潜旋繊薦践遷鮮漸禅繕塑措疎礎租粗訴阻僧双喪壮捜掃挿曹槽燥荘葬藻遭霜騒憎贈促即俗賊堕妥惰駄耐怠替泰滞胎袋逮滝卓択拓沢濯託濁諾但奪脱棚丹嘆淡端胆鍛壇弾恥痴稚致遅畜蓄逐秩窒嫡抽衷鋳駐弔彫徴懲挑眺聴超跳勅朕沈珍鎮陳津墜塚漬坪釣亭偵貞呈堤帝廷抵締艇訂逓邸泥摘滴哲徹撤迭添殿吐塗斗渡途奴怒倒凍唐塔悼搭桃棟盗痘筒到謄踏逃透陶騰闘洞胴峠匿督篤凸突屯豚曇鈍縄軟尼弐如尿妊忍寧猫粘悩濃把覇婆廃排杯輩培媒賠陪伯拍泊舶薄迫漠爆縛肌鉢髪伐罰抜閥伴帆搬畔繁般藩販範煩頒盤蛮卑妃彼扉披泌疲碑罷被避尾微匹姫漂描苗浜賓頻敏瓶怖扶敷普浮符腐膚譜賦赴附侮舞封伏幅覆払沸噴墳憤紛雰丙併塀幣弊柄壁癖偏遍舗捕穂募慕簿倣俸奉峰崩抱泡砲縫胞芳褒邦飽乏傍剖坊妨帽忙房某冒紡肪膨謀僕墨撲朴没堀奔翻凡盆摩磨魔麻埋膜又抹繭慢漫魅岬妙眠矛霧婿娘銘滅免茂妄猛盲網耗黙戻紋厄躍柳愉癒諭唯幽悠憂猶裕誘雄融与誉庸揚揺擁溶窯謡踊抑翼羅裸頼雷絡酪欄濫吏履痢離硫粒隆竜慮虜了僚寮涼猟療糧陵倫厘隣塁涙累励鈴隷零霊麗齢暦劣烈裂廉恋錬炉露廊楼浪漏郎賄惑枠湾腕',
	// 2010年追加
	'挨宛嵐畏萎椅茨咽淫唄怨媛艶旺岡臆俺苛牙瓦潰崖蓋骸柿顎葛釜鎌韓玩伎亀畿臼巾僅錦串窟熊詣稽隙桁拳鍵舷股虎勾梗喉乞駒頃痕沙挫采塞埼柵拶斬餌鹿嫉腫呪袖蹴憧拭尻芯腎須裾凄醒脊戚煎羨腺詮膳狙遡曽爽痩捉遜汰唾堆戴誰旦綻酎貼捗椎爪鶴諦溺妬賭藤瞳栃頓那奈梨謎鍋匂虹捻罵箸氾汎阪斑眉膝肘阜蔽餅蔑蜂貌睦勃昧枕蜜冥麺冶弥闇湧妖沃藍璃侶瞭瑠呂賂弄麓脇',
	'曖彙鬱楷諧毀嗅惧憬錮傲刹恣摯羞箋踪緻嘲貪丼訃璧哺喩瘍拉辣籠慄',
	// 第3水準
	// '塡剝頰', // 𠮟　正字だが第3なので無効とする
	// 代用異体字
	'填頬剥叱',
];
var kanji_list_ex = [
	// 人名用漢字
	'丑丞乃之乎也云亘亙些亦亥亨亮仔伊伍伽佃佑伶侃俄俣倭倦倖偲傭儲允兎兜其冴凌凧凪凱函劉劫勿匡廿卜卯卿厨厩叉叡叢叶只吾吻哉哨啄哩喬喧喰喋嘩嘉嘗噌噂圃圭坐尭坦埴堰堺堵塙壕壬夷奄套娃姪姥娩嬉孟宏宋宕宥寅寓寵尖尤屑峨峻嵯嵩嶺巌巳巴巷巽帖幌幡庄庇庚庵廟廻弘弛彦彪彬忽怜恢恰恕悌惟惚悉惇惹惣慧憐戊或戟托按挺挽掬捲捷捺捧掠揃摺撒撰撞播撫擢孜敦斐斡斧斯於旭昂昏昌晃晒晋晦智暢曙曝曳朋朔杏杖杜李杭杵杷枇柑柴柘柊柏柾柚桧桔桂栖桐栗梧梓梢梯桶梶椛梁棲椋椀楯楚楕椿楠楓楢楊榎樺榊榛槙槍槌樫槻樟樋橘樽檎檀櫛櫓欣欽歎此殆毅毘汀汝汐汲沌沓沫洲洛浩浬淵淳渚淀淋渥湘湊湛溢溜漕漣濡瀕灘灸灼烏焚煤煉燕燦燭爾牒牟牡牽犀狼猪獅玖珂珊玲琢琉瑛琶琵琳瑚瑞瑳瓜瓢甥甫畠畢疋疏皐瞥矩砦砥砧硯碓碗碩碧磐磯祇祢禰祐祷禄禎禽禾秦秤稀稔稜穣穿窄窪窺竣竪竺竿笈笹笠筈筑箕箔篇篠簾籾粥粟糊紘紗紐絃紬絢綜綴緋綾縞徽纂纏翠耀而耶耽聡肇肋肴胤胡腔膏臥舜舵芥芹芭芙芦苑茄苔茅茸茜莞荻莫菅菖萄菩萌菱葦葵萱葺萩董葡蓑蒔蒐蒼蒲蒙蓉蓮蔭蔦蓬蔓蕎蕨蕉蕃蕪薙蕗藁薩蘇蘭蝦蝶螺蟹衿袈袴裡裟裳襖訊訣註詫誼諏諒謂諺讃豹貰賑跨蹄蹟輔輯輿轟辰辻迂迄辿迦這逗逢遥遁遼邑祁郁鄭酉醇醐醍釘釧鋒鋸錐錆錫鍬鎧閃閏閤阿陀隈隼雀雁雛雫霞靖鞄鞍鞘鞠鞭頁頗饗馨馴馳駕駿魁魯鮎鯉鯛鰯鱒鱗鳩鳶鳳鴨鴻鵜鵬鷲鷺鷹麟麿黛鼎',
	'侑俐凜凛凰勁堯奎崚巖已彗徠惺昊昴晏晄晟晨暉檜栞梛椰槇橙櫂毬洸洵滉漱澪煌熙燎燿珈珀琥瑶皓眸祿稟穰穹笙絆綺綸羚翔脩苺茉莉菫萠蕾詢諄赳迪逞遙釉頌颯驍麒黎猪',
	// 人名漢字(異体字)
	'薗駈曾瀧嶋燈盃冨峯埜龍',
	'亞惡爲榮衞圓應櫻奧價壞懷樂卷陷氣僞戲峽狹曉勳惠鷄藝縣儉劍險圈檢顯驗嚴廣恆國碎雜兒濕實壽收從澁獸縱敍將燒奬條乘淨剩疊孃讓釀眞寢愼盡粹醉穗齊靜攝專戰纖禪壯爭莊搜裝騷藏臟帶滯單團彈晝鑄廳聽鎭轉傳盜稻拜賣髮拔祕拂佛飜萬默彌藥與搖樣謠來覽凉壘禮橫寬薰黑緖諸祥神瀨增都德福賴綠郞朗',
];

function kanji_check(){
	last_check_type = 1;

	var hoge = '';
	var error_info = [];

	var option_linenum = document.getElementById("option_linenum").checked;
	var option_noneonly = document.getElementById("option_noneonly").checked;
	var option_nospace = document.getElementById("option_nospace").checked;

	var concat_mode = false;
	if(0 < book.length){
		var bookname = book[current_page].name;
		if(bookname === concat_page_name || bookname === (concat_page_name + str_update)){
			concat_mode = true;
		}
	}

	var text = document.mainform.maintext.value;
	text = text.replace(/\r\n/g, '\n');
	text = html_escape(text);

	var part_titles = [];
	var part_num = 1;
	var part_title_line = false;
	var concat_head = get_id('concat_head').value;

	var line_num = 1;
	var word_start = -1;
	var line_none_hit = false;
	var lines = [];
	var line_start = 0;
	var line_start2 = 0;
	var line_get = true;
	var line;
	var diff = 0;
	var line_tag = '';
	var spaceline = false;
	for(var i = 0; i < text.length; i++){
		if(line_get){
			var line_end = text.length;
			for(var p = i; p < text.length; p++){
				if(0x0a === text.charCodeAt(p)){
					line_end = p + 1;
					break;
				}
			}
			line = text.substr(line_start, line_end - line_start);
			line_get = false;
			line_start2 = line_start;
			line_start = line_end;
			if(option_nospace){
				if( /^[ 　\t\r\n]*$/.test(line) ){
					spaceline = true;
				}else{
					spaceline = false;
				}
			}
			if(concat_mode){
				if(line.substr(0, concat_head.length) === concat_head){
					var part = '';
					part += '　　　・<a href="#part' + part_num + '">';
					part += line.replace('\n', '').substr(concat_head.length) + '</a>';
					part_titles.push(part);
					line_tag = '<a id="part' + part_num + '" href="#titles">';
					part_num++;
					part_title_line = true;
				}else{
					line_tag = '';
					part_title_line = false;
				}
			}
			diff = 0;
		}
		var r = i - line_start2 + diff;
		var word_end = -1;
		var word_period = false;
		var this_char = line.charCodeAt(r);
		var this_char2 = line.charAt(r);
		let sinjoyou = false;
		if(is_kanji(this_char) && this_char != 0x3005){
			var hit = false;
			for(var k = 0; k < kanji_list.length; k++){
				if(-1 != kanji_list[k].indexOf(this_char2)){
					hit = true;
					if(9 <= k){
						sinjoyou = true;
					}
					break;
				}
			}
			if(!hit || sinjoyou){
				var hit_ex = false;
				if(!hit){
					for(var k = 0; k < kanji_list_ex.length; k++){
						if(-1 != kanji_list_ex[k].indexOf(this_char2)){
							hit_ex = true;
							break;
						}
					}
				}
				var s1 = '<span class="kanjiext">';
				if(sinjoyou){
					s1 = '<span class="kanjisin">';
				}
				if(hit_ex){
					s1 = '<span class="kanjizinmei">';
				}
				var s2 = '</span>';
				var word = this_char2;
				var s_ = s1 + word + s2;
				line = line.substr(0, r) + s_ + line.substr(r + word.length);
				diff += s1.length + s2.length;
				line_none_hit = true;
			}
		}
		if(line.length - 1 === r){
			if(part_title_line){
				line_none_hit = true;
			}
			if(option_noneonly && false === line_none_hit){
				// この行は結果に加えない
			}else if(option_nospace && spaceline){
				// この行は結果に加えない
			}else{
				if(option_linenum){
					var s4 = '<span class="linenum">';
					var s5 = ': </span>';
					var num = '';
					if(concat_mode){
						num += (part_num - 1) + '/';
					}
					num += fixnum(line_num);
					var s_ = s4 + num + s5;
					if(0 < line_tag.length){
						lines.push(s_ + line_tag + line + '</a>');
					}else{
						lines.push(s_ + line);
					}
				}else{
					if(0 < line_tag.length){
						lines.push(line_tag + line + '</a>');
					}else{
						lines.push(line);
					}
				}
				line_none_hit = false;
			}
			line_get = true;
			line_num++;
		}
	}

	if(concat_mode){
		text = '<span id="titles"></span>' + part_titles.join('<br>') + '<hr>';
	}else{
		text = '';
	}
	let headtext = '';
	headtext += '■常用漢字テスト<br>';
	headtext += '　<span class="kanjiext">漢字</span>：常用・人名以外の漢字<br>';
	headtext += '　<span class="kanjizinmei">漢字</span>：人名用漢字<br>';
	headtext += '　<span class="kanjisin">漢字</span>：新常用漢字<br>';
	headtext += '　漢字：常用漢字、漢字以外<br>';
	headtext += '<hr>';
	headtext += '■結果テキスト<br>';
	text += headtext + lines.join('<br>');
	hoge = hoge.replace(/\n/g, '<br>');

	document.getElementById("result").innerHTML = '<div class="resultext">' + text + '<br>' + hoge + '</div>';
}
